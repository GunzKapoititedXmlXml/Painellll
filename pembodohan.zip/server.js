const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 3000;

const server = http.createServer((req, res) => {
    let filePath = path.join(__dirname, 'public', req.url === '/' ? 'index.html' : req.url);
    
    fs.readFile(filePath, (err, data) => {
        if (err) {
            res.writeHead(404);
            res.end('404 - File tidak ditemukan');
        } else {
            res.writeHead(200);
            res.end(data);
        }
    });
});

server.listen(PORT, () => {
    console.log(`Server: http://localhost:${PORT}`);
});

// Buka browser otomatis
const { exec } = require('child_process');
exec(`start http://localhost:${PORT}`);