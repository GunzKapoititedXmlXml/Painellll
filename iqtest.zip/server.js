const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const cors = require('cors');
const compression = require('compression');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 9000;

// Middleware
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            scriptSrc: ["'self'", "'unsafe-inline'"],
            styleSrc: ["'self'", "'unsafe-inline'"],
            imgSrc: ["'self'", "data:"],
        },
    },
}));

app.use(compression());
app.use(cors({
    origin: process.env.ALLOWED_ORIGINS ? process.env.ALLOWED_ORIGINS.split(',') : '*'
}));

// Rate limiting
const limiter = rateLimit({
    windowMs: 500 * 1000, // 1 minute
    max: 20, // 10 requests per minute
    message: 'Too many requests from this IP, please try again later.',
    standardHeaders: true,
    legacyHeaders: false,
});

app.use('/api/', limiter);

// Bot detection middleware
function isBot(userAgent) {
    const botPatterns = [
        'bot', 'crawler', 'spider', 'scraper',
        'googlebot', 'bingbot', 'slurp', 'duckduckbot',
        'baiduspider', 'yandexbot', 'facebookexternalhit',
        'python', 'curl', 'wget', 'headless', 'phantomjs',
        'puppeteer', 'selenium', 'playwright'
    ];
    
    const ua = userAgent ? userAgent.toLowerCase() : '';
    return botPatterns.some(pattern => ua.includes(pattern));
}

// Encryption function
function encryptHTML(html) {
    const algorithm = 'aes-256-cbc';
    const key = crypto.randomBytes(32);
    const iv = crypto.randomBytes(16);
    
    const cipher = crypto.createCipheriv(algorithm, key, iv);
    let encrypted = cipher.update(html, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    
    return {
        encrypted: encrypted,
        key: key.toString('hex'),
        iv: iv.toString('hex')
    };
}

// Serve protected HTML
app.get('/', (req, res) => {
    const userAgent = req.headers['user-agent'] || '';
    
    // Bot detection
    if (isBot(userAgent)) {
        return res.send(`
            <!DOCTYPE html>
            <html>
            <head><title>Access Denied</title></head>
            <body>
                <h1>🤖 Access Denied</h1>
                <p>This content is not available for bots and crawlers.</p>
            </body>
            </html>
        `);
    }
    
    // Read and encrypt HTML
    const htmlPath = path.join(__dirname, 'public', 'index.html');
    fs.readFile(htmlPath, 'utf8', (err, data) => {
        if (err) {
            return res.status(404).send('Page not found');
        }
        
        const encryptedData = encryptHTML(data);
        
        // Send encrypted HTML with decryption script
        const protectedHTML = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Protected Content</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .container {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            max-width: 500px;
            width: 90%;
            text-align: center;
        }
        .loader {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #667eea;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            animation: spin 1s linear infinite;
            margin: 20px auto;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .status { color: #666; margin-top: 10px; }
        .content { display: none; }
        .error { color: #e74c3c; }
    </style>
</head>
<body>
    <div class="container">
        <div id="loading">
            <div class="loader"></div>
            <p class="status">🔐 Decrypting content...</p>
        </div>
        <div id="content" class="content"></div>
    </div>

    <script>
        const encryptedData = '${encryptedData.encrypted}';
        const key = '${encryptedData.key}';
        const iv = '${encryptedData.iv}';
        
        async function decryptContent(encrypted, key, iv) {
            try {
                // Anti-debugging
                const startTime = performance.now();
                debugger;
                const endTime = performance.now();
                if (endTime - startTime > 100) {
                    document.getElementById('loading').innerHTML = 
                        '<h2 class="error">⛔ Access Denied</h2><p>Developer tools detected</p>';
                    return null;
                }
                
                const keyBuffer = new Uint8Array(key.match(/.{1,2}/g).map(b => parseInt(b, 16)));
                const ivBuffer = new Uint8Array(iv.match(/.{1,2}/g).map(b => parseInt(b, 16)));
                const encryptedBuffer = new Uint8Array(encrypted.match(/.{1,2}/g).map(b => parseInt(b, 16)));
                
                const cryptoKey = await crypto.subtle.importKey(
                    'raw',
                    keyBuffer,
                    { name: 'AES-CBC' },
                    false,
                    ['decrypt']
                );
                
                const decrypted = await crypto.subtle.decrypt(
                    { name: 'AES-CBC', iv: ivBuffer },
                    cryptoKey,
                    encryptedBuffer
                );
                
                const decoder = new TextDecoder();
                return decoder.decode(decrypted);
            } catch (error) {
                console.error('Decryption failed:', error);
                return null;
            }
        }
        
        decryptContent(encryptedData, key, iv).then(html => {
            if (html) {
                document.getElementById('loading').style.display = 'none';
                document.getElementById('content').style.display = 'block';
                document.getElementById('content').innerHTML = html;
            } else {
                document.getElementById('loading').innerHTML = 
                    '<h2 class="error">❌ Access Denied</h2><p>Unable to decrypt content</p>';
            }
        });
    </script>
</body>
</html>
        `;
        
        res.send(protectedHTML);
    });
});

// Serve static files
app.use('/static', express.static('public'));

// Health check
app.get('/health', (req, res) => {
    res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// Error handling
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).send('Something went wrong!');
});

app.listen(PORT, () => {
    console.log(`✅ Server running on http://localhost:${PORT}`);
    console.log(`🔒 Protected mode: ON`);
    console.log(`📊 Rate limit: 10 requests/minute`);
});

// Open browser
const { exec } = require('child_process');
const os = require('os');

setTimeout(() => {
    const platform = os.platform();
    const url = `http://localhost:${PORT}`;
    
    if (platform === 'win32') {
        exec(`start ${url}`);
    } else if (platform === 'darwin') {
        exec(`open ${url}`);
    } else {
        exec(`xdg-open ${url}`);
    }
}, 1000);