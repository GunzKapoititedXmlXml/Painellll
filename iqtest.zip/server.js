const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 9000;

const server = http.createServer((req, res) => {
    const host = req.headers.host;
    const url = req.url;
    
    // BLOKIR: qzz.io/index.html
    if (host && host.includes('https://testiq.xonepanel.qzz.io') && url === '/index.html') {
        res.writeHead(403, { 'Content-Type': 'text/html' });
        res.end(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>403 - Akses Diblokir</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        text-align: center;
                        padding: 50px;
                        background: #1a1a1a;
                        color: white;
                    }
                    .blocked {
                        background: #2d2d2d;
                        padding: 30px;
                        border-radius: 10px;
                        max-width: 500px;
                        margin: 0 auto;
                    }
                    h1 { color: #ff4444; }
                </style>
            </head>
            <body>
                <div class="blocked">
                    <h1>🚫 Akses Diblokir</h1>
                    <p>URL <strong>${host}${url}</strong> tidak dapat diakses.</p>
                    <p>Silakan akses <a href="/" style="color: #4CAF50;">halaman utama</a>.</p>
                </div>
            </body>
            </html>
        `);
        return;
    }

    // IZINKAN: qzz.io/ (root) dan semua file lain
    let filePath = path.join(__dirname, 'public', req.url === '/' ? 'index.html' : req.url);
    
    fs.readFile(filePath, (err, data) => {
        if (err) {
            res.writeHead(404);
            res.end('404 - File tidak ditemukan');
        } else {
            res.writeHead(200);
            res.end(data);
        }
    });
});

server.listen(PORT, () => {
    console.log(`Server berjalan di: http://localhost:${PORT}`);
    console.log('✅ qzz.io/ BISA diakses');
    console.log('🚫 qzz.io/index.html DIBLOKIR');
});

// Buka browser otomatis
const { exec } = require('child_process');
exec(`start http://localhost:${PORT}`);