const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = 9000;

// Fungsi untuk mengenkripsi konten HTML
function encryptHTML(html) {
    const algorithm = 'aes-256-cbc';
    const key = crypto.randomBytes(32);
    const iv = crypto.randomBytes(16);
    
    const cipher = crypto.createCipheriv(algorithm, key, iv);
    let encrypted = cipher.update(html, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    
    return {
        encrypted: encrypted,
        key: key.toString('hex'),
        iv: iv.toString('hex')
    };
}

// Middleware untuk deteksi bot
function isBot(userAgent) {
    const botPatterns = [
        'bot', 'crawler', 'spider', 'scraper', 
        'googlebot', 'bingbot', 'slurp', 'duckduckbot',
        'baiduspider', 'yandexbot', 'facebookexternalhit',
        'python', 'curl', 'wget', 'headless', 'phantomjs'
    ];
    
    const ua = userAgent ? userAgent.toLowerCase() : '';
    return botPatterns.some(pattern => ua.includes(pattern));
}

// Rate limiting
const requestCounts = new Map();
const RATE_LIMIT = 10; // requests per minute
const WINDOW_SIZE = 60000; // 1 minute

function checkRateLimit(ip) {
    const now = Date.now();
    const windowStart = now - WINDOW_SIZE;
    
    if (!requestCounts.has(ip)) {
        requestCounts.set(ip, []);
    }
    
    const requests = requestCounts.get(ip);
    const validRequests = requests.filter(time => time > windowStart);
    
    if (validRequests.length >= RATE_LIMIT) {
        return false;
    }
    
    validRequests.push(now);
    requestCounts.set(ip, validRequests);
    return true;
}

const server = http.createServer((req, res) => {
    // 1. Cek Rate Limit
    const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
    if (!checkRateLimit(ip)) {
        res.writeHead(429, { 'Content-Type': 'text/plain' });
        res.end('Too Many Requests');
        return;
    }
    
    // 2. Cek User Agent (Bot Detection)
    const userAgent = req.headers['user-agent'];
    if (isBot(userAgent)) {
        // Redirect ke halaman honeypot atau beri respons palsu
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end('<html><body><p>Ini adalah konten untuk bot</p></body></html>');
        return;
    }
    
    // 3. Cek Referer (optional)
    const referer = req.headers['referer'] || '';
    // Hanya izinkan akses dari domain sendiri
    if (referer && !referer.includes(`localhost:${PORT}`) && !referer.includes('127.0.0.1')) {
        res.writeHead(403);
        res.end('Access Denied');
        return;
    }
    
    // Serve file
    let filePath = path.join(__dirname, 'public', req.url === '/' ? 'index.html' : req.url);
    const ext = path.extname(filePath);
    
    // Untuk file HTML, berikan perlindungan ekstra
    if (ext === '.html') {
        fs.readFile(filePath, 'utf8', (err, data) => {
            if (err) {
                res.writeHead(404);
                res.end('404 - File tidak ditemukan');
                return;
            }
            
            // Enkripsi konten HTML
            const encryptedData = encryptHTML(data);
            
            // Kirim HTML dengan script dekripsi
            const protectedHTML = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Protected Content</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background: #f0f0f0;
        }
        .loading {
            text-align: center;
            padding: 20px;
        }
        .loader {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #3498db;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 0 auto;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .content {
            display: none;
        }
    </style>
</head>
<body>
    <div id="loading" class="loading">
        <div class="loader"></div>
        <p>Decrypting content...</p>
    </div>
    <div id="content" class="content"></div>

    <script>
        // Kunci dan IV akan diambil dari server
        const encryptedData = '${encryptedData.encrypted}';
        const key = '${encryptedData.key}';
        const iv = '${encryptedData.iv}';
        
        // Fungsi dekripsi
        async function decryptContent(encrypted, key, iv) {
            try {
                // Hanya bisa diakses dari browser dengan JavaScript
                if (typeof window === 'undefined') {
                    throw new Error('Not a browser environment');
                }
                
                // Cek apakah ada tool developer terbuka
                const startTime = performance.now();
                debugger;
                const endTime = performance.now();
                if (endTime - startTime > 100) {
                    // Detected debugging
                    document.body.innerHTML = '<h1>Access Denied</h1><p>Developer tools detected</p>';
                    return;
                }
                
                // Decrypt menggunakan Web Crypto API
                const keyBuffer = new Uint8Array(key.match(/.{1,2}/g).map(byte => parseInt(byte, 16)));
                const ivBuffer = new Uint8Array(iv.match(/.{1,2}/g).map(byte => parseInt(byte, 16)));
                const encryptedBuffer = new Uint8Array(encrypted.match(/.{1,2}/g).map(byte => parseInt(byte, 16)));
                
                const cryptoKey = await crypto.subtle.importKey(
                    'raw',
                    keyBuffer,
                    { name: 'AES-CBC' },
                    false,
                    ['decrypt']
                );
                
                const decrypted = await crypto.subtle.decrypt(
                    { name: 'AES-CBC', iv: ivBuffer },
                    cryptoKey,
                    encryptedBuffer
                );
                
                const decoder = new TextDecoder();
                return decoder.decode(decrypted);
            } catch (error) {
                console.error('Decryption failed:', error);
                return null;
            }
        }
        
        // Load dan decrypt content
        decryptContent(encryptedData, key, iv).then(html => {
            if (html) {
                document.getElementById('loading').style.display = 'none';
                document.getElementById('content').style.display = 'block';
                document.getElementById('content').innerHTML = html;
            } else {
                document.getElementById('loading').innerHTML = '<h1>Access Denied</h1><p>Unable to decrypt content</p>';
            }
        });
    </script>
</body>
</html>
            `;
            
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(protectedHTML);
        });
    } else {
        // Untuk file non-HTML (CSS, JS, gambar), serve normal
        fs.readFile(filePath, (err, data) => {
            if (err) {
                res.writeHead(404);
                res.end('404 - File tidak ditemukan');
                return;
            }
            
            const mimeTypes = {
                '.css': 'text/css',
                '.js': 'application/javascript',
                '.png': 'image/png',
                '.jpg': 'image/jpeg',
                '.gif': 'image/gif',
                '.svg': 'image/svg+xml'
            };
            
            const contentType = mimeTypes[ext] || 'application/octet-stream';
            res.writeHead(200, { 'Content-Type': contentType });
            res.end(data);
        });
    }
});

server.listen(PORT, () => {
    console.log(`Server: http://localhost:${PORT}`);
});

// Buka browser otomatis
const { exec } = require('child_process');
const os = require('os');
const platform = os.platform();

if (platform === 'win32') {
    exec(`start http://localhost:${PORT}`);
} else if (platform === 'darwin') {
    exec(`open http://localhost:${PORT}`);
} else {
    exec(`xdg-open http://localhost:${PORT}`);
}