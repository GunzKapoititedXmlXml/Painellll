// config.js
const config = {
    baseURL: 'http://chatprivat.xonepanel.qzz.io',
    port: 9988,
    apiPath: '/api/ranking',
    encryptionPassword: 'IQTest2026SecurePassword!@#$%^&*()_+'
};

module.exports = config;