// config.js
const config = {
    baseURL: 'http://testiq.xonepanel.qzz.io',
    port: 9000,
    apiPath: '/api/tokens-imdyi82tsntakfAhrektdbyrhfw8eu/test/iq/test/iq/ranking'
};

module.exports = config;