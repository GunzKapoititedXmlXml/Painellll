// config.js
const config = {
    baseURL: 'http://testiq.xonepanel.qzz.io',
    port: 9000,
    apiPath: '/api/ranking',
    encryptionPassword: 'IQTest2026SecurePassword!@#$%^&*()_+'
};

module.exports = config;