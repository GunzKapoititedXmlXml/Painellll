// config.js
const config = {
    baseURL: 'http://localhost:9000',
    port: 9000,
    apiPath: '/api/ranking',
    encryptionPassword: 'IQTest2026SecurePassword!@#$%^&*()_+'
};

module.exports = config;