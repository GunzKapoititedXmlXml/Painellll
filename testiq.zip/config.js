// config.js
// Konfigurasi global untuk aplikasi IQ Test

const CONFIG = {
    // ===== STORAGE =====
    STORAGE_KEY: 'iq_ranking_data',
    USER_SESSION_KEY: 'iq_current_user',
    
    // ===== SOAL =====
    TOTAL_QUESTIONS: 35,
    
    // ===== API =====
    // Untuk development (server local)
    API_BASE_URL: '/api',
    
    // Untuk production (ganti dengan domain Anda)
    // API_BASE_URL: 'https://api.domainanda.com/api',
    
    // ===== SERTIFIKAT =====
    CERTIFICATE: {
        DIRECTOR_NAME: 'Dr. Alexander Mitchell',
        DIRECTOR_TITLE: 'Director of Cognitive Assessment',
        ORGANIZATION: 'International IQ Test'
    },
    
    // ===== RANKING =====
    RANKING: {
        MAX_USERS: 1000,
        MIN_IQ: 50,
        MAX_IQ: 150
    },
    
    // ===== CHEAT DETECTION =====
    CHEAT: {
        MAX_TAB_SWITCHES: 2,
        MAX_WINDOW_RESIZE: 200
    }
};

// Export untuk penggunaan
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CONFIG;
}