// config.js
const config = {
    baseURL: 'http://localhost:9000',
    port: 9000,
    apiPath: '/api/tokens-imdyi82tsntakfAhrektdbyrhfw8eu/test/iq/test/iq/ranking'
};

module.exports = config;