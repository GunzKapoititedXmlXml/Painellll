// ============================================================
// BANK SOAL IQ TEST - TANPA API KEY
// ============================================================

const BANK_SOAL = [
  // ========== MATEMATIKA ==========
  {
    id: 1,
    mataPelajaran: "Matematika",
    tingkat: "Mudah",
    question: "Berapakah hasil dari 25 + 37?",
    options: ["52", "62", "72", "82"],
    answer: "62"
  },
  {
    id: 2,
    mataPelajaran: "Matematika",
    tingkat: "Mudah",
    question: "Jika 5x = 25, berapakah nilai x?",
    options: ["3", "4", "5", "6"],
    answer: "5"
  },
  {
    id: 3,
    mataPelajaran: "Matematika",
    tingkat: "Sedang",
    question: "Berapakah hasil dari 144 ÷ 12?",
    options: ["10", "12", "14", "16"],
    answer: "12"
  },
  {
    id: 4,
    mataPelajaran: "Matematika",
    tingkat: "Sedang",
    question: "Jika 3x + 7 = 22, berapakah nilai x?",
    options: ["3", "5", "7", "9"],
    answer: "5"
  },
  {
    id: 5,
    mataPelajaran: "Matematika",
    tingkat: "Sulit",
    question: "Berapakah akar kuadrat dari 196?",
    options: ["12", "13", "14", "15"],
    answer: "14"
  },
  {
    id: 6,
    mataPelajaran: "Matematika",
    tingkat: "Sulit",
    question: "Jika 2x² + 8x + 6 = 0, berapakah nilai x?",
    options: ["-1 atau -3", "-2 atau -4", "1 atau 3", "2 atau 4"],
    answer: "-1 atau -3"
  },
  {
    id: 7,
    mataPelajaran: "Matematika",
    tingkat: "Tersulit",
    question: "Berapakah hasil dari 2^10?",
    options: ["512", "1024", "2048", "4096"],
    answer: "1024"
  },
  {
    id: 8,
    mataPelajaran: "Matematika",
    tingkat: "Tersulit",
    question: "Jika f(x) = 2x² - 3x + 1, berapakah f(3)?",
    options: ["8", "10", "12", "14"],
    answer: "10"
  },

  // ========== LOGIKA ==========
  {
    id: 9,
    mataPelajaran: "Logika",
    tingkat: "Mudah",
    question: "Semua kucing adalah hewan. Semua hewan bernyawa. Maka...",
    options: ["Semua kucing bernyawa", "Semua hewan adalah kucing", "Kucing tidak bernyawa", "Tidak ada kesimpulan"],
    answer: "Semua kucing bernyawa"
  },
  {
    id: 10,
    mataPelajaran: "Logika",
    tingkat: "Mudah",
    question: "Jika A = B dan B = C, maka...",
    options: ["A = C", "A ≠ C", "B ≠ C", "Tidak ada kesimpulan"],
    answer: "A = C"
  },
  {
    id: 11,
    mataPelajaran: "Logika",
    tingkat: "Sedang",
    question: "Semua mahasiswa pandai. Beberapa pandai adalah penulis. Maka...",
    options: ["Semua mahasiswa adalah penulis", "Beberapa mahasiswa adalah penulis", "Semua penulis adalah mahasiswa", "Tidak ada kesimpulan"],
    answer: "Beberapa mahasiswa adalah penulis"
  },
  {
    id: 12,
    mataPelajaran: "Logika",
    tingkat: "Sedang",
    question: "Jika hari ini hujan, maka jalanan basah. Jalanan tidak basah. Maka...",
    options: ["Hari ini hujan", "Hari ini tidak hujan", "Jalanan kering", "Tidak ada kesimpulan"],
    answer: "Hari ini tidak hujan"
  },
  {
    id: 13,
    mataPelajaran: "Logika",
    tingkat: "Sulit",
    question: "Semua politikus adalah pembohong. Beberapa pembohong adalah pencuri. Maka...",
    options: ["Semua politikus adalah pencuri", "Beberapa politikus adalah pencuri", "Semua pencuri adalah politikus", "Tidak ada kesimpulan"],
    answer: "Tidak ada kesimpulan"
  },
  {
    id: 14,
    mataPelajaran: "Logika",
    tingkat: "Sulit",
    question: "Jika P → Q dan Q → R, maka...",
    options: ["P → R", "R → P", "P ↔ R", "Tidak ada kesimpulan"],
    answer: "P → R"
  },
  {
    id: 15,
    mataPelajaran: "Logika",
    tingkat: "Tersulit",
    question: "Semua manusia akan mati. Socrates adalah manusia. Maka...",
    options: ["Socrates akan mati", "Socrates tidak akan mati", "Socrates adalah dewa", "Tidak ada kesimpulan"],
    answer: "Socrates akan mati"
  },
  {
    id: 16,
    mataPelajaran: "Logika",
    tingkat: "Tersulit",
    question: "Jika A > B dan B > C, maka hubungan A dan C adalah...",
    options: ["A > C", "A < C", "A = C", "Tidak bisa ditentukan"],
    answer: "A > C"
  },

  // ========== BAHASA INDONESIA ==========
  {
    id: 17,
    mataPelajaran: "Bahasa Indonesia",
    tingkat: "Mudah",
    question: "Sinonim dari kata 'cerdas' adalah...",
    options: ["Pandai", "Bodoh", "Malas", "Rajin"],
    answer: "Pandai"
  },
  {
    id: 18,
    mataPelajaran: "Bahasa Indonesia",
    tingkat: "Mudah",
    question: "Antonim dari kata 'besar' adalah...",
    options: ["Kecil", "Tinggi", "Panjang", "Lebar"],
    answer: "Kecil"
  },
  {
    id: 19,
    mataPelajaran: "Bahasa Indonesia",
    tingkat: "Sedang",
    question: "Kalimat yang tepat adalah...",
    options: ["Saya pergi ke sekolah", "Saya pergi kesekolah", "Saya pergi kesekolah", "Saya pergi ke sekolah"],
    answer: "Saya pergi ke sekolah"
  },
  {
    id: 20,
    mataPelajaran: "Bahasa Indonesia",
    tingkat: "Sedang",
    question: "Makna kata 'berpacu' adalah...",
    options: ["Berlari cepat", "Berkompetisi", "Berjalan lambat", "Berdiam diri"],
    answer: "Berkompetisi"
  },
  {
    id: 21,
    mataPelajaran: "Bahasa Indonesia",
    tingkat: "Sulit",
    question: "Kalimat pasif dari 'Ibu memasak nasi' adalah...",
    options: ["Nasi dimasak oleh Ibu", "Ibu memasak nasi", "Nasi sedang dimasak", "Ibu menanak nasi"],
    answer: "Nasi dimasak oleh Ibu"
  },
  {
    id: 22,
    mataPelajaran: "Bahasa Indonesia",
    tingkat: "Sulit",
    question: "Sinonim dari kata 'abstrak' adalah...",
    options: ["Konkret", "Nyata", "Teoretis", "Fisik"],
    answer: "Teoretis"
  },
  {
    id: 23,
    mataPelajaran: "Bahasa Indonesia",
    tingkat: "Tersulit",
    question: "Makna kata 'kronologi' adalah...",
    options: ["Urutan waktu", "Urutan tempat", "Urutan kejadian", "Urutan sebab-akibat"],
    answer: "Urutan waktu"
  },
  {
    id: 24,
    mataPelajaran: "Bahasa Indonesia",
    tingkat: "Tersulit",
    question: "Antonim dari kata 'kontemporer' adalah...",
    options: ["Modern", "Kuno", "Masa kini", "Tradisional"],
    answer: "Kuno"
  },

  // ========== SAINS ==========
  {
    id: 25,
    mataPelajaran: "Sains",
    tingkat: "Mudah",
    question: "Apa yang dimaksud dengan fotosintesis?",
    options: ["Proses makan tumbuhan", "Proses tumbuhan membuat makanan", "Proses tumbuhan bernapas", "Proses tumbuhan berkembang biak"],
    answer: "Proses tumbuhan membuat makanan"
  },
  {
    id: 26,
    mataPelajaran: "Sains",
    tingkat: "Mudah",
    question: "Air membeku pada suhu...",
    options: ["0°C", "100°C", "32°C", "212°C"],
    answer: "0°C"
  },
  {
    id: 27,
    mataPelajaran: "Sains",
    tingkat: "Sedang",
    question: "Apa yang menyebabkan terjadinya siang dan malam?",
    options: ["Revolusi bumi", "Rotasi bumi", "Gravitasi bumi", "Atmosfer bumi"],
    answer: "Rotasi bumi"
  },
  {
    id: 28,
    mataPelajaran: "Sains",
    tingkat: "Sedang",
    question: "Organ yang berfungsi memompa darah adalah...",
    options: ["Paru-paru", "Jantung", "Hati", "Ginjal"],
    answer: "Jantung"
  },
  {
    id: 29,
    mataPelajaran: "Sains",
    tingkat: "Sulit",
    question: "Hukum kekekalan energi menyatakan bahwa...",
    options: ["Energi dapat diciptakan", "Energi dapat dimusnahkan", "Energi tidak dapat diciptakan atau dimusnahkan", "Energi selalu berkurang"],
    answer: "Energi tidak dapat diciptakan atau dimusnahkan"
  },
  {
    id: 30,
    mataPelajaran: "Sains",
    tingkat: "Sulit",
    question: "Apa yang dimaksud dengan evolusi?",
    options: ["Perubahan spesies seiring waktu", "Kepunahan spesies", "Perubahan iklim", "Bencana alam"],
    answer: "Perubahan spesies seiring waktu"
  },
  {
    id: 31,
    mataPelajaran: "Sains",
    tingkat: "Tersulit",
    question: "Apa yang dimaksud dengan 'black hole'?",
    options: ["Lubang hitam di angkasa", "Bintang yang sangat terang", "Planet baru", "Galaksi jauh"],
    answer: "Lubang hitam di angkasa"
  },
  {
    id: 32,
    mataPelajaran: "Sains",
    tingkat: "Tersulit",
    question: "Siapa yang menemukan hukum gravitasi?",
    options: ["Albert Einstein", "Isaac Newton", "Galileo Galilei", "Nikola Tesla"],
    answer: "Isaac Newton"
  },

  // ========== PENGETAHUAN UMUM ==========
  {
    id: 33,
    mataPelajaran: "Pengetahuan Umum",
    tingkat: "Mudah",
    question: "Ibu kota Indonesia adalah...",
    options: ["Jakarta", "Surabaya", "Bandung", "Medan"],
    answer: "Jakarta"
  },
  {
    id: 34,
    mataPelajaran: "Pengetahuan Umum",
    tingkat: "Mudah",
    question: "Lambang negara Indonesia adalah...",
    options: ["Garuda Pancasila", "Banteng", "Komodo", "Rafflesia"],
    answer: "Garuda Pancasila"
  },
  {
    id: 35,
    mataPelajaran: "Pengetahuan Umum",
    tingkat: "Sedang",
    question: "Siapa presiden pertama Indonesia?",
    options: ["Soekarno", "Soeharto", "Habibie", "Gus Dur"],
    answer: "Soekarno"
  },
  {
    id: 36,
    mataPelajaran: "Pengetahuan Umum",
    tingkat: "Sedang",
    question: "Benua terbesar di dunia adalah...",
    options: ["Asia", "Afrika", "Amerika", "Eropa"],
    answer: "Asia"
  },
  {
    id: 37,
    mataPelajaran: "Pengetahuan Umum",
    tingkat: "Sulit",
    question: "Sungai terpanjang di dunia adalah...",
    options: ["Amazon", "Nil", "Mississippi", "Yangtze"],
    answer: "Nil"
  },
  {
    id: 38,
    mataPelajaran: "Pengetahuan Umum",
    tingkat: "Sulit",
    question: "Gunung tertinggi di dunia adalah...",
    options: ["Everest", "Kilimanjaro", "Fuji", "Himalaya"],
    answer: "Everest"
  },
  {
    id: 39,
    mataPelajaran: "Pengetahuan Umum",
    tingkat: "Tersulit",
    question: "Apa yang dimaksud dengan 'demokrasi'?",
    options: ["Pemerintahan oleh rakyat", "Pemerintahan oleh raja", "Pemerintahan oleh militer", "Pemerintahan oleh agama"],
    answer: "Pemerintahan oleh rakyat"
  },
  {
    id: 40,
    mataPelajaran: "Pengetahuan Umum",
    tingkat: "Tersulit",
    question: "Siapa penemu benua Amerika?",
    options: ["Christopher Columbus", "Vasco da Gama", "Ferdinand Magellan", "Amerigo Vespucci"],
    answer: "Christopher Columbus"
  }
];

// ============================================================
// FUNGSI UNTUK MENGAMBIL SOAL ACAK
// ============================================================

function getRandomQuestions(jumlah = 35) {
    // Acak urutan soal
    const shuffled = [...BANK_SOAL].sort(() => Math.random() - 0.5);
    
    // Ambil sejumlah yang diminta
    const selected = shuffled.slice(0, jumlah);
    
    // Jika kurang dari jumlah yang diminta, tambahkan dari awal
    if (selected.length < jumlah) {
        const tambahan = BANK_SOAL.slice(0, jumlah - selected.length);
        return [...selected, ...tambahan];
    }
    
    return selected;
}

// Export untuk digunakan di HTML
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { BANK_SOAL, getRandomQuestions };
}