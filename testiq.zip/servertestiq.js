// server.js
// Backend server untuk menyimpan data ranking + Serve HTML

const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 9000;

// ========== MIDDLEWARE ==========
app.use(cors({
    origin: 'http://testiq.xonepanel.qzz.io', // Ganti dengan domain Anda
    methods: ['GET', 'POST', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type']
}));
app.use(express.json());

// ========== SERVE STATIC FILES ==========
// Sajikan semua file di folder yang sama dengan server.js
app.use(express.static(__dirname));

// ========== FILE STORAGE ==========
const DATA_FILE = path.join(__dirname, 'ranking.json');

// Inisialisasi file data
function initDataFile() {
    if (!fs.existsSync(DATA_FILE)) {
        fs.writeFileSync(DATA_FILE, JSON.stringify({ users: [] }, null, 2));
        console.log('✅ File ranking.json created');
    }
}
initDataFile();

// Fungsi baca data
function readData() {
    try {
        const raw = fs.readFileSync(DATA_FILE, 'utf8');
        return JSON.parse(raw);
    } catch (error) {
        console.error('Error reading data file:', error);
        return { users: [] };
    }
}

// Fungsi tulis data
function writeData(data) {
    try {
        fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
        return true;
    } catch (error) {
        console.error('Error writing data file:', error);
        return false;
    }
}

// ========== ROUTES API ==========

/**
 * GET /api/ranking
 * Mendapatkan semua data ranking (sorted by IQ descending)
 */
app.get('/api/ranking', (req, res) => {
    try {
        const data = readData();
        const sorted = [...data.users].sort((a, b) => b.iq - a.iq);
        res.json({
            success: true,
            data: sorted,
            total: sorted.length
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

/**
 * POST /api/ranking
 * Menambah atau update data user
 * Body: { name, iq, correct, total, time, category }
 */
app.post('/api/ranking', (req, res) => {
    try {
        const { name, iq, correct, total, time, category } = req.body;

        // Validasi
        if (!name || iq === undefined || correct === undefined) {
            return res.status(400).json({
                success: false,
                message: 'Data tidak lengkap'
            });
        }

        const data = readData();
        const existingIndex = data.users.findIndex(
            u => u.name.toLowerCase() === name.toLowerCase()
        );

        const userData = {
            name: name.trim(),
            iq: Number(iq),
            correct: Number(correct),
            total: Number(total),
            time: time || '00:00',
            category: category || 'Tidak Diketahui',
            date: new Date().toISOString()
        };

        if (existingIndex !== -1) {
            // Update existing user
            data.users[existingIndex] = {
                ...data.users[existingIndex],
                ...userData
            };
            console.log(`🔄 Update user: ${name} | IQ: ${iq}`);
        } else {
            // Add new user
            data.users.push(userData);
            console.log(`✅ User baru: ${name} | IQ: ${iq}`);
        }

        if (writeData(data)) {
            res.json({
                success: true,
                message: 'Data berhasil disimpan',
                data: userData
            });
        } else {
            res.status(500).json({
                success: false,
                message: 'Gagal menyimpan data'
            });
        }
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

/**
 * GET /api/ranking/search
 * Mencari user berdasarkan nama
 * Query: ?name=John
 */
app.get('/api/ranking/search', (req, res) => {
    try {
        const { name } = req.query;
        if (!name) {
            return res.status(400).json({
                success: false,
                message: 'Parameter name diperlukan'
            });
        }

        const data = readData();
        const users = data.users.filter(
            u => u.name.toLowerCase().includes(name.toLowerCase())
        );

        res.json({
            success: true,
            data: users
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

/**
 * GET /api/ranking/stats
 * Mendapatkan statistik ranking
 */
app.get('/api/ranking/stats', (req, res) => {
    try {
        const data = readData();
        const users = data.users;

        if (users.length === 0) {
            return res.json({
                success: true,
                data: {
                    total: 0,
                    highestIQ: 0,
                    averageIQ: 0,
                    lowestIQ: 0,
                    totalUsers: 0
                }
            });
        }

        const iqs = users.map(u => u.iq);
        const highestIQ = Math.max(...iqs);
        const lowestIQ = Math.min(...iqs);
        const averageIQ = Math.round(iqs.reduce((a, b) => a + b, 0) / iqs.length);

        res.json({
            success: true,
            data: {
                total: users.length,
                highestIQ,
                averageIQ,
                lowestIQ,
                totalUsers: users.length
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

/**
 * DELETE /api/ranking/clear
 * Menghapus semua data (admin only)
 */
app.delete('/api/ranking/clear', (req, res) => {
    try {
        // Tambahkan autentikasi di sini jika diperlukan
        // const { adminKey } = req.body;
        // if (adminKey !== 'your-secret-key') {
        //     return res.status(401).json({ success: false, message: 'Unauthorized' });
        // }

        if (writeData({ users: [] })) {
            console.log('🗑️ Semua data ranking dihapus');
            res.json({
                success: true,
                message: 'Semua data berhasil dihapus'
            });
        } else {
            res.status(500).json({
                success: false,
                message: 'Gagal menghapus data'
            });
        }
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

// ========== ROOT - SERVE HTML ==========
app.get('/', (req, res) => {
    // Cari file HTML utama di folder yang sama
    const htmlFiles = ['index.html', 'iqtest.html', 'main.html', 'test.html'];
    let found = false;
    
    for (const file of htmlFiles) {
        const filePath = path.join(__dirname, file);
        if (fs.existsSync(filePath)) {
            res.sendFile(filePath);
            found = true;
            console.log(`📄 Serving: ${file}`);
            break;
        }
    }
    
    if (!found) {
        // Jika tidak ada file HTML, tampilkan JSON API info
        res.json({
            name: 'IQ Test Ranking API',
            version: '1.0.0',
            message: 'Server berjalan. HTML file tidak ditemukan di folder ini.',
            instructions: 'Letakkan file HTML Anda di folder yang sama dengan server.js',
            endpoints: {
                ranking: '/api/ranking',
                stats: '/api/ranking/stats',
                search: '/api/ranking/search?name=John',
                clear: '/api/ranking/clear (DELETE)'
            }
        });
    }
});

// ========== ERROR HANDLING ==========
app.use((err, req, res, next) => {
    console.error('Server error:', err);
    res.status(500).json({
        success: false,
        message: 'Terjadi kesalahan pada server'
    });
});

// ========== START SERVER ==========
app.listen(PORT, () => {
    console.log(`\n╔══════════════════════════════════════════╗`);
    console.log(`║   🚀 IQ TEST RANKING SERVER           ║`);
    console.log(`╠══════════════════════════════════════════╣`);
    console.log(`║   🌐 http://localhost:${PORT}             ║`);
    console.log(`║   📁 Data: ${DATA_FILE}`);
    console.log(`╚══════════════════════════════════════════╝\n`);
    console.log(`📋 API Endpoints:`);
    console.log(`   GET  /api/ranking          - Lihat semua ranking`);
    console.log(`   POST /api/ranking          - Tambah/update user`);
    console.log(`   GET  /api/ranking/stats    - Statistik ranking`);
    console.log(`   GET  /api/ranking/search   - Cari user`);
    console.log(`   DELETE /api/ranking/clear  - Hapus semua data`);
    console.log(`\n📄 Buka browser: http://localhost:${PORT}\n`);
});