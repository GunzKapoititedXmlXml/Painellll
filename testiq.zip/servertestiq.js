// servertestiq.js
const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

// ========== LOAD CONFIG ==========
const config = require('./config.js');

const app = express();
const PORT = config.port;
const BASE_URL = config.baseURL;

// ========== MIDDLEWARE ==========
// CORS - DI SET AGAR BISA DIAKSES DARI MANA SAJA
app.use(cors({
    origin: '*',
    methods: ['GET', 'POST', 'DELETE', 'PUT', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json());

// ========== LOG REQUEST (Debugging) ==========
app.use((req, res, next) => {
    console.log(`📥 ${req.method} ${req.url}`);
    console.log(`   Origin: ${req.headers.origin || 'none'}`);
    console.log(`   Referer: ${req.headers.referer || 'none'}`);
    next();
});

// ========== BLOCK SENSITIVE FILES ==========
app.use((req, res, next) => {
    const blockedFiles = [
        'package.json',
        'package-lock.json',
        'server.js',
        'servertestiq.js',
        '.env',
        '.gitignore',
        'README.md',
        'nodemon.json',
        'tsconfig.json',
        '.eslintrc.js',
        '.prettierrc',
        'yarn.lock'
    ];
    
    const requestedPath = req.path;
    const requestedFile = path.basename(requestedPath);
    
    if (blockedFiles.includes(requestedFile) || 
        requestedPath.includes('node_modules') ||
        requestedPath.includes('.git')) {
        console.log(`🚫 Blocked access to: ${requestedPath}`);
        return res.status(403).json({
            success: false,
            message: 'Access denied to this file'
        });
    }
    
    const blockedExtensions = ['.env', '.lock', '.log', '.key', '.pem', '.crt'];
    const ext = path.extname(requestedPath);
    if (blockedExtensions.includes(ext) && !requestedPath.includes('/api/')) {
        return res.status(403).json({
            success: false,
            message: 'Access denied to this file type'
        });
    }
    
    next();
});

// ========== PROTECTED PATH MIDDLEWARE ==========
const PROTECTED_PATH = '/tokens-imdyi82tsntakfAhrektdbyrhfw8eu/test/iq/test/iq';

app.use(PROTECTED_PATH, (req, res, next) => {
    if (req.path.includes('/api/') || req.path.includes('/ranking')) {
        return next();
    }
    
    const referer = req.headers.referer || '';
    const origin = req.headers.origin || '';
    
    // CEK DARI DOMAIN PUBLIK ATAU LOCALHOST
    const isFromDashboard = 
        referer.includes('http://testiq.xonepanel.qzz.io') ||
        referer.includes('https://testiq.xonepanel.qzz.io') ||
        referer.includes('http://localhost:9000') ||
        referer.includes('http://localhost:5500') ||
        origin.includes('testiq.xonepanel.qzz.io') ||
        origin.includes('localhost');
    
    const fromButton = req.query.from === 'dashboard';
    
    if (isFromDashboard || fromButton) {
        console.log(`✅ Access granted from dashboard: ${req.path}`);
        return next();
    }
    
    console.log(`🔄 Direct access blocked: ${req.path} (Referer: ${referer || 'none'})`);
    return res.redirect(301, '/');
});

// ========== SERVE STATIC FILES ==========
app.use(express.static(__dirname, {
    setHeaders: (res, filePath) => {
        const allowedExtensions = ['.html', '.htm', '.css', '.js', '.png', '.jpg', '.jpeg', '.gif', '.svg', '.ico', '.webp', '.woff', '.woff2', '.ttf', '.eot'];
        const ext = path.extname(filePath);
        if (!allowedExtensions.includes(ext)) {
            res.removeHeader('Content-Disposition');
        }
    }
}));

// ========== FILE STORAGE ==========
const DATA_FILE = path.join(__dirname, 'tokens-imdyi82tsntakfAhrektdbyrhfw8eu/test/iq/test/iq/ranking.json');

function initDataFile() {
    const dir = path.dirname(DATA_FILE);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
        console.log('✅ Folder data created');
    }
    if (!fs.existsSync(DATA_FILE)) {
        fs.writeFileSync(DATA_FILE, JSON.stringify({ users: [] }, null, 2));
        console.log('✅ File ranking.json created');
    }
}
initDataFile();

function readData() {
    try {
        const raw = fs.readFileSync(DATA_FILE, 'utf8');
        return JSON.parse(raw);
    } catch (error) {
        console.error('Error reading data file:', error);
        return { users: [] };
    }
}

function writeData(data) {
    try {
        fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
        return true;
    } catch (error) {
        console.error('Error writing data file:', error);
        return false;
    }
}

// ========== ROUTES API ==========
app.get(config.apiPath, (req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    try {
        const data = readData();
        const sorted = [...data.users].sort((a, b) => b.iq - a.iq);
        res.json({
            success: true,
            data: sorted,
            total: sorted.length
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

app.post(config.apiPath, (req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    try {
        const { name, iq, correct, total, time, category } = req.body;

        if (!name || iq === undefined || correct === undefined) {
            return res.status(400).json({
                success: false,
                message: 'Data tidak lengkap'
            });
        }

        const data = readData();
        const existingIndex = data.users.findIndex(
            u => u.name.toLowerCase() === name.toLowerCase()
        );

        const userData = {
            name: name.trim(),
            iq: Number(iq),
            correct: Number(correct),
            total: Number(total) || 10,
            time: time || '00:00',
            category: category || 'Tidak Diketahui',
            date: new Date().toISOString()
        };

        if (existingIndex !== -1) {
            data.users[existingIndex] = {
                ...data.users[existingIndex],
                ...userData
            };
            console.log(`🔄 Update user: ${name} | IQ: ${iq}`);
        } else {
            data.users.push(userData);
            console.log(`✅ User baru: ${name} | IQ: ${iq}`);
        }

        if (writeData(data)) {
            res.json({
                success: true,
                message: 'Data berhasil disimpan',
                data: userData
            });
        } else {
            res.status(500).json({
                success: false,
                message: 'Gagal menyimpan data'
            });
        }
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

app.get(`${config.apiPath}/search`, (req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    try {
        const { name } = req.query;
        if (!name) {
            return res.status(400).json({
                success: false,
                message: 'Parameter name diperlukan'
            });
        }

        const data = readData();
        const users = data.users.filter(
            u => u.name.toLowerCase().includes(name.toLowerCase())
        );

        res.json({
            success: true,
            data: users
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

app.get(`${config.apiPath}/stats`, (req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    try {
        const data = readData();
        const users = data.users;

        if (users.length === 0) {
            return res.json({
                success: true,
                data: {
                    total: 0,
                    highestIQ: 0,
                    averageIQ: 0,
                    lowestIQ: 0,
                    totalUsers: 0
                }
            });
        }

        const iqs = users.map(u => u.iq);
        const highestIQ = Math.max(...iqs);
        const lowestIQ = Math.min(...iqs);
        const averageIQ = Math.round(iqs.reduce((a, b) => a + b, 0) / iqs.length);

        res.json({
            success: true,
            data: {
                total: users.length,
                highestIQ,
                averageIQ,
                lowestIQ,
                totalUsers: users.length
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

app.delete(`${config.apiPath}/clear`, (req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    try {
        if (writeData({ users: [] })) {
            console.log('🗑️ Semua data ranking dihapus');
            res.json({
                success: true,
                message: 'Semua data berhasil dihapus'
            });
        } else {
            res.status(500).json({
                success: false,
                message: 'Gagal menghapus data'
            });
        }
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

// ========== ROOT - SERVE HTML ==========
app.get('/', (req, res) => {
    const searchDirs = [
        __dirname,
        path.join(__dirname, 'dashboard'),
        path.join(__dirname, 'tokens-imdyi82tsntakfAhrektdbyrhfw8eu/test'),
        path.join(__dirname, 'tokens-imdyi82tsntakfAhrektdbyrhfw8eu/test/iq'),
        path.join(__dirname, 'tokens-imdyi82tsntakfAhrektdbyrhfw8eu/test/iq/test'),
        path.join(__dirname, 'tokens-imdyi82tsntakfAhrektdbyrhfw8eu/test/iq/test/iq')
    ];
    
    const htmlFiles = [
        'index.html',
        'index.htm',
        'main.html',
        'test.html',
        'dashboard.html',
        'iqtest.htm'
    ];
    
    let found = false;
    
    for (const dir of searchDirs) {
        if (!fs.existsSync(dir)) continue;
        
        for (const file of htmlFiles) {
            const filePath = path.join(dir, file);
            if (fs.existsSync(filePath)) {
                res.sendFile(filePath);
                found = true;
                console.log(`📄 Serving: ${path.relative(__dirname, filePath)}`);
                break;
            }
        }
        if (found) break;
    }
    
    if (!found) {
        res.json({
            name: 'IQ Test Ranking API',
            version: '1.0.0',
            message: 'Server berjalan. Tidak ada file HTML yang ditemukan.',
            endpoints: {
                ranking: config.apiPath,
                stats: `${config.apiPath}/stats`,
                search: `${config.apiPath}/search?name=John`,
                clear: `${config.apiPath}/clear (DELETE)`
            }
        });
    }
});

// ========== 404 HANDLER ==========
app.use((req, res) => {
    res.status(404).json({
        success: false,
        message: 'Resource tidak ditemukan'
    });
});

// ========== ERROR HANDLING ==========
app.use((err, req, res, next) => {
    console.error('Server error:', err);
    res.status(500).json({
        success: false,
        message: 'Terjadi kesalahan pada server'
    });
});

// ========== START SERVER ==========
app.listen(PORT, '0.0.0.0', () => {
    console.log(`\n╔══════════════════════════════════════════╗`);
    console.log(`║   🚀 IQ TEST RANKING SERVER             ║`);
    console.log(`╠══════════════════════════════════════════╣`);
    console.log(`║   🌐 ${BASE_URL}             ║`);
    console.log(`║   📁 Data: ${DATA_FILE}`);
    console.log(`╚══════════════════════════════════════════╝\n`);
    console.log(`📋 API Endpoints:`);
    console.log(`   GET  ${config.apiPath}          - Lihat semua ranking`);
    console.log(`   POST ${config.apiPath}          - Tambah/update user`);
    console.log(`   GET  ${config.apiPath}/stats    - Statistik ranking`);
    console.log(`   GET  ${config.apiPath}/search   - Cari user`);
    console.log(`   DELETE ${config.apiPath}/clear  - Hapus semua data`);
    console.log(`\n📄 Buka browser: ${BASE_URL}\n`);
    console.log(`🔒 Security: File sensitif diblokir`);
    console.log(`🔐 Protected: ${PROTECTED_PATH} (hanya via tombol)`);
    console.log(`📁 Serving files from: ${__dirname}\n`);
});