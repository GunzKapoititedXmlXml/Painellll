// server.js
const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// ========== LOAD CONFIG ==========
const config = require('./config.js');

const app = express();
const PORT = config.port;
const BASE_URL = config.baseURL;

// ========== MIDDLEWARE ==========
app.use(cors({
    origin: '*',
    methods: ['GET', 'POST', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type']
}));
app.use(express.json());

// ========== BLOCK SENSITIVE FILES ==========
app.use((req, res, next) => {
    const blockedFiles = [
        'package.json',
        'package-lock.json',
        'server.js',
        'servertestiq.js',
        '.env',
        '.gitignore',
        'README.md',
        'nodemon.json',
        'tsconfig.json',
        '.eslintrc.js',
        '.prettierrc',
        'yarn.lock'
    ];
    
    const requestedPath = req.path;
    const requestedFile = path.basename(requestedPath);
    
    if (blockedFiles.includes(requestedFile) || 
        requestedPath.includes('node_modules') ||
        requestedPath.includes('.git')) {
        console.log(`🚫 Blocked access to: ${requestedPath}`);
        return res.status(403).json({
            success: false,
            message: 'Access denied to this file'
        });
    }
    
    const blockedExtensions = ['.env', '.lock', '.log', '.key', '.pem', '.crt'];
    const ext = path.extname(requestedPath);
    if (blockedExtensions.includes(ext) && !requestedPath.includes('/api/')) {
        return res.status(403).json({
            success: false,
            message: 'Access denied to this file type'
        });
    }
    
    next();
});

// ========== PROTECTED PATH ==========
const PROTECTED_PATH = '/tokens-imdyi82tsntakfAhrektdbyrhfw8eu/test/iq/test/iq';
const TOKEN_EXPIRY_MS = 30 * 60 * 1000; // 30 menit

// ========== SESSION/TOKEN TRACKING ==========
const verifiedSessions = new Map();

// Cleanup expired tokens setiap 5 menit
setInterval(() => {
    const now = Date.now();
    let deletedCount = 0;
    for (const [key, data] of verifiedSessions.entries()) {
        if (now - data.timestamp > TOKEN_EXPIRY_MS) {
            verifiedSessions.delete(key);
            deletedCount++;
        }
    }
    if (deletedCount > 0) {
        console.log(`🧹 Cleaned ${deletedCount} expired tokens`);
    }
}, 300000);

// ========== GENERATE DEVICE FINGERPRINT ==========
function getDeviceFingerprint(req) {
    const userAgent = req.headers['user-agent'] || 'unknown';
    const ip = req.ip || req.connection.remoteAddress || 'unknown';
    return crypto.createHash('sha256')
        .update(userAgent + ip)
        .digest('hex');
}

// ========== GENERATE TOKEN ==========
function generateToken(deviceFingerprint) {
    const timestamp = Date.now().toString(36);
    const random = crypto.randomBytes(16).toString('hex');
    return `iq_${timestamp}_${random}`;
}

// ========== VALIDATE TOKEN ==========
function isValidToken(token, deviceFingerprint) {
    if (!token) return false;
    const session = verifiedSessions.get(token);
    if (!session) return false;
    
    const now = Date.now();
    if (now - session.timestamp > TOKEN_EXPIRY_MS) {
        verifiedSessions.delete(token);
        return false;
    }
    
    if (session.deviceFingerprint !== deviceFingerprint) {
        verifiedSessions.delete(token);
        return false;
    }
    
    return true;
}

// ========== MIDDLEWARE PROTECTED PATH ==========
app.use(PROTECTED_PATH, (req, res, next) => {
    // API endpoints tetap bisa diakses
    if (req.path.includes('/api/') || req.path.includes('/ranking')) {
        return next();
    }
    
    const deviceFingerprint = getDeviceFingerprint(req);
    
    // ===== CEK TOKEN =====
    const tokenFromQuery = req.query.token;
    const tokenFromCookie = req.cookies?.iq_token;
    const tokenFromHeader = req.headers['x-iq-token'];
    const token = tokenFromQuery || tokenFromCookie || tokenFromHeader;
    
    // Cek apakah token valid
    const hasValidToken = token && isValidToken(token, deviceFingerprint);
    
    // ===== CEK REFERER (HARUS DARI DASHBOARD) =====
    const referer = req.headers.referer || '';
    const isFromDashboard = referer.includes(`${BASE_URL}/`) || 
                           referer.includes(`${BASE_URL}?`) ||
                           referer.includes(BASE_URL.replace('http', 'https'));
    
    const fromDashboardParam = req.query.from === 'dashboard';
    
    console.log(`🔍 Access check for ${req.path}:`);
    console.log(`   Device: ${deviceFingerprint.substring(0, 20)}...`);
    console.log(`   Token valid: ${hasValidToken}`);
    console.log(`   from=dashboard param: ${fromDashboardParam}`);
    console.log(`   Referer from dashboard: ${isFromDashboard}`);
    console.log(`   Referer: ${referer || 'none'}`);
    
    // ===== KALAU PUNYA TOKEN VALID =====
    if (hasValidToken) {
        // Refresh token
        const session = verifiedSessions.get(token);
        session.timestamp = Date.now();
        verifiedSessions.set(token, session);
        
        res.cookie('iq_token', token, {
            maxAge: TOKEN_EXPIRY_MS,
            httpOnly: true,
            secure: false,
            sameSite: 'lax'
        });
        
        console.log(`✅ Access granted with token`);
        return next();
    }
    
    // ===== KALAU DARI DASHBOARD (buat token baru) =====
    if (fromDashboardParam && isFromDashboard) {
        const newToken = generateToken(deviceFingerprint);
        verifiedSessions.set(newToken, {
            timestamp: Date.now(),
            deviceFingerprint: deviceFingerprint,
            userAgent: req.headers['user-agent'] || 'unknown',
            ip: req.ip || req.connection.remoteAddress,
            createdAt: new Date().toISOString()
        });
        
        console.log(`✅ New token created from dashboard`);
        console.log(`   Token: ${newToken.substring(0, 20)}...`);
        
        res.cookie('iq_token', newToken, {
            maxAge: TOKEN_EXPIRY_MS,
            httpOnly: true,
            secure: false,
            sameSite: 'lax'
        });
        
        // Redirect dengan token
        const redirectUrl = req.originalUrl.includes('?') 
            ? req.originalUrl + `&token=${newToken}` 
            : req.originalUrl + `?token=${newToken}`;
        
        return res.redirect(302, redirectUrl);
    }
    
    // ===== AKSES DITOLAK =====
    console.log(`🚫 ACCESS DENIED`);
    console.log(`   Reason: No valid token and not from dashboard`);
    console.log(`   Redirecting to dashboard...`);
    
    res.clearCookie('iq_token');
    return res.redirect(302, '/?error=access_denied&msg=Silakan akses melalui tombol MULAI TEST GRATIS dari dashboard');
});

// ========== SERVE STATIC FILES ==========
app.use(express.static(__dirname, {
    setHeaders: (res, filePath) => {
        const allowedExtensions = ['.html', '.htm', '.css', '.js', '.png', '.jpg', '.jpeg', '.gif', '.svg', '.ico', '.webp', '.woff', '.woff2', '.ttf', '.eot'];
        const ext = path.extname(filePath);
        if (!allowedExtensions.includes(ext)) {
            res.removeHeader('Content-Disposition');
        }
    }
}));

// ========== SERVE DASHBOARD FOLDER ==========
const DASHBOARD_DIR = path.join(__dirname, 'dashboard');

// Serve dashboard folder sebagai static
app.use('/dashboard', express.static(DASHBOARD_DIR, {
    setHeaders: (res, filePath) => {
        const ext = path.extname(filePath);
        if (ext === '.html' || ext === '.htm') {
            res.setHeader('Content-Type', 'text/html');
        }
    }
}));

// ========== FILE STORAGE ==========
const DATA_FILE = path.join(__dirname, 'tokens-imdyi82tsntakfAhrektdbyrhfw8eu/test/iq/test/iq/ranking.json');

function initDataFile() {
    const dir = path.dirname(DATA_FILE);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
        console.log('✅ Folder data created');
    }
    if (!fs.existsSync(DATA_FILE)) {
        fs.writeFileSync(DATA_FILE, JSON.stringify({ users: [] }, null, 2));
        console.log('✅ File ranking.json created');
    }
}
initDataFile();

function readData() {
    try {
        const raw = fs.readFileSync(DATA_FILE, 'utf8');
        return JSON.parse(raw);
    } catch (error) {
        console.error('Error reading data file:', error);
        return { users: [] };
    }
}

function writeData(data) {
    try {
        fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
        return true;
    } catch (error) {
        console.error('Error writing data file:', error);
        return false;
    }
}

// ========== ROUTES API ==========
app.get(config.apiPath, (req, res) => {
    try {
        const data = readData();
        const sorted = [...data.users].sort((a, b) => b.iq - a.iq);
        res.json({
            success: true,
            data: sorted,
            total: sorted.length
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

app.post(config.apiPath, (req, res) => {
    try {
        const { name, iq, correct, total, time, category } = req.body;

        if (!name || iq === undefined || correct === undefined) {
            return res.status(400).json({
                success: false,
                message: 'Data tidak lengkap'
            });
        }

        const data = readData();
        const existingIndex = data.users.findIndex(
            u => u.name.toLowerCase() === name.toLowerCase()
        );

        const userData = {
            name: name.trim(),
            iq: Number(iq),
            correct: Number(correct),
            total: Number(total) || 10,
            time: time || '00:00',
            category: category || 'Tidak Diketahui',
            date: new Date().toISOString()
        };

        if (existingIndex !== -1) {
            data.users[existingIndex] = {
                ...data.users[existingIndex],
                ...userData
            };
            console.log(`🔄 Update user: ${name} | IQ: ${iq}`);
        } else {
            data.users.push(userData);
            console.log(`✅ User baru: ${name} | IQ: ${iq}`);
        }

        if (writeData(data)) {
            res.json({
                success: true,
                message: 'Data berhasil disimpan',
                data: userData
            });
        } else {
            res.status(500).json({
                success: false,
                message: 'Gagal menyimpan data'
            });
        }
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

app.get(`${config.apiPath}/search`, (req, res) => {
    try {
        const { name } = req.query;
        if (!name) {
            return res.status(400).json({
                success: false,
                message: 'Parameter name diperlukan'
            });
        }

        const data = readData();
        const users = data.users.filter(
            u => u.name.toLowerCase().includes(name.toLowerCase())
        );

        res.json({
            success: true,
            data: users
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

app.get(`${config.apiPath}/stats`, (req, res) => {
    try {
        const data = readData();
        const users = data.users;

        if (users.length === 0) {
            return res.json({
                success: true,
                data: {
                    total: 0,
                    highestIQ: 0,
                    averageIQ: 0,
                    lowestIQ: 0,
                    totalUsers: 0
                }
            });
        }

        const iqs = users.map(u => u.iq);
        const highestIQ = Math.max(...iqs);
        const lowestIQ = Math.min(...iqs);
        const averageIQ = Math.round(iqs.reduce((a, b) => a + b, 0) / iqs.length);

        res.json({
            success: true,
            data: {
                total: users.length,
                highestIQ,
                averageIQ,
                lowestIQ,
                totalUsers: users.length
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

app.delete(`${config.apiPath}/clear`, (req, res) => {
    try {
        if (writeData({ users: [] })) {
            console.log('🗑️ Semua data ranking dihapus');
            res.json({
                success: true,
                message: 'Semua data berhasil dihapus'
            });
        } else {
            res.status(500).json({
                success: false,
                message: 'Gagal menghapus data'
            });
        }
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

// ========== CHECK TOKEN STATUS ==========
app.get('/api/check-token', (req, res) => {
    const token = req.query.token || req.cookies?.iq_token;
    const deviceFingerprint = getDeviceFingerprint(req);
    
    if (!token) {
        return res.json({
            valid: false,
            message: 'No token provided',
            device: deviceFingerprint.substring(0, 20) + '...'
        });
    }
    
    const isValid = isValidToken(token, deviceFingerprint);
    const session = verifiedSessions.get(token);
    const expiry = session ? new Date(session.timestamp + TOKEN_EXPIRY_MS).toISOString() : null;
    
    res.json({
        valid: isValid,
        token: token.substring(0, 20) + '...',
        device: deviceFingerprint.substring(0, 20) + '...',
        deviceMatch: session ? session.deviceFingerprint === deviceFingerprint : false,
        expiresAt: expiry,
        timeRemaining: session ? Math.floor((TOKEN_EXPIRY_MS - (Date.now() - session.timestamp)) / 1000) : 0,
        message: isValid ? 'Token valid untuk device ini' : 'Token invalid atau device berbeda'
    });
});

// ========== ROOT - SERVE DASHBOARD HTML ==========
app.get('/', (req, res) => {
    const error = req.query.error;
    const msg = req.query.msg;
    
    // Hapus cookie token di root
    res.clearCookie('iq_token');
    
    // Cari file HTML di folder dashboard
    const dashboardFile = path.join(DASHBOARD_DIR, 'index.html');
    
    if (fs.existsSync(dashboardFile)) {
        console.log(`📄 Serving dashboard: ${path.relative(__dirname, dashboardFile)}`);
        res.sendFile(dashboardFile);
    } else {
        // Jika file tidak ditemukan, beri response error
        console.log(`❌ Dashboard file not found: ${dashboardFile}`);
        res.status(404).json({
            success: false,
            message: 'Dashboard file not found. Please put index.html in dashboard folder.',
            path: dashboardFile
        });
    }
});

// ========== REDIRECT UNTUK AKSES TANPA TOKEN ==========
app.get('/tokens-imdyi82tsntakfAhrektdbyrhfw8eu/test/iq/test/iq', (req, res, next) => {
    const token = req.query.token || req.cookies?.iq_token;
    const deviceFingerprint = getDeviceFingerprint(req);
    const referer = req.headers.referer || '';
    const isFromDashboard = referer.includes(`${BASE_URL}/`) || 
                           referer.includes(`${BASE_URL}?`) ||
                           referer.includes(BASE_URL.replace('http', 'https'));
    const fromDashboardParam = req.query.from === 'dashboard';
    
    // Jika ada token valid, lanjutkan
    if (token && isValidToken(token, deviceFingerprint)) {
        return next();
    }
    
    // Jika dari dashboard dengan referer valid, lanjutkan
    if (fromDashboardParam && isFromDashboard) {
        return next();
    }
    
    // Selain itu, redirect ke root
    console.log(`🔄 Redirect to root: ${req.url} (no valid token and not from dashboard)`);
    return res.redirect(302, '/?error=access_denied&msg=Silakan akses melalui tombol MULAI TEST GRATIS dari dashboard');
});

// ========== 404 HANDLER ==========
app.use((req, res) => {
    res.status(404).json({
        success: false,
        message: 'Resource tidak ditemukan'
    });
});

// ========== ERROR HANDLING ==========
app.use((err, req, res, next) => {
    console.error('Server error:', err);
    res.status(500).json({
        success: false,
        message: 'Terjadi kesalahan pada server'
    });
});

// ========== START SERVER ==========
app.listen(PORT, () => {
    console.log(`\n╔════════════════════════════════════════════════════════════════╗`);
    console.log(`║   🚀 IQ TEST RANKING SERVER                                   ║`);
    console.log(`╠════════════════════════════════════════════════════════════════╣`);
    console.log(`║   🌐 ${BASE_URL}                                     ║`);
    console.log(`║   📁 Data: ${DATA_FILE}`);
    console.log(`║   📁 Dashboard: ${DASHBOARD_DIR}`);
    console.log(`╠════════════════════════════════════════════════════════════════╣`);
    console.log(`║   🔐 SECURITY:                                                ║`);
    console.log(`║      - Token WAJIB untuk akses test                          ║`);
    console.log(`║      - Token hanya dari dashboard (referer)                  ║`);
    console.log(`║      - Parameter ?from=dashboard TIDAK CUKUP                 ║`);
    console.log(`║      - Token terikat device (browser + IP)                   ║`);
    console.log(`║      - Token expired ${TOKEN_EXPIRY_MS/60000} menit                     ║`);
    console.log(`║      - Akses langsung → redirect dashboard                   ║`);
    console.log(`╚════════════════════════════════════════════════════════════════╝\n`);
    console.log(`📋 API Endpoints:`);
    console.log(`   GET  ${config.apiPath}          - Lihat semua ranking`);
    console.log(`   POST ${config.apiPath}          - Tambah/update user`);
    console.log(`   GET  ${config.apiPath}/stats    - Statistik ranking`);
    console.log(`   GET  ${config.apiPath}/search   - Cari user`);
    console.log(`   DELETE ${config.apiPath}/clear  - Hapus semua data`);
    console.log(`   GET  /api/check-token           - Cek status token\n`);
    console.log(`📄 Dashboard: ${BASE_URL}`);
    console.log(`\n🔒 Cara Akses yang BENAR:`);
    console.log(`   1. Buka dashboard: ${BASE_URL}`);
    console.log(`   2. Klik tombol MULAI TEST GRATIS`);
    console.log(`   3. Server akan generate token dan redirect`);
    console.log(`   4. Token valid 30 menit untuk device tersebut\n`);
    console.log(`🚫 Cara Akses yang SALAH (akan redirect):`);
    console.log(`   ❌ ${BASE_URL}/tokens-.../test/iq/test/iq?from=dashboard`);
    console.log(`   ❌ ${BASE_URL}/tokens-.../test/iq/test/iq`);
    console.log(`   ❌ Copy URL ke browser lain\n`);
});