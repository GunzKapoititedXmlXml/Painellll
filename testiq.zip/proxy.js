// proxy.js
// ========================================================================
// ANTI-DDOS, ANTI-BRUTE FORCE & ANTI-SQL INJECTION PROXY MIDDLEWARE
// ------------------------------------------------------------------------
// - Pengunjung normal (browsing wajar) TIDAK akan terkena block sama sekali.
// - IP yang ketahuan melakukan hal berikut akan diblokir OTOMATIS 10 menit
//   dan tampil jelas di terminal/console server:
//     1) Flood request (indikasi DDoS)
//     2) Spam ke endpoint sensitif / data server (indikasi brute force)
//     3) Payload mengandung pola SQL Injection (di query string maupun body)
//     4) Mencoba mengakses path login/admin/panel yang tidak ada di aplikasi
//        ini (indikasi bot mencoba "menembus" masuk ke server)
//     5) Path traversal (../../etc/passwd, dsb) - indikasi coba baca/otak-atik
//        file di server
//     6) Akses langsung ke endpoint decrypt tanpa token yang valid
//     7) Brute force mencoba banyak token invalid ke endpoint decrypt
// - UNBLOCK OTOMATIS setelah 10 menit (dikelola oleh sistem cleanup)
// - Semua penghitungan disimpan in-memory (Map) dan dibersihkan berkala
//   supaya tidak membebani memori server.
// ========================================================================

// ========== KONFIGURASI ==========
const BLOCK_DURATION_MS = 3 * 1000; // 1 detik
const WINDOW_MS = 10 * 1000;
const MAX_REQUESTS_PER_WINDOW = 50;
const MAX_SENSITIVE_PER_WINDOW = 10;
const ATTACK_WINDOW_MS = 60 * 1000;
const MAX_ATTACK_HITS = 3;
const MAX_DECRYPT_ATTEMPTS = 3; // Hanya 3 percobaan sebelum diblokir
const CLEANUP_INTERVAL_MS = 1 * 1000; // Pembersihan setiap 30 detik

// Pola path yang dianggap "sensitif" -> target favorit brute force / probing data
const SENSITIVE_PATTERNS = [
    'api',
    'go-to-test',
    '.env',
    '.git',
    'config.js',
    'package.json',
    'package-lock.json',
    'server.js',
    '.encrypted',
    'node_modules',
    '.key',
    '.pem',
    '.crt',
    '.log'
];

// Path login/admin/panel yang TIDAK ADA di aplikasi ini
const ATTACK_PROBE_PATTERNS = [
    'wp-login.php',
    'wp-admin',
    'wp-content',
    'wp-json',
    'xmlrpc.php',
    'administrator',
    'phpmyadmin',
    'pma',
    'adminer',
    'admin.php',
    'admin.html',
    'admin',
    'login.php',
    'login.html',
    'login',
    'signin',
    'user.php',
    'shell.php',
    'cmd.php',
    'config.php',
    '.aws',
    '.ssh',
    '.docker',
    'actuator',
    'manager/html',
    'console',
    'solr',
    'vendor/phpunit'
];

// Path traversal patterns
const PATH_TRAVERSAL_PATTERNS = [
    '../',
    '..\\',
    '%2e%2e%2f',
    '%2e%2e/',
    '/etc/passwd',
    '/proc/self'
];

// SQL Injection patterns
const SQLI_PATTERNS = [
    'union select',
    'union+select',
    'union%20select',
    'select from',
    'insert into',
    'update set',
    'delete from',
    'drop table',
    'drop database',
    'alter table',
    'truncate table',
    'exec sp_',
    'exec xp_',
    'xp_cmdshell',
    'information_schema',
    'sleep(',
    'benchmark(',
    'waitfor delay',
    "or 1=1",
    "or '1'='1",
    'or "1"="1',
    "and 1=1",
    "and '1'='1",
    'and "1"="1',
    ';drop',
    ';delete',
    ';update',
    ';insert',
    '--drop',
    '--delete',
    '--update',
    '--select'
];

// Endpoint decrypt yang harus dilindungi
const DECRYPT_ENDPOINTS = [
    '/api/get-decrypted-content',
    '/api/get-decrypted-dashboard'
];

// ========== STORAGE IN-MEMORY ==========
const requestLog = new Map();
const sensitiveLog = new Map();
const attackLog = new Map();
const blockedIPs = new Map(); // Key: IP, Value: unblockAt timestamp
const violationCount = new Map();
const decryptAttemptLog = new Map();
const bruteForceLog = new Map();

// ========== HELPER ==========
function getClientIP(req) {
    const forwarded = req.headers['x-forwarded-for'];
    if (forwarded) {
        const ips = forwarded.split(',').map(ip => ip.trim());
        return ips[0];
    }
    return req.ip || req.connection?.remoteAddress || 'unknown';
}

function getIPDetails(req) {
    const ip = getClientIP(req);
    const userAgent = req.headers['user-agent'] || 'unknown';
    const referer = req.headers['referer'] || 'none';
    const acceptLanguage = req.headers['accept-language'] || 'unknown';
    
    return {
        ip,
        userAgent,
        referer,
        acceptLanguage,
        timestamp: new Date().toISOString()
    };
}

function isSensitivePath(pathName) {
    const lowerPath = pathName.toLowerCase();
    return SENSITIVE_PATTERNS.some((pattern) => {
        return lowerPath.includes(pattern.toLowerCase());
    });
}

function isAttackProbePath(pathName) {
    const lowerPath = pathName.toLowerCase();
    return ATTACK_PROBE_PATTERNS.some((pattern) => {
        return lowerPath.includes(pattern.toLowerCase());
    });
}

function hasPathTraversal(str) {
    const lowerStr = str.toLowerCase();
    return PATH_TRAVERSAL_PATTERNS.some((pattern) => {
        return lowerStr.includes(pattern.toLowerCase());
    });
}

function hasSqlInjection(str) {
    const lowerStr = str.toLowerCase();
    return SQLI_PATTERNS.some((pattern) => {
        return lowerStr.includes(pattern.toLowerCase());
    });
}

function isDecryptEndpoint(pathName) {
    return DECRYPT_ENDPOINTS.some(endpoint => pathName.includes(endpoint));
}

function flattenValues(obj, out = []) {
    if (obj === null || obj === undefined) return out;
    if (typeof obj === 'string') {
        out.push(obj);
    } else if (typeof obj === 'number' || typeof obj === 'boolean') {
        out.push(String(obj));
    } else if (Array.isArray(obj)) {
        for (const item of obj) flattenValues(item, out);
    } else if (typeof obj === 'object') {
        for (const key of Object.keys(obj)) {
            out.push(key);
            flattenValues(obj[key], out);
        }
    }
    return out;
}

function pruneOld(arr, now, windowMs) {
    let i = 0;
    while (i < arr.length && now - arr[i] > windowMs) i++;
    if (i > 0) arr.splice(0, i);
    return arr;
}

function blockIP(ip, reason, category, details = {}) {
    const unblockAt = Date.now() + BLOCK_DURATION_MS;
    blockedIPs.set(ip, unblockAt);
    const violations = (violationCount.get(ip) || 0) + 1;
    violationCount.set(ip, violations);

    console.log(`\n${'='.repeat(80)}`);
    console.log(`🚨🚨🚨 SERANGAN TERDETEKSI - IP DIBLOKIR 10 MENIT 🚨🚨🚨`);
    console.log(`${'='.repeat(80)}`);
    console.log(`📌 IP Address      : ${ip}`);
    console.log(`📌 Kategori        : ${category}`);
    console.log(`📌 Alasan          : ${reason}`);
    console.log(`📌 User Agent      : ${details.userAgent || 'unknown'}`);
    console.log(`📌 Referer         : ${details.referer || 'none'}`);
    console.log(`📌 Accept Language : ${details.acceptLanguage || 'unknown'}`);
    console.log(`📌 Waktu Kejadian  : ${new Date().toISOString()}`);
    console.log(`📌 Buka Kembali    : ${new Date(unblockAt).toISOString()}`);
    console.log(`📌 Total Pelanggaran: ${violations}x`);
    
    if (details.attemptedTokens) {
        console.log(`📌 Token Dicoba    : ${details.attemptedTokens.join(', ')}`);
    }
    if (details.requestCount) {
        console.log(`📌 Total Request   : ${details.requestCount}`);
    }
    if (details.path) {
        console.log(`📌 Path Tujuan     : ${details.path}`);
    }
    
    console.log(`${'='.repeat(80)}\n`);
}

function recordAttackHit(ip, now, reason, category, details = {}) {
    let times = attackLog.get(ip) || [];
    times = pruneOld(times, now, ATTACK_WINDOW_MS);
    times.push(now);
    attackLog.set(ip, times);

    const attemptNumber = times.length;
    console.log(`⚠️  [PROXY] Percobaan mencurigakan #${attemptNumber} dari IP ${ip}`);
    console.log(`   → ${reason}`);
    if (details.token) {
        console.log(`   → Token: ${details.token.substring(0, 30)}...`);
    }

    if (times.length >= MAX_ATTACK_HITS) {
        blockIP(ip, `${reason} (${times.length}x dalam ${ATTACK_WINDOW_MS / 1000} detik)`, category, details);
        attackLog.delete(ip);
        return true;
    }
    return false;
}

// proxy.js - Bagian yang perlu diubah (bagian DETEKSI BRUTE FORCE)

// ========== MIDDLEWARE 1: GUARD UTAMA ==========
function guard(req, res, next) {
    const ip = getClientIP(req);
    const now = Date.now();
    const pathName = req.path;
    const ipDetails = getIPDetails(req);

    // CEK APAKAH IP SEDANG DIBLOKIR
    const unblockAt = blockedIPs.get(ip);
    if (unblockAt) {
        if (now < unblockAt) {
            const remaining = Math.ceil((unblockAt - now) / 1000);
            const minutes = Math.floor(remaining / 60);
            const seconds = remaining % 60;
            
            console.log(`🚫 [PROXY] IP diblokir mencoba akses: ${ip} (${minutes}m ${seconds}s tersisa)`);
            
            res.setHeader('Retry-After', remaining);
            return res.status(429).json({
                success: false,
                message: `Akses Anda diblokir sementara karena aktivitas mencurigakan. Coba lagi dalam ${minutes} menit ${seconds} detik.`,
                blockedUntil: new Date(unblockAt).toISOString(),
                remainingSeconds: remaining,
                autoUnblockAt: new Date(unblockAt).toISOString()
            });
        }
        // BLOKIR SUDAH HABIS - UNBLOCK OTOMATIS
        blockedIPs.delete(ip);
        violationCount.delete(ip);
        requestLog.delete(ip);
        sensitiveLog.delete(ip);
        attackLog.delete(ip);
        decryptAttemptLog.delete(ip);
        bruteForceLog.delete(ip);
        console.log(`✅ [PROXY] 🔓 UNBLOCK OTOMATIS - IP ${ip} sudah tidak diblokir (10 menit habis)`);
    }

    // 1) Probing path login/admin/panel
    if (isAttackProbePath(pathName)) {
        const blocked = recordAttackHit(ip, now, 
            `Mencoba akses path login/admin/panel palsu: "${pathName}"`, 
            'PROBE_LOGIN_ADMIN',
            ipDetails
        );
        if (blocked) {
            return res.status(429).json({ 
                success: false, 
                message: 'IP Anda diblokir sementara selama 10 menit.' 
            });
        }
        return res.status(404).json({ success: false, message: 'Resource tidak ditemukan' });
    }

    // 2) Path traversal
    if (hasPathTraversal(pathName) || hasPathTraversal(req.originalUrl)) {
        const blocked = recordAttackHit(ip, now, 
            `Path traversal terdeteksi: "${req.originalUrl}"`, 
            'PATH_TRAVERSAL',
            { ...ipDetails, path: req.originalUrl }
        );
        if (blocked) {
            return res.status(429).json({ 
                success: false, 
                message: 'IP Anda diblokir sementara selama 10 menit.' 
            });
        }
        return res.status(400).json({ success: false, message: 'Request tidak valid' });
    }

    // 3) SQL Injection
    const queryValues = flattenValues(req.query);
    const toScan = [pathName, ...queryValues];
    const sqliHit = toScan.find((v) => hasSqlInjection(v));
    if (sqliHit) {
        const blocked = recordAttackHit(ip, now, 
            `Pola SQL Injection terdeteksi pada query/URL: "${sqliHit}"`, 
            'SQL_INJECTION',
            { ...ipDetails, path: req.originalUrl }
        );
        if (blocked) {
            return res.status(429).json({ 
                success: false, 
                message: 'IP Anda diblokir sementara selama 10 menit.' 
            });
        }
        return res.status(400).json({ success: false, message: 'Request tidak valid' });
    }

    // 4) DETEKSI BRUTE FORCE PADA ENDPOINT DECRYPT - DIPERBAIKI!
    if (isDecryptEndpoint(pathName)) {
        const token = req.query.token || req.cookies?.iq_token;
        
        // CEK APAKAH TOKEN VALID SEBELUM MENGHITUNG SEBAGAI PERCOBAAN
        // Kita perlu akses fungsi isValidToken dari server.js
        // Tapi kita tidak bisa langsung, jadi kita gunakan pendekatan berbeda
        
        // Jika token ada, cek apakah formatnya valid (mulai dengan 'iq_')
        const isTokenFormatValid = token && token.startsWith('iq_');
        
        // Jika token tidak ada ATAU formatnya tidak valid, baru dianggap serangan
        if (!token || !isTokenFormatValid) {
            console.log(`🔴 [PROXY] ⚠️  PERCOBAAN AKSES DECRYPT DENGAN TOKEN INVALID dari IP: ${ip}`);
            console.log(`   Token: ${token ? token.substring(0, 20) + '...' : 'NO_TOKEN'}`);
            console.log(`   User-Agent: ${ipDetails.userAgent}`);
            console.log(`   Path: ${pathName}`);
            
            // Catat sebagai percobaan mencurigakan
            let decryptAttempts = decryptAttemptLog.get(ip) || [];
            decryptAttempts = pruneOld(decryptAttempts, now, ATTACK_WINDOW_MS);
            decryptAttempts.push(now);
            decryptAttemptLog.set(ip, decryptAttempts);
            
            // Catat token yang dicoba
            let bruteForceData = bruteForceLog.get(ip) || { tokens: [], count: 0, lastAttempt: 0 };
            bruteForceData.tokens.push(token || 'NO_TOKEN');
            bruteForceData.count++;
            bruteForceData.lastAttempt = now;
            bruteForceLog.set(ip, bruteForceData);
            
            const blocked = recordAttackHit(ip, now, 
                `Mencoba akses decrypt endpoint dengan token invalid (percobaan ke-${decryptAttempts.length})`, 
                'DECRYPT_INVALID_TOKEN',
                { ...ipDetails, path: pathName, token: token }
            );
            if (blocked) {
                return res.status(429).json({ 
                    success: false, 
                    message: 'IP Anda diblokir sementara selama 10 menit.' 
                });
            }
            return res.status(403).json({
                success: false,
                message: 'Access denied - Invalid token'
            });
        }
        
        // TOKEN VALID - TIDAK DIHITUNG SEBAGAI SERANGAN!
        console.log(`✅ [PROXY] Valid token access dari IP: ${ip}`);
        console.log(`   Token: ${token.substring(0, 20)}...`);
        console.log(`   Path: ${pathName}`);
        
        // Reset counter untuk IP ini (karena token valid)
        // Ini mencegah IP diblokir karena refresh normal
        if (decryptAttemptLog.has(ip)) {
            // Hapus log percobaan untuk IP ini karena sekarang token valid
            const attempts = decryptAttemptLog.get(ip) || [];
            const validAttempts = attempts.filter(time => now - time > ATTACK_WINDOW_MS);
            if (validAttempts.length === 0) {
                decryptAttemptLog.delete(ip);
            } else {
                decryptAttemptLog.set(ip, validAttempts);
            }
        }
        
        // Hapus brute force log jika ada (karena sekarang token valid)
        if (bruteForceLog.has(ip)) {
            bruteForceLog.delete(ip);
        }
    }

    // 5) Rate limit umum - DDoS/Flood
    let generalTimes = requestLog.get(ip) || [];
    generalTimes = pruneOld(generalTimes, now, WINDOW_MS);
    generalTimes.push(now);
    requestLog.set(ip, generalTimes);

    if (generalTimes.length > MAX_REQUESTS_PER_WINDOW) {
        blockIP(ip, 
            `Flood terdeteksi (${generalTimes.length} request dalam ${WINDOW_MS / 1000}s)`, 
            'DDOS_FLOOD',
            { ...ipDetails, requestCount: generalTimes.length }
        );
        requestLog.delete(ip);
        return res.status(429).json({
            success: false,
            message: 'Terlalu banyak permintaan. IP Anda diblokir sementara selama 10 menit.'
        });
    }

    // 6) Rate limit untuk endpoint sensitif
    if (isSensitivePath(pathName)) {
        let sensTimes = sensitiveLog.get(ip) || [];
        sensTimes = pruneOld(sensTimes, now, WINDOW_MS);
        sensTimes.push(now);
        sensitiveLog.set(ip, sensTimes);

        if (sensTimes.length > MAX_SENSITIVE_PER_WINDOW) {
            blockIP(ip, 
                `Percobaan berulang ke endpoint sensitif "${pathName}" (${sensTimes.length}x dalam ${WINDOW_MS / 1000}s)`, 
                'BRUTE_FORCE',
                { ...ipDetails, path: pathName, requestCount: sensTimes.length }
            );
            sensitiveLog.delete(ip);
            return res.status(429).json({
                success: false,
                message: 'Aktivitas mencurigakan terdeteksi. IP Anda diblokir sementara selama 10 menit.'
            });
        }
    }

    next();
}

// ========== MIDDLEWARE 2: CONTENT GUARD ==========
function contentGuard(req, res, next) {
    if (!req.body || typeof req.body !== 'object') return next();

    const ip = getClientIP(req);
    const now = Date.now();
    const ipDetails = getIPDetails(req);

    const unblockAt = blockedIPs.get(ip);
    if (unblockAt && now < unblockAt) {
        const remaining = Math.ceil((unblockAt - now) / 1000);
        res.setHeader('Retry-After', remaining);
        return res.status(429).json({
            success: false,
            message: `Akses Anda diblokir sementara. Coba lagi dalam ${remaining} detik.`
        });
    }

    const bodyValues = flattenValues(req.body);
    const sqliHit = bodyValues.find((v) => hasSqlInjection(v));
    if (sqliHit) {
        const blocked = recordAttackHit(ip, now, 
            `Pola SQL Injection terdeteksi pada body request: "${sqliHit}"`, 
            'SQL_INJECTION_BODY',
            { ...ipDetails, path: req.path }
        );
        if (blocked) {
            return res.status(429).json({ 
                success: false, 
                message: 'IP Anda diblokir sementara selama 10 menit.' 
            });
        }
        return res.status(400).json({ success: false, message: 'Data tidak valid' });
    }

    next();
}

// ========== AUTO UNBLOCK - PEMBERSIHAN BERKALA ==========
setInterval(() => {
    const now = Date.now();
    let unblockedCount = 0;
    let cleanedCount = 0;

    // CEK DAN UNBLOCK IP YANG SUDAH HABIS MASA BLOKIRNYA
    for (const [ip, unblockAt] of blockedIPs.entries()) {
        if (now >= unblockAt) {
            blockedIPs.delete(ip);
            violationCount.delete(ip);
            requestLog.delete(ip);
            sensitiveLog.delete(ip);
            attackLog.delete(ip);
            decryptAttemptLog.delete(ip);
            bruteForceLog.delete(ip);
            unblockedCount++;
            console.log(`✅ [PROXY] 🔓 AUTO UNBLOCK - IP ${ip} dibuka otomatis (waktu blokir habis)`);
        }
    }

    // BERSIHKAN DATA LOG YANG SUDAH KADALUARSA
    for (const [ip, times] of requestLog.entries()) {
        if (pruneOld(times, now, WINDOW_MS).length === 0) {
            requestLog.delete(ip);
            cleanedCount++;
        }
    }
    for (const [ip, times] of sensitiveLog.entries()) {
        if (pruneOld(times, now, WINDOW_MS).length === 0) {
            sensitiveLog.delete(ip);
            cleanedCount++;
        }
    }
    for (const [ip, times] of attackLog.entries()) {
        if (pruneOld(times, now, ATTACK_WINDOW_MS).length === 0) {
            attackLog.delete(ip);
            cleanedCount++;
        }
    }
    for (const [ip, times] of decryptAttemptLog.entries()) {
        if (pruneOld(times, now, ATTACK_WINDOW_MS).length === 0) {
            decryptAttemptLog.delete(ip);
            cleanedCount++;
        }
    }
    for (const [ip, data] of bruteForceLog.entries()) {
        if (now - data.lastAttempt > ATTACK_WINDOW_MS) {
            bruteForceLog.delete(ip);
            cleanedCount++;
        }
    }
    
    if (unblockedCount > 0 || cleanedCount > 0) {
        console.log(`🧹 [PROXY] Cleanup: ${unblockedCount} IP di-unblock, ${cleanedCount} data log dibersihkan`);
        console.log(`📊 [PROXY] Status: ${blockedIPs.size} IP masih diblokir`);
    }
}, CLEANUP_INTERVAL_MS);

// ========== HELPER MONITORING ==========
function getBlockedIPs() {
    const now = Date.now();
    return Array.from(blockedIPs.entries())
        .filter(([, unblockAt]) => unblockAt > now)
        .map(([ip, unblockAt]) => ({
            ip,
            remainingSeconds: Math.ceil((unblockAt - now) / 1000),
            remainingMinutes: Math.floor((unblockAt - now) / 60000),
            violations: violationCount.get(ip) || 0,
            unblockAt: new Date(unblockAt).toISOString(),
            autoUnblock: true
        }));
}

function unblockIPManual(ip) {
    blockedIPs.delete(ip);
    violationCount.delete(ip);
    requestLog.delete(ip);
    sensitiveLog.delete(ip);
    attackLog.delete(ip);
    decryptAttemptLog.delete(ip);
    bruteForceLog.delete(ip);
    console.log(`✅ [PROXY] 🔓 UNBLOCK MANUAL - IP ${ip} dibuka secara manual oleh admin`);
    return true;
}

function getBruteForceStats() {
    const stats = [];
    for (const [ip, data] of bruteForceLog.entries()) {
        stats.push({
            ip,
            attempts: data.count,
            lastAttempt: new Date(data.lastAttempt).toISOString(),
            uniqueTokens: new Set(data.tokens).size,
            sampleTokens: Array.from(new Set(data.tokens)).slice(0, 5)
        });
    }
    return stats;
}

function getSystemStatus() {
    return {
        blockedIPs: blockedIPs.size,
        activeSessions: requestLog.size,
        bruteForceAttempts: bruteForceLog.size,
        attackLogs: attackLog.size,
        blockDurationMinutes: BLOCK_DURATION_MS / 60000,
        cleanupIntervalSeconds: CLEANUP_INTERVAL_MS / 1000
    };
}

module.exports = guard;
module.exports.guard = guard;
module.exports.contentGuard = contentGuard;
module.exports.getBlockedIPs = getBlockedIPs;
module.exports.unblockIP = unblockIPManual;
module.exports.getBruteForceStats = getBruteForceStats;
module.exports.getSystemStatus = getSystemStatus;