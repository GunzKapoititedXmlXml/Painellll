// proxy.js
// ========================================================================
// ANTI-DDOS, ANTI-BRUTE FORCE & ANTI-SQL INJECTION PROXY MIDDLEWARE
// ------------------------------------------------------------------------
// - Pengunjung normal (browsing wajar) TIDAK akan terkena block sama sekali.
// - IP yang ketahuan melakukan hal berikut akan diblokir OTOMATIS 5 menit
//   dan tampil jelas di terminal/console server:
//     1) Flood request (indikasi DDoS)
//     2) Spam ke endpoint sensitif / data server (indikasi brute force)
//     3) Payload mengandung pola SQL Injection (di query string maupun body)
//     4) Mencoba mengakses path login/admin/panel yang tidak ada di aplikasi
//        ini (indikasi bot mencoba "menembus" masuk ke server)
//     5) Path traversal (../../etc/passwd, dsb) - indikasi coba baca/otak-atik
//        file di server
// - Semua penghitungan disimpan in-memory (Map) dan dibersihkan berkala
//   supaya tidak membebani memori server.
// ========================================================================

// ========== KONFIGURASI ==========
const BLOCK_DURATION_MS = 5 * 60 * 1000;
const WINDOW_MS = 10 * 1000;
const MAX_REQUESTS_PER_WINDOW = 50;
const MAX_SENSITIVE_PER_WINDOW = 10;
const ATTACK_WINDOW_MS = 60 * 1000;
const MAX_ATTACK_HITS = 3;
const CLEANUP_INTERVAL_MS = 30 * 1000;

// Pola path yang dianggap "sensitif" -> target favorit brute force / probing data
const SENSITIVE_PATTERNS = [
    'api',
    'go-to-test',
    '.env',
    '.git',
    'config.js',
    'package.json',
    'package-lock.json',
    'server.js',
    '.encrypted',
    'node_modules',
    '.key',
    '.pem',
    '.crt',
    '.log'
];

// Path login/admin/panel yang TIDAK ADA di aplikasi ini
const ATTACK_PROBE_PATTERNS = [
    'wp-login.php',
    'wp-admin',
    'wp-content',
    'wp-json',
    'xmlrpc.php',
    'administrator',
    'phpmyadmin',
    'pma',
    'adminer',
    'admin.php',
    'admin.html',
    'admin',
    'login.php',
    'login.html',
    'login',
    'signin',
    'user.php',
    'shell.php',
    'cmd.php',
    'config.php',
    '.aws',
    '.ssh',
    '.docker',
    'actuator',
    'manager/html',
    'console',
    'solr',
    'vendor/phpunit'
];

// Path traversal patterns
const PATH_TRAVERSAL_PATTERNS = [
    '../',
    '..\\',
    '%2e%2e%2f',
    '%2e%2e/',
    '/etc/passwd',
    '/proc/self'
];

// SQL Injection patterns
const SQLI_PATTERNS = [
    'union select',
    'union+select',
    'union%20select',
    'select from',
    'insert into',
    'update set',
    'delete from',
    'drop table',
    'drop database',
    'alter table',
    'truncate table',
    'exec sp_',
    'exec xp_',
    'xp_cmdshell',
    'information_schema',
    'sleep(',
    'benchmark(',
    'waitfor delay',
    "or 1=1",
    "or '1'='1",
    'or "1"="1',
    "and 1=1",
    "and '1'='1",
    'and "1"="1',
    ';drop',
    ';delete',
    ';update',
    ';insert',
    '--drop',
    '--delete',
    '--update',
    '--select'
];

// ========== STORAGE IN-MEMORY ==========
const requestLog = new Map();
const sensitiveLog = new Map();
const attackLog = new Map();
const blockedIPs = new Map();
const violationCount = new Map();

// ========== HELPER ==========
function getClientIP(req) {
    const forwarded = req.headers['x-forwarded-for'];
    if (forwarded) {
        return forwarded.split(',')[0].trim();
    }
    return req.ip || req.connection?.remoteAddress || 'unknown';
}

function isSensitivePath(pathName) {
    const lowerPath = pathName.toLowerCase();
    return SENSITIVE_PATTERNS.some((pattern) => {
        return lowerPath.includes(pattern.toLowerCase());
    });
}

function isAttackProbePath(pathName) {
    const lowerPath = pathName.toLowerCase();
    return ATTACK_PROBE_PATTERNS.some((pattern) => {
        return lowerPath.includes(pattern.toLowerCase());
    });
}

function hasPathTraversal(str) {
    const lowerStr = str.toLowerCase();
    return PATH_TRAVERSAL_PATTERNS.some((pattern) => {
        return lowerStr.includes(pattern.toLowerCase());
    });
}

function hasSqlInjection(str) {
    const lowerStr = str.toLowerCase();
    return SQLI_PATTERNS.some((pattern) => {
        return lowerStr.includes(pattern.toLowerCase());
    });
}

function flattenValues(obj, out = []) {
    if (obj === null || obj === undefined) return out;
    if (typeof obj === 'string') {
        out.push(obj);
    } else if (typeof obj === 'number' || typeof obj === 'boolean') {
        out.push(String(obj));
    } else if (Array.isArray(obj)) {
        for (const item of obj) flattenValues(item, out);
    } else if (typeof obj === 'object') {
        for (const key of Object.keys(obj)) {
            out.push(key);
            flattenValues(obj[key], out);
        }
    }
    return out;
}

function pruneOld(arr, now, windowMs) {
    let i = 0;
    while (i < arr.length && now - arr[i] > windowMs) i++;
    if (i > 0) arr.splice(0, i);
    return arr;
}

function blockIP(ip, reason, category) {
    const unblockAt = Date.now() + BLOCK_DURATION_MS;
    blockedIPs.set(ip, unblockAt);
    const violations = (violationCount.get(ip) || 0) + 1;
    violationCount.set(ip, violations);

    console.log(`\n🚨🚨🚨 SERANGAN TERDETEKSI - IP DIBLOKIR 5 MENIT 🚨🚨🚨`);
    console.log(`   IP           : ${ip}`);
    console.log(`   Kategori     : ${category}`);
    console.log(`   Alasan       : ${reason}`);
    console.log(`   Waktu blokir : ${new Date().toISOString()}`);
    console.log(`   Buka lagi at : ${new Date(unblockAt).toISOString()}`);
    console.log(`   Total pelanggaran IP ini: ${violations}`);
    console.log(`🚨🚨🚨-----------------------------------------------🚨🚨🚨\n`);
}

function recordAttackHit(ip, now, reason, category) {
    let times = attackLog.get(ip) || [];
    times = pruneOld(times, now, ATTACK_WINDOW_MS);
    times.push(now);
    attackLog.set(ip, times);

    console.log(`⚠️  [PROXY] Percobaan mencurigakan #${times.length} dari IP ${ip} -> ${reason}`);

    if (times.length >= MAX_ATTACK_HITS) {
        blockIP(ip, `${reason} (${times.length}x dalam ${ATTACK_WINDOW_MS / 1000} detik)`, category);
        attackLog.delete(ip);
        return true;
    }
    return false;
}

// ========== MIDDLEWARE 1: GUARD UTAMA ==========
function guard(req, res, next) {
    const ip = getClientIP(req);
    const now = Date.now();
    const pathName = req.path;

    // 1) Jika IP sedang dalam masa blokir -> tolak langsung
    const unblockAt = blockedIPs.get(ip);
    if (unblockAt) {
        if (now < unblockAt) {
            const remaining = Math.ceil((unblockAt - now) / 1000);
            res.setHeader('Retry-After', remaining);
            return res.status(429).json({
                success: false,
                message: `Akses Anda diblokir sementara karena aktivitas mencurigakan. Coba lagi dalam ${remaining} detik.`
            });
        }
        blockedIPs.delete(ip);
        requestLog.delete(ip);
        sensitiveLog.delete(ip);
        attackLog.delete(ip);
    }

    // 2) Probing path login/admin/panel yang tidak ada di aplikasi ini
    if (isAttackProbePath(pathName)) {
        const blocked = recordAttackHit(ip, now, `Mencoba akses path login/admin/panel palsu: "${pathName}"`, 'PROBE_LOGIN_ADMIN');
        if (blocked) {
            return res.status(429).json({ success: false, message: 'IP Anda diblokir sementara selama 5 menit.' });
        }
        return res.status(404).json({ success: false, message: 'Resource tidak ditemukan' });
    }

    // 3) Path traversal di URL
    if (hasPathTraversal(pathName) || hasPathTraversal(req.originalUrl)) {
        const blocked = recordAttackHit(ip, now, `Path traversal terdeteksi: "${req.originalUrl}"`, 'PATH_TRAVERSAL');
        if (blocked) {
            return res.status(429).json({ success: false, message: 'IP Anda diblokir sementara selama 5 menit.' });
        }
        return res.status(400).json({ success: false, message: 'Request tidak valid' });
    }

    // 4) SQL Injection di path atau query string
    const queryValues = flattenValues(req.query);
    const toScan = [pathName, ...queryValues];
    const sqliHit = toScan.find((v) => hasSqlInjection(v));
    if (sqliHit) {
        const blocked = recordAttackHit(ip, now, `Pola SQL Injection terdeteksi pada query/URL: "${sqliHit}"`, 'SQL_INJECTION');
        if (blocked) {
            return res.status(429).json({ success: false, message: 'IP Anda diblokir sementara selama 5 menit.' });
        }
        return res.status(400).json({ success: false, message: 'Request tidak valid' });
    }

    // 5) Rate limit umum -> deteksi flood/DDoS
    let generalTimes = requestLog.get(ip) || [];
    generalTimes = pruneOld(generalTimes, now, WINDOW_MS);
    generalTimes.push(now);
    requestLog.set(ip, generalTimes);

    if (generalTimes.length > MAX_REQUESTS_PER_WINDOW) {
        blockIP(ip, `Flood terdeteksi (${generalTimes.length} request dalam ${WINDOW_MS / 1000}s)`, 'DDOS_FLOOD');
        requestLog.delete(ip);
        return res.status(429).json({
            success: false,
            message: 'Terlalu banyak permintaan. IP Anda diblokir sementara selama 5 menit.'
        });
    }

    // 6) Rate limit lebih ketat untuk endpoint sensitif -> brute force
    if (isSensitivePath(pathName)) {
        let sensTimes = sensitiveLog.get(ip) || [];
        sensTimes = pruneOld(sensTimes, now, WINDOW_MS);
        sensTimes.push(now);
        sensitiveLog.set(ip, sensTimes);

        if (sensTimes.length > MAX_SENSITIVE_PER_WINDOW) {
            blockIP(ip, `Percobaan berulang ke endpoint sensitif "${pathName}" (${sensTimes.length}x dalam ${WINDOW_MS / 1000}s)`, 'BRUTE_FORCE');
            sensitiveLog.delete(ip);
            return res.status(429).json({
                success: false,
                message: 'Aktivitas mencurigakan terdeteksi. IP Anda diblokir sementara selama 5 menit.'
            });
        }
    }

    next();
}

// ========== MIDDLEWARE 2: CONTENT GUARD ==========
function contentGuard(req, res, next) {
    if (!req.body || typeof req.body !== 'object') return next();

    const ip = getClientIP(req);
    const now = Date.now();

    const unblockAt = blockedIPs.get(ip);
    if (unblockAt && now < unblockAt) {
        const remaining = Math.ceil((unblockAt - now) / 1000);
        res.setHeader('Retry-After', remaining);
        return res.status(429).json({
            success: false,
            message: `Akses Anda diblokir sementara. Coba lagi dalam ${remaining} detik.`
        });
    }

    const bodyValues = flattenValues(req.body);
    const sqliHit = bodyValues.find((v) => hasSqlInjection(v));
    if (sqliHit) {
        const blocked = recordAttackHit(ip, now, `Pola SQL Injection terdeteksi pada body request: "${sqliHit}"`, 'SQL_INJECTION_BODY');
        if (blocked) {
            return res.status(429).json({ success: false, message: 'IP Anda diblokir sementara selama 5 menit.' });
        }
        return res.status(400).json({ success: false, message: 'Data tidak valid' });
    }

    next();
}

// ========== PEMBERSIHAN BERKALA ==========
setInterval(() => {
    const now = Date.now();

    for (const [ip, unblockAt] of blockedIPs.entries()) {
        if (now >= unblockAt) {
            blockedIPs.delete(ip);
            violationCount.delete(ip);
        }
    }
    for (const [ip, times] of requestLog.entries()) {
        if (pruneOld(times, now, WINDOW_MS).length === 0) requestLog.delete(ip);
    }
    for (const [ip, times] of sensitiveLog.entries()) {
        if (pruneOld(times, now, WINDOW_MS).length === 0) sensitiveLog.delete(ip);
    }
    for (const [ip, times] of attackLog.entries()) {
        if (pruneOld(times, now, ATTACK_WINDOW_MS).length === 0) attackLog.delete(ip);
    }
}, CLEANUP_INTERVAL_MS);

// ========== HELPER MONITORING ==========
function getBlockedIPs() {
    const now = Date.now();
    return Array.from(blockedIPs.entries())
        .filter(([, unblockAt]) => unblockAt > now)
        .map(([ip, unblockAt]) => ({
            ip,
            remainingSeconds: Math.ceil((unblockAt - now) / 1000),
            violations: violationCount.get(ip) || 0
        }));
}

function unblockIPManual(ip) {
    blockedIPs.delete(ip);
    violationCount.delete(ip);
    requestLog.delete(ip);
    sensitiveLog.delete(ip);
    attackLog.delete(ip);
    console.log(`✅ [PROXY] IP dibuka manual: ${ip}`);
}

module.exports = guard;
module.exports.guard = guard;
module.exports.contentGuard = contentGuard;
module.exports.getBlockedIPs = getBlockedIPs;
module.exports.unblockIP = unblockIPManual;