// ranking-api.js
// Client-side API untuk mengakses data ranking dari server

const RankingAPI = (function() {
    'use strict';

    // ========== KONFIGURASI ==========
    // Menggunakan path relatif, tidak perlu base URL
    const API_PATH = '/api/tokens-imdyi82tsntakfAhrektdbyrhfw8eu/test/iq/test/iq';
    
    // ========== FUNGSI API ==========

    /**
     * Mendapatkan semua data ranking dari server
     * @returns {Promise<Array>} Data ranking
     */
    async function getRankingData() {
        try {
            const response = await fetch(`${API_PATH}/ranking`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            return data.success ? data.data : [];
        } catch (error) {
            console.error('Error fetching ranking data:', error);
            // Fallback ke localStorage jika server offline
            return getLocalRankingData();
        }
    }

    /**
     * Menambahkan atau memperbarui data user di server
     * @param {Object} userData - Data user
     * @param {string} userData.name - Nama user
     * @param {number} userData.iq - Skor IQ
     * @param {number} userData.correct - Jawaban benar
     * @param {number} userData.total - Total soal
     * @param {string} userData.time - Waktu pengerjaan
     * @param {string} userData.category - Kategori IQ
     * @returns {Promise<Object>} Response dari server
     */
    async function saveUserRanking(userData) {
        try {
            const response = await fetch(`${API_PATH}/ranking`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(userData)
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            
            // Backup ke localStorage
            saveToLocalRanking(userData);
            
            return data;
        } catch (error) {
            console.error('Error saving ranking data:', error);
            // Fallback ke localStorage jika server offline
            saveToLocalRanking(userData);
            return { 
                success: false, 
                message: 'Server offline, data disimpan lokal',
                data: getLocalRankingData()
            };
        }
    }

    /**
     * Menghapus semua data ranking (admin only)
     * @returns {Promise<Object>} Response dari server
     */
    async function clearAllRanking() {
        try {
            const response = await fetch(`${API_PATH}/ranking/clear`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            // Hapus juga dari localStorage
            localStorage.removeItem('iq_ranking_data_backup');
            return data;
        } catch (error) {
            console.error('Error clearing ranking data:', error);
            return { success: false, message: error.message };
        }
    }

    /**
     * Mendapatkan statistik ranking
     * @returns {Promise<Object>} Statistik
     */
    async function getRankingStats() {
        try {
            const response = await fetch(`${API_PATH}/ranking/stats`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            return data.success ? data.data : null;
        } catch (error) {
            console.error('Error fetching stats:', error);
            return null;
        }
    }

    /**
     * Mencari user berdasarkan nama
     * @param {string} name - Nama user
     * @returns {Promise<Object>} Data user
     */
    async function findUser(name) {
        try {
            const response = await fetch(`${API_PATH}/ranking/search?name=${encodeURIComponent(name)}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            return data.success ? data.data : null;
        } catch (error) {
            console.error('Error finding user:', error);
            return null;
        }
    }

    // ========== FUNGSI BACKUP LOKAL ==========

    function getLocalRankingData() {
        try {
            const data = localStorage.getItem('iq_ranking_data_backup');
            return data ? JSON.parse(data) : [];
        } catch (e) {
            return [];
        }
    }

    function saveToLocalRanking(userData) {
        try {
            const data = getLocalRankingData();
            const existing = data.find(u => u.name.toLowerCase() === userData.name.toLowerCase());
            if (existing) {
                Object.assign(existing, userData);
            } else {
                data.push(userData);
            }
            localStorage.setItem('iq_ranking_data_backup', JSON.stringify(data));
        } catch (e) {
            console.error('Error saving to local backup:', e);
        }
    }

    // ========== PUBLIC API ==========
    return {
        getRankingData,
        saveUserRanking,
        clearAllRanking,
        getRankingStats,
        findUser
    };

})();

// Export untuk penggunaan
if (typeof module !== 'undefined' && module.exports) {
    module.exports = RankingAPI;
}