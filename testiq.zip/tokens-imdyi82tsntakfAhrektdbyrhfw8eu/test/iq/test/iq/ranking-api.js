// ranking-api.js
// Client-side API untuk mengakses data ranking dari server

const RankingAPI = (function() {
    'use strict';

    // ========== KONFIGURASI ==========
    // PAKAI DOMAIN PUBLIK
    const API_BASE_URL = 'http://testiq.xonepanel.qzz.io/api/tokens-imdyi82tsntakfAhrektdbyrhfw8eu/test/iq/test/iq';
    
    // ========== FUNGSI API ==========

    async function getRankingData() {
        try {
            const response = await fetch(`${API_BASE_URL}/ranking`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            return data.success ? data.data : [];
        } catch (error) {
            console.error('Error fetching ranking data:', error);
            return getLocalRankingData();
        }
    }

    async function saveUserRanking(userData) {
        try {
            const response = await fetch(`${API_BASE_URL}/ranking`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(userData)
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            saveToLocalRanking(userData);
            return data;
        } catch (error) {
            console.error('Error saving ranking data:', error);
            saveToLocalRanking(userData);
            return { 
                success: false, 
                message: 'Server offline, data disimpan lokal',
                data: getLocalRankingData()
            };
        }
    }

    async function clearAllRanking() {
        try {
            const response = await fetch(`${API_BASE_URL}/ranking/clear`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            localStorage.removeItem('iq_ranking_data_backup');
            return data;
        } catch (error) {
            console.error('Error clearing ranking data:', error);
            return { success: false, message: error.message };
        }
    }

    async function getRankingStats() {
        try {
            const response = await fetch(`${API_BASE_URL}/ranking/stats`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            return data.success ? data.data : null;
        } catch (error) {
            console.error('Error fetching stats:', error);
            return null;
        }
    }

    async function findUser(name) {
        try {
            const response = await fetch(`${API_BASE_URL}/ranking/search?name=${encodeURIComponent(name)}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            return data.success ? data.data : null;
        } catch (error) {
            console.error('Error finding user:', error);
            return null;
        }
    }

    // ========== FUNGSI BACKUP LOKAL ==========

    function getLocalRankingData() {
        try {
            const data = localStorage.getItem('iq_ranking_data_backup');
            return data ? JSON.parse(data) : [];
        } catch (e) {
            return [];
        }
    }

    function saveToLocalRanking(userData) {
        try {
            const data = getLocalRankingData();
            const existing = data.find(u => u.name.toLowerCase() === userData.name.toLowerCase());
            if (existing) {
                Object.assign(existing, userData);
            } else {
                data.push(userData);
            }
            localStorage.setItem('iq_ranking_data_backup', JSON.stringify(data));
        } catch (e) {
            console.error('Error saving to local backup:', e);
        }
    }

    // ========== PUBLIC API ==========
    return {
        getRankingData,
        saveUserRanking,
        clearAllRanking,
        getRankingStats,
        findUser
    };

})();

// Export untuk penggunaan
if (typeof module !== 'undefined' && module.exports) {
    module.exports = RankingAPI;
}