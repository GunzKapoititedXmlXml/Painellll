// ============================================================
// BANK SOAL IQ TEST - 100 SOAL
// ============================================================

const BANK_SOAL = [
  // ========== MATEMATIKA (20 SOAL) ==========
  {
    id: 1,
    mataPelajaran: "Matematika",
    tingkat: "Sulit",
    question: "Jika x² - 5x + 6 = 0, berapakah akar-akar persamaan tersebut?",
    options: ["2 dan 3", "1 dan 6", "-2 dan -3", "-1 dan -6"],
    answer: "2 dan 3"
  },
  {
    id: 2,
    mataPelajaran: "Matematika",
    tingkat: "Sulit",
    question: "Berapakah hasil dari integral (2x + 3) dx?",
    options: ["x² + 3x + C", "x² + 3x", "2x² + 3x + C", "x² + 3x + C"],
    answer: "x² + 3x + C"
  },
  {
    id: 3,
    mataPelajaran: "Matematika",
    tingkat: "Sulit",
    question: "Jika log₂(8) = x, berapakah nilai x?",
    options: ["2", "3", "4", "8"],
    answer: "3"
  },
  {
    id: 4,
    mataPelajaran: "Matematika",
    tingkat: "Sulit",
    question: "Berapakah hasil dari 7! ?",
    options: ["5040", "720", "40320", "50400"],
    answer: "5040"
  },
  {
    id: 5,
    mataPelajaran: "Matematika",
    tingkat: "Sulit",
    question: "Jika f(x) = x³ - 3x² + 2x, berapakah f'(2)?",
    options: ["2", "4", "6", "8"],
    answer: "2"
  },
  {
    id: 6,
    mataPelajaran: "Matematika",
    tingkat: "Sulit",
    question: "Berapakah nilai dari sin(30°) + cos(60°)?",
    options: ["0.5", "1", "1.5", "2"],
    answer: "1"
  },
  {
    id: 7,
    mataPelajaran: "Matematika",
    tingkat: "Sulit",
    question: "Jika 2x + 3y = 12 dan x - y = 1, berapakah nilai x?",
    options: ["2", "3", "4", "5"],
    answer: "3"
  },
  {
    id: 8,
    mataPelajaran: "Matematika",
    tingkat: "Sulit",
    question: "Berapakah jumlah deret geometri tak hingga: 2 + 1 + 0.5 + 0.25 + ...?",
    options: ["3", "4", "5", "6"],
    answer: "4"
  },
  {
    id: 9,
    mataPelajaran: "Matematika",
    tingkat: "Sulit",
    question: "Jika A = {1,2,3} dan B = {2,3,4}, berapakah A ∩ B?",
    options: ["{1,4}", "{2,3}", "{1,2,3}", "{2,3,4}"],
    answer: "{2,3}"
  },
  {
    id: 10,
    mataPelajaran: "Matematika",
    tingkat: "Sulit",
    question: "Berapakah nilai dari akar(169)?",
    options: ["11", "12", "13", "14"],
    answer: "13"
  },
  {
    id: 11,
    mataPelajaran: "Matematika",
    tingkat: "Sulit",
    question: "Jika P(A) = 0.3 dan P(B) = 0.4, berapakah P(A∪B) jika A dan B saling lepas?",
    options: ["0.1", "0.7", "0.12", "0.3"],
    answer: "0.7"
  },
  {
    id: 12,
    mataPelajaran: "Matematika",
    tingkat: "Sulit",
    question: "Berapakah hasil dari 2³ × 2⁴?",
    options: ["2⁷", "2¹²", "4⁷", "8⁷"],
    answer: "2⁷"
  },
  {
    id: 13,
    mataPelajaran: "Matematika",
    tingkat: "Sulit",
    question: "Jika persamaan garis y = 2x + 3, berapakah gradiennya?",
    options: ["2", "3", "-2", "-3"],
    answer: "2"
  },
  {
    id: 14,
    mataPelajaran: "Matematika",
    tingkat: "Sulit",
    question: "Berapakah luas lingkaran dengan jari-jari 7 cm?",
    options: ["154 cm²", "44 cm²", "22 cm²", "154 cm²"],
    answer: "154 cm²"
  },
  {
    id: 15,
    mataPelajaran: "Matematika",
    tingkat: "Sulit",
    question: "Jika x:y = 3:4 dan y:z = 2:3, berapakah x:z?",
    options: ["1:2", "2:3", "3:4", "1:2"],
    answer: "1:2"
  },
  {
    id: 16,
    mataPelajaran: "Matematika",
    tingkat: "Sulit",
    question: "Berapakah nilai dari (2+3i)(2-3i)?",
    options: ["13", "-5", "4-9i", "4+9i"],
    answer: "13"
  },
  {
    id: 17,
    mataPelajaran: "Matematika",
    tingkat: "Sulit",
    question: "Jika f(x) = 2x² - 5x + 3, berapakah f(1)?",
    options: ["0", "1", "2", "3"],
    answer: "0"
  },
  {
    id: 18,
    mataPelajaran: "Matematika",
    tingkat: "Sulit",
    question: "Berapakah hasil dari 10P3?",
    options: ["720", "120", "1000", "30"],
    answer: "720"
  },
  {
    id: 19,
    mataPelajaran: "Matematika",
    tingkat: "Sulit",
    question: "Jika x² - 9 = 0, berapakah nilai x?",
    options: ["3", "-3", "±3", "9"],
    answer: "±3"
  },
  {
    id: 20,
    mataPelajaran: "Matematika",
    tingkat: "Sulit",
    question: "Berapakah nilai dari 5! × 3!?",
    options: ["120", "720", "360", "30"],
    answer: "720"
  },

  // ========== LOGIKA (20 SOAL) ==========
  {
    id: 21,
    mataPelajaran: "Logika",
    tingkat: "Sulit",
    question: "Jika semua P adalah Q dan semua Q adalah R, maka...",
    options: ["Semua P adalah R", "Semua R adalah P", "Semua P adalah Q", "Tidak ada kesimpulan"],
    answer: "Semua P adalah R"
  },
  {
    id: 22,
    mataPelajaran: "Logika",
    tingkat: "Sulit",
    question: "Kontraposisi dari 'Jika hujan maka jalan basah' adalah...",
    options: ["Jika jalan tidak basah maka tidak hujan", "Jika hujan maka jalan tidak basah", "Jika jalan basah maka hujan", "Jika tidak hujan maka jalan tidak basah"],
    answer: "Jika jalan tidak basah maka tidak hujan"
  },
  {
    id: 23,
    mataPelajaran: "Logika",
    tingkat: "Sulit",
    question: "Diberikan premis: Semua ilmuan adalah pekerja keras. Beberapa pekerja keras adalah seniman. Maka...",
    options: ["Semua ilmuan adalah seniman", "Beberapa ilmuan adalah seniman", "Semua seniman adalah ilmuan", "Tidak ada kesimpulan"],
    answer: "Tidak ada kesimpulan"
  },
  {
    id: 24,
    mataPelajaran: "Logika",
    tingkat: "Sulit",
    question: "Jika p → q dan q → r, maka pernyataan yang benar adalah...",
    options: ["p → r", "r → p", "q → p", "r → q"],
    answer: "p → r"
  },
  {
    id: 25,
    mataPelajaran: "Logika",
    tingkat: "Sulit",
    question: "Negasi dari 'Semua mahasiswa rajin' adalah...",
    options: ["Ada mahasiswa yang tidak rajin", "Semua mahasiswa tidak rajin", "Tidak ada mahasiswa rajin", "Semua mahasiswa malas"],
    answer: "Ada mahasiswa yang tidak rajin"
  },
  {
    id: 26,
    mataPelajaran: "Logika",
    tingkat: "Sulit",
    question: "Jika A > B dan B = C, maka hubungan A dan C adalah...",
    options: ["A > C", "A < C", "A = C", "Tidak bisa ditentukan"],
    answer: "A > C"
  },
  {
    id: 27,
    mataPelajaran: "Logika",
    tingkat: "Sulit",
    question: "Diberikan: 'Beberapa siswa suka matematika' dan 'Semua siswa suka fisika'. Maka...",
    options: ["Beberapa siswa suka keduanya", "Semua siswa suka matematika", "Tidak ada siswa suka matematika", "Tidak ada kesimpulan"],
    answer: "Beberapa siswa suka keduanya"
  },
  {
    id: 28,
    mataPelajaran: "Logika",
    tingkat: "Sulit",
    question: "Jika 'Tidak ada A yang B' benar, maka...",
    options: ["Beberapa A adalah B", "Semua A adalah B", "Beberapa A bukan B", "Semua A bukan B"],
    answer: "Semua A bukan B"
  },
  {
    id: 29,
    mataPelajaran: "Logika",
    tingkat: "Sulit",
    question: "Silogisme: Semua M adalah P. Semua S adalah M. Maka...",
    options: ["Semua S adalah P", "Semua P adalah S", "Beberapa S adalah P", "Tidak ada kesimpulan"],
    answer: "Semua S adalah P"
  },
  {
    id: 30,
    mataPelajaran: "Logika",
    tingkat: "Sulit",
    question: "Jika X → Y dan ¬Y, maka...",
    options: ["¬X", "X", "Y", "Tidak ada kesimpulan"],
    answer: "¬X"
  },
  {
    id: 31,
    mataPelajaran: "Logika",
    tingkat: "Sulit",
    question: "Diberikan: 'Jika hari cerah maka saya pergi jalan' dan 'Saya tidak pergi jalan'. Maka...",
    options: ["Hari cerah", "Hari tidak cerah", "Hari hujan", "Tidak ada kesimpulan"],
    answer: "Hari tidak cerah"
  },
  {
    id: 32,
    mataPelajaran: "Logika",
    tingkat: "Sulit",
    question: "Manakah yang merupakan invers dari 'Jika p maka q'?",
    options: ["Jika q maka p", "Jika ¬p maka ¬q", "Jika ¬q maka ¬p", "q jika dan hanya jika p"],
    answer: "Jika ¬p maka ¬q"
  },
  {
    id: 33,
    mataPelajaran: "Logika",
    tingkat: "Sulit",
    question: "Premis: Semua kucing adalah hewan. Beberapa hewan adalah anjing. Maka...",
    options: ["Beberapa kucing adalah anjing", "Semua kucing adalah anjing", "Semua anjing adalah kucing", "Tidak ada kesimpulan"],
    answer: "Tidak ada kesimpulan"
  },
  {
    id: 34,
    mataPelajaran: "Logika",
    tingkat: "Sulit",
    question: "Jika P ↔ Q benar, maka...",
    options: ["P → Q dan Q → P", "P → Q saja", "Q → P saja", "P dan Q saling bertentangan"],
    answer: "P → Q dan Q → P"
  },
  {
    id: 35,
    mataPelajaran: "Logika",
    tingkat: "Sulit",
    question: "Manakah yang merupakan tautologi?",
    options: ["p ∧ ¬p", "p ∨ ¬p", "p → ¬p", "¬p → p"],
    answer: "p ∨ ¬p"
  },
  {
    id: 36,
    mataPelajaran: "Logika",
    tingkat: "Sulit",
    question: "Jika 'Beberapa guru adalah seniman' benar, maka...",
    options: ["Semua guru adalah seniman", "Ada guru yang bukan seniman", "Ada seniman yang guru", "Tidak ada kesimpulan"],
    answer: "Ada seniman yang guru"
  },
  {
    id: 37,
    mataPelajaran: "Logika",
    tingkat: "Sulit",
    question: "Hukum De Morgan: ¬(p ∧ q) ekuivalen dengan...",
    options: ["¬p ∨ ¬q", "¬p ∧ ¬q", "p ∨ q", "¬(p ∨ q)"],
    answer: "¬p ∨ ¬q"
  },
  {
    id: 38,
    mataPelajaran: "Logika",
    tingkat: "Sulit",
    question: "Jika A = B dan B ≠ C, maka hubungan A dan C...",
    options: ["A = C", "A ≠ C", "A > C", "Tidak bisa ditentukan"],
    answer: "A ≠ C"
  },
  {
    id: 39,
    mataPelajaran: "Logika",
    tingkat: "Sulit",
    question: "Manakah yang benar tentang argumen: 'Semua burung bisa terbang. Penguin adalah burung. Maka penguin bisa terbang.'",
    options: ["Valid", "Tidak valid", "Premis salah", "Kesimpulan benar"],
    answer: "Tidak valid"
  },
  {
    id: 40,
    mataPelajaran: "Logika",
    tingkat: "Sulit",
    question: "Jika p dan q adalah pernyataan, (p ∨ q) ∧ ¬p ekuivalen dengan...",
    options: ["q", "p", "¬q", "p ∧ q"],
    answer: "q"
  },

  // ========== BAHASA INDONESIA (15 SOAL) ==========
  {
    id: 41,
    mataPelajaran: "Bahasa Indonesia",
    tingkat: "Sulit",
    question: "Sinonim dari kata 'ambivalen' adalah...",
    options: ["Bimbang", "Tegas", "Pasti", "Ragu"],
    answer: "Bimbang"
  },
  {
    id: 42,
    mataPelajaran: "Bahasa Indonesia",
    tingkat: "Sulit",
    question: "Antonim dari kata 'progresif' adalah...",
    options: ["Konservatif", "Modern", "Dinamis", "Inovatif"],
    answer: "Konservatif"
  },
  {
    id: 43,
    mataPelajaran: "Bahasa Indonesia",
    tingkat: "Sulit",
    question: "Makna idiom 'buah bibir' adalah...",
    options: ["Topik pembicaraan", "Buah favorit", "Bibir manis", "Kata-kata manis"],
    answer: "Topik pembicaraan"
  },
  {
    id: 44,
    mataPelajaran: "Bahasa Indonesia",
    tingkat: "Sulit",
    question: "Kalimat yang menggunakan kata serapan dengan benar adalah...",
    options: ["Aktivitas belajarnya padat", "Aktifitas belajarnya padat", "Aktifitas belajarnya padat", "Aktifitas belajarnya padat"],
    answer: "Aktivitas belajarnya padat"
  },
  {
    id: 45,
    mataPelajaran: "Bahasa Indonesia",
    tingkat: "Sulit",
    question: "Sinonim dari 'kontemporer' adalah...",
    options: ["Modern", "Kuno", "Tradisional", "Klasik"],
    answer: "Modern"
  },
  {
    id: 46,
    mataPelajaran: "Bahasa Indonesia",
    tingkat: "Sulit",
    question: "Makna kata 'metamorfosis' dalam puisi adalah...",
    options: ["Perubahan bentuk", "Perubahan warna", "Pertumbuhan", "Perkembangan"],
    answer: "Perubahan bentuk"
  },
  {
    id: 47,
    mataPelajaran: "Bahasa Indonesia",
    tingkat: "Sulit",
    question: "Kalimat baku: 'Di mana kamu tinggal?' yang benar adalah...",
    options: ["Di mana kamu tinggal?", "Kamu tinggal di mana?", "Dimana kamu tinggal?", "Kamu tinggal dimana?"],
    answer: "Kamu tinggal di mana?"
  },
  {
    id: 48,
    mataPelajaran: "Bahasa Indonesia",
    tingkat: "Sulit",
    question: "Antonim dari 'anarkis' adalah...",
    options: ["Patuh", "Kacau", "Keras", "Bebas"],
    answer: "Patuh"
  },
  {
    id: 49,
    mataPelajaran: "Bahasa Indonesia",
    tingkat: "Sulit",
    question: "Sinonim dari 'absolut' adalah...",
    options: ["Mutlak", "Relatif", "Bergantung", "Berubah"],
    answer: "Mutlak"
  },
  {
    id: 50,
    mataPelajaran: "Bahasa Indonesia",
    tingkat: "Sulit",
    question: "Makna kata 'epistemologi' adalah...",
    options: ["Ilmu pengetahuan", "Filosofi pengetahuan", "Metode ilmiah", "Logika"],
    answer: "Filosofi pengetahuan"
  },
  {
    id: 51,
    mataPelajaran: "Bahasa Indonesia",
    tingkat: "Sulit",
    question: "Kalimat pasif dari 'Mereka membangun jembatan' adalah...",
    options: ["Jembatan dibangun oleh mereka", "Jembatan mereka bangun", "Mereka bangun jembatan", "Jembatan sedang dibangun"],
    answer: "Jembatan dibangun oleh mereka"
  },
  {
    id: 52,
    mataPelajaran: "Bahasa Indonesia",
    tingkat: "Sulit",
    question: "Antonim dari 'konsisten' adalah...",
    options: ["Inkonsisten", "Konstan", "Stabil", "Tetap"],
    answer: "Inkonsisten"
  },
  {
    id: 53,
    mataPelajaran: "Bahasa Indonesia",
    tingkat: "Sulit",
    question: "Sinonim dari 'relevan' adalah...",
    options: ["Berkaitan", "Terpisah", "Jauh", "Berbeda"],
    answer: "Berkaitan"
  },
  {
    id: 54,
    mataPelajaran: "Bahasa Indonesia",
    tingkat: "Sulit",
    question: "Makna 'antitesis' dalam wacana adalah...",
    options: ["Pertentangan", "Persamaan", "Perbandingan", "Penguatan"],
    answer: "Pertentangan"
  },
  {
    id: 55,
    mataPelajaran: "Bahasa Indonesia",
    tingkat: "Sulit",
    question: "Kalimat yang mengandung kata tidak baku adalah...",
    options: ["Saya nggak datang", "Saya tidak datang", "Saya bukan datang", "Saya tak datang"],
    answer: "Saya nggak datang"
  },

  // ========== SAINS (15 SOAL) ==========
  {
    id: 56,
    mataPelajaran: "Sains",
    tingkat: "Sulit",
    question: "Apa yang dimaksud dengan teori relativitas Einstein?",
    options: ["Hubungan ruang dan waktu", "Gravitasi kuantum", "Mekanika kuantum", "Termodinamika"],
    answer: "Hubungan ruang dan waktu"
  },
  {
    id: 57,
    mataPelajaran: "Sains",
    tingkat: "Sulit",
    question: "Siapa yang menemukan DNA?",
    options: ["Watson dan Crick", "Einstein", "Newton", "Darwin"],
    answer: "Watson dan Crick"
  },
  {
    id: 58,
    mataPelajaran: "Sains",
    tingkat: "Sulit",
    question: "Apa yang dimaksud dengan 'Big Bang'?",
    options: ["Ledakan besar awal alam semesta", "Bintang meledak", "Galaksi bertabrakan", "Planet terbentuk"],
    answer: "Ledakan besar awal alam semesta"
  },
  {
    id: 59,
    mataPelajaran: "Sains",
    tingkat: "Sulit",
    question: "Unsur kimia dengan simbol 'Fe' adalah...",
    options: ["Besi", "Fosfor", "Fluorin", "Ferium"],
    answer: "Besi"
  },
  {
    id: 60,
    mataPelajaran: "Sains",
    tingkat: "Sulit",
    question: "Apa yang dimaksud dengan sel stem?",
    options: ["Sel yang belum berdiferensiasi", "Sel yang telah mati", "Sel khusus", "Sel reproduksi"],
    answer: "Sel yang belum berdiferensiasi"
  },
  {
    id: 61,
    mataPelajaran: "Sains",
    tingkat: "Sulit",
    question: "Planet terbesar di tata surya adalah...",
    options: ["Jupiter", "Saturnus", "Neptunus", "Uranus"],
    answer: "Jupiter"
  },
  {
    id: 62,
    mataPelajaran: "Sains",
    tingkat: "Sulit",
    question: "Apa yang menyebabkan pasang surut air laut?",
    options: ["Gravitasi bulan dan matahari", "Rotasi bumi", "Revolusi bumi", "Angin"],
    answer: "Gravitasi bulan dan matahari"
  },
  {
    id: 63,
    mataPelajaran: "Sains",
    tingkat: "Sulit",
    question: "Organ yang bertanggung jawab untuk mengatur suhu tubuh adalah...",
    options: ["Hipotalamus", "Jantung", "Paru-paru", "Hati"],
    answer: "Hipotalamus"
  },
  {
    id: 64,
    mataPelajaran: "Sains",
    tingkat: "Sulit",
    question: "Apa yang dimaksud dengan 'fotosintesis'?",
    options: ["Proses pembuatan makanan pada tumbuhan", "Proses pernapasan tumbuhan", "Proses perkembangbiakan", "Proses penguapan"],
    answer: "Proses pembuatan makanan pada tumbuhan"
  },
  {
    id: 65,
    mataPelajaran: "Sains",
    tingkat: "Sulit",
    question: "Partikel terkecil penyusun atom adalah...",
    options: ["Elektron", "Proton", "Neutron", "Nukleon"],
    answer: "Elektron"
  },
  {
    id: 66,
    mataPelajaran: "Sains",
    tingkat: "Sulit",
    question: "Apa yang dimaksud dengan 'enzim'?",
    options: ["Protein yang mempercepat reaksi", "Hormon", "Vitamin", "Lemak"],
    answer: "Protein yang mempercepat reaksi"
  },
  {
    id: 67,
    mataPelajaran: "Sains",
    tingkat: "Sulit",
    question: "Bintang terdekat dengan bumi adalah...",
    options: ["Matahari", "Proxima Centauri", "Alpha Centauri", "Sirius"],
    answer: "Matahari"
  },
  {
    id: 68,
    mataPelajaran: "Sains",
    tingkat: "Sulit",
    question: "Apa yang dimaksud dengan 'antibodi'?",
    options: ["Protein melawan antigen", "Sel darah merah", "Sel darah putih", "Enzim pencernaan"],
    answer: "Protein melawan antigen"
  },
  {
    id: 69,
    mataPelajaran: "Sains",
    tingkat: "Sulit",
    question: "Hukum Newton kedua menyatakan bahwa...",
    options: ["F = ma", "F = mg", "F = mv", "F = m/a"],
    answer: "F = ma"
  },
  {
    id: 70,
    mataPelajaran: "Sains",
    tingkat: "Sulit",
    question: "Gas yang paling banyak di atmosfer bumi adalah...",
    options: ["Nitrogen", "Oksigen", "Karbon dioksida", "Argon"],
    answer: "Nitrogen"
  },

  // ========== PENGETAHUAN UMUM (15 SOAL) ==========
  {
    id: 71,
    mataPelajaran: "Pengetahuan Umum",
    tingkat: "Sulit",
    question: "Bendera negara mana yang terdiri dari tiga warna vertikal: merah, putih, biru?",
    options: ["Prancis", "Italia", "Belanda", "Jerman"],
    answer: "Prancis"
  },
  {
    id: 72,
    mataPelajaran: "Pengetahuan Umum",
    tingkat: "Sulit",
    question: "Siapa penulis novel 'One Hundred Years of Solitude'?",
    options: ["Gabriel Garcia Marquez", "Ernest Hemingway", "Mark Twain", "Leo Tolstoy"],
    answer: "Gabriel Garcia Marquez"
  },
  {
    id: 73,
    mataPelajaran: "Pengetahuan Umum",
    tingkat: "Sulit",
    question: "Apa mata uang Jepang?",
    options: ["Yen", "Won", "Yuan", "Dolar"],
    answer: "Yen"
  },
  {
    id: 74,
    mataPelajaran: "Pengetahuan Umum",
    tingkat: "Sulit",
    question: "Siapa raja Inggris yang dieksekusi pada tahun 1649?",
    options: ["Charles I", "Charles II", "James I", "Henry VIII"],
    answer: "Charles I"
  },
  {
    id: 75,
    mataPelajaran: "Pengetahuan Umum",
    tingkat: "Sulit",
    question: "Pertempuran Waterloo terjadi pada tahun...",
    options: ["1815", "1805", "1825", "1795"],
    answer: "1815"
  },
  {
    id: 76,
    mataPelajaran: "Pengetahuan Umum",
    tingkat: "Sulit",
    question: "Siapa yang menulis 'Manifesto Komunis' bersama Marx?",
    options: ["Engels", "Lenin", "Stalin", "Trotsky"],
    answer: "Engels"
  },
  {
    id: 77,
    mataPelajaran: "Pengetahuan Umum",
    tingkat: "Sulit",
    question: "Bangunan tertinggi di dunia saat ini adalah...",
    options: ["Burj Khalifa", "Menara Taipei", "Empire State", "Shanghai Tower"],
    answer: "Burj Khalifa"
  },
  {
    id: 78,
    mataPelajaran: "Pengetahuan Umum",
    tingkat: "Sulit",
    question: "Siapa pelukis Monalisa?",
    options: ["Leonardo da Vinci", "Michelangelo", "Raphael", "Donatello"],
    answer: "Leonardo da Vinci"
  },
  {
    id: 79,
    mataPelajaran: "Pengetahuan Umum",
    tingkat: "Sulit",
    question: "Negara dengan populasi terbanyak di dunia adalah...",
    options: ["China", "India", "Amerika Serikat", "Indonesia"],
    answer: "China"
  },
  {
    id: 80,
    mataPelajaran: "Pengetahuan Umum",
    tingkat: "Sulit",
    question: "Perguruan tinggi tertua di Eropa adalah...",
    options: ["Universitas Bologna", "Oxford", "Cambridge", "Sorbonne"],
    answer: "Universitas Bologna"
  },
  {
    id: 81,
    mataPelajaran: "Pengetahuan Umum",
    tingkat: "Sulit",
    question: "Siapa yang menemukan mesin cetak?",
    options: ["Gutenberg", "Caxton", "Franklin", "Edison"],
    answer: "Gutenberg"
  },
  {
    id: 82,
    mataPelajaran: "Pengetahuan Umum",
    tingkat: "Sulit",
    question: "Apa simbol kimia untuk emas?",
    options: ["Au", "Ag", "Fe", "Cu"],
    answer: "Au"
  },
  {
    id: 83,
    mataPelajaran: "Pengetahuan Umum",
    tingkat: "Sulit",
    question: "Siapa presiden AS yang membebaskan budak?",
    options: ["Abraham Lincoln", "George Washington", "Thomas Jefferson", "John Adams"],
    answer: "Abraham Lincoln"
  },
  {
    id: 84,
    mataPelajaran: "Pengetahuan Umum",
    tingkat: "Sulit",
    question: "Tembok Besar Cina dibangun untuk...",
    options: ["Melindungi dari serangan", "Monumen", "Perdagangan", "Transportasi"],
    answer: "Melindungi dari serangan"
  },
  {
    id: 85,
    mataPelajaran: "Pengetahuan Umum",
    tingkat: "Sulit",
    question: "Siapa yang menulis 'Hamlet'?",
    options: ["Shakespeare", "Marlowe", "Jonson", "Webster"],
    answer: "Shakespeare"
  },

  // ========== LOGIKA PENALARAN (15 SOAL) ==========
  {
    id: 86,
    mataPelajaran: "Logika Penalaran",
    tingkat: "Sulit",
    question: "Jika 2+3=10, 7+2=63, 6+5=66, maka 8+4=?",
    options: ["96", "88", "84", "78"],
    answer: "96"
  },
  {
    id: 87,
    mataPelajaran: "Logika Penalaran",
    tingkat: "Sulit",
    question: "Deret: 1, 2, 6, 24, 120, ... ?",
    options: ["720", "600", "840", "960"],
    answer: "720"
  },
  {
    id: 88,
    mataPelajaran: "Logika Penalaran",
    tingkat: "Sulit",
    question: "Jika A=1, B=2, C=3, ..., Z=26, berapa nilai 'IQ'?",
    options: ["17", "18", "19", "20"],
    answer: "17"
  },
  {
    id: 89,
    mataPelajaran: "Logika Penalaran",
    tingkat: "Sulit",
    question: "Berapa jumlah sudut dalam segi-10?",
    options: ["1440°", "1080°", "1260°", "1620°"],
    answer: "1440°"
  },
  {
    id: 90,
    mataPelajaran: "Logika Penalaran",
    tingkat: "Sulit",
    question: "Manakah yang berbeda: 3, 5, 7, 9, 11?",
    options: ["3", "5", "9", "11"],
    answer: "9"
  },
  {
    id: 91,
    mataPelajaran: "Logika Penalaran",
    tingkat: "Sulit",
    question: "Jika hari ini Kamis, 100 hari lagi hari apa?",
    options: ["Sabtu", "Minggu", "Senin", "Selasa"],
    answer: "Sabtu"
  },
  {
    id: 92,
    mataPelajaran: "Logika Penalaran",
    tingkat: "Sulit",
    question: "Berapa banyak segitiga pada gambar segi-5?",
    options: ["10", "15", "20", "25"],
    answer: "10"
  },
  {
    id: 93,
    mataPelajaran: "Logika Penalaran",
    tingkat: "Sulit",
    question: "Jika 3 kotak berisi 3 kucing, berapa banyak kotak yang dibutuhkan untuk 9 kucing?",
    options: ["9", "6", "3", "12"],
    answer: "9"
  },
  {
    id: 94,
    mataPelajaran: "Logika Penalaran",
    tingkat: "Sulit",
    question: "Deret: 2, 4, 8, 16, 32, ... ?",
    options: ["64", "62", "34", "48"],
    answer: "64"
  },
  {
    id: 95,
    mataPelajaran: "Logika Penalaran",
    tingkat: "Sulit",
    question: "Jika 5 orang membutuhkan 5 hari untuk menggali 5 lubang, berapa hari untuk 10 orang menggali 10 lubang?",
    options: ["5", "10", "15", "20"],
    answer: "5"
  },
  {
    id: 96,
    mataPelajaran: "Logika Penalaran",
    tingkat: "Sulit",
    question: "Berapa 1/2 dari 3/4?",
    options: ["3/8", "3/4", "1/4", "1/2"],
    answer: "3/8"
  },
  {
    id: 97,
    mataPelajaran: "Logika Penalaran",
    tingkat: "Sulit",
    question: "Jika 8 = 56, 7 = 42, 6 = 30, 5 = 20, maka 3 = ?",
    options: ["12", "6", "9", "15"],
    answer: "12"
  },
  {
    id: 98,
    mataPelajaran: "Logika Penalaran",
    tingkat: "Sulit",
    question: "Berapa nilai 1/3 dari 9/12?",
    options: ["1/4", "1/3", "1/2", "3/4"],
    answer: "1/4"
  },
  {
    id: 99,
    mataPelajaran: "Logika Penalaran",
    tingkat: "Sulit",
    question: "Jika 10 buku harganya Rp500.000, berapa harga 15 buku?",
    options: ["Rp750.000", "Rp500.000", "Rp1.000.000", "Rp250.000"],
    answer: "Rp750.000"
  },
  {
    id: 100,
    mataPelajaran: "Logika Penalaran",
    tingkat: "Sulit",
    question: "Berapa hari dalam 4 tahun?",
    options: ["1461", "1460", "1464", "1465"],
    answer: "1461"
  }
];

// ============================================================
// FUNGSI UNTUK MENGACAK PILIHAN JAWABAN
// ============================================================

function acakPilihan(soal) {
    var data = soal.options.map(function(text, index) {
        return {
            text: text,
            label: String.fromCharCode(65 + index)
        };
    });
    
    for (var i = data.length - 1; i > 0; i--) {
        var j = Math.floor(Math.random() * (i + 1));
        var temp = data[i];
        data[i] = data[j];
        data[j] = temp;
    }
    
    var jawabanBenar = null;
    for (var k = 0; k < data.length; k++) {
        if (data[k].text === soal.answer) {
            jawabanBenar = data[k];
            break;
        }
    }
    
    return {
        ...soal,
        options: data.map(function(item) { return item.text; }),
        answer: jawabanBenar ? jawabanBenar.text : soal.answer
    };
}

function getRandomQuestions(jumlah) {
    jumlah = jumlah || 35;
    var shuffled = BANK_SOAL.slice().sort(function() {
        return Math.random() - 0.5;
    });
    
    var selected = shuffled.slice(0, jumlah);
    var denganPilihanDiacak = selected.map(acakPilihan);
    
    if (denganPilihanDiacak.length < jumlah) {
        var tambahan = BANK_SOAL.slice(0, jumlah - denganPilihanDiacak.length).map(acakPilihan);
        return denganPilihanDiacak.concat(tambahan);
    }
    
    return denganPilihanDiacak;
}

function cekDistribusiJawaban(soalList) {
    var distribusi = { A: 0, B: 0, C: 0, D: 0 };
    
    for (var i = 0; i < soalList.length; i++) {
        var index = soalList[i].options.indexOf(soalList[i].answer);
        var label = String.fromCharCode(65 + index);
        distribusi[label]++;
    }
    
    return distribusi;
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { 
        BANK_SOAL: BANK_SOAL,
        getRandomQuestions: getRandomQuestions,
        acakPilihan: acakPilihan,
        cekDistribusiJawaban: cekDistribusiJawaban
    };
}