// config.js
// Konfigurasi global untuk IQ Test

const CONFIG = (function() {
    'use strict';

    return {
        // ========== STORAGE ==========
        STORAGE_KEY: 'iq_ranking_data_backup',
        USER_SESSION_KEY: 'iq_test_user_session',
        
        // ========== TEST ==========
        TOTAL_QUESTIONS: 35,
        
        // ========== API ==========
        // Untuk ranking-api.js
        API_BASE_URL: 'http://testiq.xonepanel.qzz.io/api/tokens-imdyi82tsntakfAhrektdbyrhfw8eu/test/iq/test/iq',
        
        // ========== SERTIFIKAT ==========
        CERTIFICATE: {
            name: 'International IQ Test',
            dateFormat: 'id-ID',
            defaultBg: 'bg-putih',
            bgOptions: [
                { id: 'bg-putih', label: 'Putih', style: 'bg-opt-putih' },
                { id: 'bg-kuning', label: 'Kuning', style: 'bg-opt-kuning' },
                { id: 'bg-ungu-muda', label: 'Ungu Muda', style: 'bg-opt-ungu-muda' },
                { id: 'bg-pink', label: 'Pink', style: 'bg-opt-pink' },
                { id: 'bg-oranye', label: 'Oranye', style: 'bg-opt-oranye' },
                { id: 'bg-ungu-putih', label: 'Ungu Putih', style: 'bg-opt-ungu-putih' },
                { id: 'bg-merah-putih', label: 'Merah Putih', style: 'bg-opt-merah-putih' },
                { id: 'bg-putih-2', label: 'Putih Elegan', style: 'bg-opt-putih-2' },
                { id: 'bg-emas', label: 'Emas', style: 'bg-opt-emas' },
                { id: 'bg-biru-muda', label: 'Biru Muda', style: 'bg-opt-biru-muda' },
                { id: 'bg-hijau-muda', label: 'Hijau Muda', style: 'bg-opt-hijau-muda' },
                { id: 'bg-ungu-tua', label: 'Ungu Tua', style: 'bg-opt-ungu-tua' },
                { id: 'bg-merah-muda', label: 'Merah Muda', style: 'bg-opt-merah-muda' },
                { id: 'bg-putih-polosan', label: 'Putih Polosan', style: 'bg-opt-putih-polosan' }
            ]
        }
    };

})();

// Export untuk penggunaan
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CONFIG;
}