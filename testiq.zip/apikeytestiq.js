// ============================================================
// KONFIGURASI API KEY - JANGAN UBAH MANUAL!
// ============================================================
const CONFIG = {
  "API_KEYS": [
    "AQ.Ab8RN6LG3M-Yn_Q0SSPF5hVwpiIPcuogEw05_VFx5TA87OMQdA"
  ],
  "GEMINI_MODEL": "gemini-2.5-flash-lite",
  "TOTAL_QUESTIONS": 35,
  "STORAGE_KEY": "iq_test_ranking",
  "USER_SESSION_KEY": "iq_current_user"
};

if (typeof module !== 'undefined' && module.exports) {
    module.exports = CONFIG;
}