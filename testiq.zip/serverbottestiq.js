const express = require('express');
const fs = require('fs');
const path = require('path');
const TelegramBot = require('node-telegram-bot-api');

const app = express();
const PORT = 9000;

// ============================================================
// KONFIGURASI - ISI SESUAI DATA ANDA
// ============================================================

// Token Bot Telegram (dapatkan dari @BotFather)
const BOT_TOKEN = '8524234680:AAF8x5tYxcNr8k7OxtQLYihGPHWbDCnhoOo';

// ID Admin Telegram (dapatkan dari @userinfobot)
const ADMIN_CHAT_ID = '8212614573';

// Path ke file apikeytestiq.js
const CONFIG_PATH = path.join(__dirname, 'apikeytestiq.js');

// ============================================================
// INISIALISASI
// ============================================================

let bot = null;
let botInitialized = false;

// Middleware
app.use(express.json());
app.use(express.static('.'));

// Inisialisasi Bot Telegram
try {
    if (BOT_TOKEN && BOT_TOKEN !== 'YOUR_BOT_TOKEN_HERE') {
        bot = new TelegramBot(BOT_TOKEN, { 
            polling: {
                interval: 300,
                autoStart: true,
                params: {
                    timeout: 10
                }
            }
        });
        botInitialized = true;
        console.log('✅ Bot Telegram berhasil diinisialisasi');
        setupBotCommands();
        setupBotButtons();
    } else {
        console.warn('⚠️ BOT_TOKEN tidak valid. Bot tidak aktif.');
    }
} catch (error) {
    console.error('❌ Gagal inisialisasi bot:', error.message);
}

// ============================================================
// FUNGSI BACA & TULIS CONFIG
// ============================================================

function readConfig() {
    try {
        if (!fs.existsSync(CONFIG_PATH)) {
            const defaultConfig = {
                API_KEYS: [],
                GEMINI_MODEL: "gemini-2.5-flash-lite",
                TOTAL_QUESTIONS: 35,
                STORAGE_KEY: "iq_test_ranking",
                USER_SESSION_KEY: "iq_current_user"
            };
            writeConfig(defaultConfig);
            return defaultConfig;
        }
        
        const content = fs.readFileSync(CONFIG_PATH, 'utf8');
        const match = content.match(/const CONFIG = ({[\s\S]*?});/);
        if (match) {
            const config = new Function(`return ${match[1]}`)();
            return config;
        }
        return null;
    } catch (error) {
        console.error('Error membaca config:', error.message);
        return null;
    }
}

function writeConfig(config) {
    try {
        const configStr = JSON.stringify(config, null, 2);
        const content = `// ============================================================\n`;
        const content2 = `// KONFIGURASI API KEY - JANGAN UBAH MANUAL!\n`;
        const content3 = `// ============================================================\n`;
        const content4 = `const CONFIG = ${configStr};\n\n`;
        const content5 = `if (typeof module !== 'undefined' && module.exports) {\n`;
        const content6 = `    module.exports = CONFIG;\n`;
        const content7 = `}`;
        
        fs.writeFileSync(CONFIG_PATH, content + content2 + content3 + content4 + content5 + content6 + content7);
        return true;
    } catch (error) {
        console.error('Error menulis config:', error.message);
        return false;
    }
}

function isAdmin(chatId) {
    return chatId.toString() === ADMIN_CHAT_ID;
}

// ============================================================
// TOMBOL-TomBOL TELEGRAM
// ============================================================

function setupBotButtons() {
    if (!bot) return;

    // ========== TOMBOL INLINE ==========
    // Tombol untuk menu utama
    const mainMenuButtons = {
        reply_markup: {
            inline_keyboard: [
                [
                    { text: '📊 Status', callback_data: 'status' },
                    { text: '🔑 List Keys', callback_data: 'listkeys' }
                ],
                [
                    { text: '➕ Add Key', callback_data: 'addkey' },
                    { text: '❌ Remove Key', callback_data: 'removekey' }
                ],
                [
                    { text: '🔍 Test Key', callback_data: 'testkey' },
                    { text: '📌 Set Model', callback_data: 'setmodel' }
                ],
                [
                    { text: '📝 Set Questions', callback_data: 'setquestions' },
                    { text: '📚 Help', callback_data: 'help' }
                ]
            ]
        }
    };

    // Tombol untuk kembali ke menu
    const backToMenuButton = {
        reply_markup: {
            inline_keyboard: [
                [{ text: '🔙 Kembali ke Menu', callback_data: 'menu' }]
            ]
        }
    };

    // ========== HANDLER CALLBACK QUERY ==========
    bot.on('callback_query', async (callbackQuery) => {
        const chatId = callbackQuery.message.chat.id;
        const messageId = callbackQuery.message.message_id;
        const data = callbackQuery.data;

        // Hanya admin yang bisa menggunakan
        if (!isAdmin(chatId)) {
            bot.answerCallbackQuery(callbackQuery.id, { text: '⛔ Anda bukan admin!', show_alert: true });
            return;
        }

        // Hapus pesan loading
        bot.answerCallbackQuery(callbackQuery.id);

        switch(data) {
            case 'menu':
                bot.editMessageText('📱 MENU UTAMA\n\nPilih salah satu tombol di bawah:', {
                    chat_id: chatId,
                    message_id: messageId,
                    reply_markup: mainMenuButtons.reply_markup
                });
                break;

            case 'status':
                const statusMsg = await getStatusMessage();
                bot.editMessageText(statusMsg, {
                    chat_id: chatId,
                    message_id: messageId,
                    reply_markup: backToMenuButton.reply_markup
                });
                break;

            case 'listkeys':
                const listMsg = await getListKeysMessage();
                bot.editMessageText(listMsg, {
                    chat_id: chatId,
                    message_id: messageId,
                    reply_markup: backToMenuButton.reply_markup
                });
                break;

            case 'addkey':
                bot.editMessageText('➕ TAMBAH API KEY\n\nKirimkan API key yang ingin ditambahkan.\n\nContoh: /addkey AQ.xxxxxxxxxxxxx', {
                    chat_id: chatId,
                    message_id: messageId,
                    reply_markup: backToMenuButton.reply_markup
                });
                break;

            case 'removekey':
                const keys = readConfig()?.API_KEYS || [];
                if (keys.length === 0) {
                    bot.editMessageText('📭 Tidak ada API keys yang bisa dihapus.', {
                        chat_id: chatId,
                        message_id: messageId,
                        reply_markup: backToMenuButton.reply_markup
                    });
                    return;
                }

                // Buat tombol untuk setiap key
                const removeButtons = {
                    reply_markup: {
                        inline_keyboard: keys.map((key, index) => {
                            const masked = key.substring(0, 10) + '...' + key.substring(key.length - 5);
                            return [{ text: `❌ ${masked}`, callback_data: `remove_${key}` }];
                        }).concat([
                            [{ text: '🔙 Kembali ke Menu', callback_data: 'menu' }]
                        ])
                    }
                };

                bot.editMessageText('❌ HAPUS API KEY\n\nPilih API key yang ingin dihapus:', {
                    chat_id: chatId,
                    message_id: messageId,
                    reply_markup: removeButtons.reply_markup
                });
                break;

            case 'testkey':
                bot.editMessageText('🔍 TEST API KEY\n\nKirimkan API key yang ingin dites.\n\nContoh: /testkey AQ.xxxxxxxxxxxxx', {
                    chat_id: chatId,
                    message_id: messageId,
                    reply_markup: backToMenuButton.reply_markup
                });
                break;

            case 'setmodel':
                bot.editMessageText('📌 SET MODEL\n\nKirimkan nama model yang ingin digunakan.\n\nContoh: /setmodel gemini-2.5-flash-lite\n\nModel yang tersedia:\n• gemini-2.5-flash-lite\n• gemini-2.0-flash\n• gemini-2.0-flash-lite', {
                    chat_id: chatId,
                    message_id: messageId,
                    reply_markup: backToMenuButton.reply_markup
                });
                break;

            case 'setquestions':
                bot.editMessageText('📝 SET JUMLAH SOAL\n\nKirimkan jumlah soal yang diinginkan (1-100).\n\nContoh: /setquestions 35', {
                    chat_id: chatId,
                    message_id: messageId,
                    reply_markup: backToMenuButton.reply_markup
                });
                break;

            case 'help':
                const helpMsg = await getHelpMessage();
                bot.editMessageText(helpMsg, {
                    chat_id: chatId,
                    message_id: messageId,
                    reply_markup: backToMenuButton.reply_markup
                });
                break;

            default:
                // Handle remove key
                if (data.startsWith('remove_')) {
                    const keyToRemove = data.replace('remove_', '');
                    const result = await removeKey(keyToRemove);
                    bot.editMessageText(result, {
                        chat_id: chatId,
                        message_id: messageId,
                        reply_markup: backToMenuButton.reply_markup
                    });
                }
                break;
        }
    });

    // ========== TOMBOL REPLY KEYBOARD (Permanent) ==========
    const replyKeyboard = {
        reply_markup: {
            keyboard: [
                ['📊 Status', '🔑 List Keys'],
                ['➕ Add Key', '❌ Remove Key'],
                ['🔍 Test Key', '📌 Set Model'],
                ['📝 Set Questions', '📚 Help']
            ],
            resize_keyboard: true,
            one_time_keyboard: false
        }
    };

    // Kirim keyboard saat /start
    bot.onText(/\/start/, (msg) => {
        const chatId = msg.chat.id;
        bot.sendMessage(chatId, '📱 MENU UTAMA\n\nPilih salah satu tombol di bawah:', replyKeyboard);
    });

    // Handle pesan dari tombol reply keyboard
    bot.on('message', (msg) => {
        const chatId = msg.chat.id;
        const text = msg.text;

        if (!isAdmin(chatId)) {
            bot.sendMessage(chatId, '⛔ Anda bukan admin!');
            return;
        }

        // Cek apakah pesan adalah perintah dari tombol
        switch(text) {
            case '📊 Status':
                bot.sendMessage(chatId, getStatusMessage());
                break;
            case '🔑 List Keys':
                bot.sendMessage(chatId, getListKeysMessage());
                break;
            case '➕ Add Key':
                bot.sendMessage(chatId, '➕ Kirimkan API key yang ingin ditambahkan.\n\nContoh: /addkey AQ.xxxxxxxxxxxxx');
                break;
            case '❌ Remove Key':
                const keys = readConfig()?.API_KEYS || [];
                if (keys.length === 0) {
                    bot.sendMessage(chatId, '📭 Tidak ada API keys yang bisa dihapus.');
                    return;
                }
                let msg = '❌ PILIH API KEY YANG DIHAPUS:\n\n';
                keys.forEach((key, index) => {
                    const masked = key.substring(0, 10) + '...' + key.substring(key.length - 5);
                    msg += `${index + 1}. ${masked}\n`;
                    msg += `   /removekey ${key}\n\n`;
                });
                bot.sendMessage(chatId, msg);
                break;
            case '🔍 Test Key':
                bot.sendMessage(chatId, '🔍 Kirimkan API key yang ingin dites.\n\nContoh: /testkey AQ.xxxxxxxxxxxxx');
                break;
            case '📌 Set Model':
                bot.sendMessage(chatId, '📌 Kirimkan nama model.\n\nContoh: /setmodel gemini-2.5-flash-lite');
                break;
            case '📝 Set Questions':
                bot.sendMessage(chatId, '📝 Kirimkan jumlah soal (1-100).\n\nContoh: /setquestions 35');
                break;
            case '📚 Help':
                bot.sendMessage(chatId, getHelpMessage());
                break;
        }
    });

    console.log('✅ Tombol bot siap digunakan');
}

// ============================================================
// FUNGSI BOT - COMMANDS
// ============================================================

function setupBotCommands() {
    if (!bot) return;

    // ========== COMMAND: /status ==========
    bot.onText(/\/status/, (msg) => {
        const chatId = msg.chat.id;
        if (!isAdmin(chatId)) {
            bot.sendMessage(chatId, '⛔ Anda bukan admin!');
            return;
        }
        bot.sendMessage(chatId, getStatusMessage());
    });

    // ========== COMMAND: /listkeys ==========
    bot.onText(/\/listkeys/, (msg) => {
        const chatId = msg.chat.id;
        if (!isAdmin(chatId)) {
            bot.sendMessage(chatId, '⛔ Anda bukan admin!');
            return;
        }
        bot.sendMessage(chatId, getListKeysMessage());
    });

    // ========== COMMAND: /addkey ==========
    bot.onText(/\/addkey (.+)/, async (msg, match) => {
        const chatId = msg.chat.id;
        if (!isAdmin(chatId)) {
            bot.sendMessage(chatId, '⛔ Anda bukan admin!');
            return;
        }

        const newKey = match[1].trim();
        const result = await addKey(newKey);
        bot.sendMessage(chatId, result);
    });

    // ========== COMMAND: /removekey ==========
    bot.onText(/\/removekey (.+)/, async (msg, match) => {
        const chatId = msg.chat.id;
        if (!isAdmin(chatId)) {
            bot.sendMessage(chatId, '⛔ Anda bukan admin!');
            return;
        }

        const keyToRemove = match[1].trim();
        const result = await removeKey(keyToRemove);
        bot.sendMessage(chatId, result);
    });

    // ========== COMMAND: /testkey ==========
    bot.onText(/\/testkey (.+)/, async (msg, match) => {
        const chatId = msg.chat.id;
        if (!isAdmin(chatId)) {
            bot.sendMessage(chatId, '⛔ Anda bukan admin!');
            return;
        }

        const key = match[1].trim();
        bot.sendMessage(chatId, '🔄 Sedang mengetes API key...');
        const result = await testKey(key);
        bot.sendMessage(chatId, result);
    });

    // ========== COMMAND: /setmodel ==========
    bot.onText(/\/setmodel (.+)/, (msg, match) => {
        const chatId = msg.chat.id;
        if (!isAdmin(chatId)) {
            bot.sendMessage(chatId, '⛔ Anda bukan admin!');
            return;
        }

        const newModel = match[1].trim();
        const result = setModel(newModel);
        bot.sendMessage(chatId, result);
    });

    // ========== COMMAND: /setquestions ==========
    bot.onText(/\/setquestions (.+)/, (msg, match) => {
        const chatId = msg.chat.id;
        if (!isAdmin(chatId)) {
            bot.sendMessage(chatId, '⛔ Anda bukan admin!');
            return;
        }

        const newTotal = parseInt(match[1].trim());
        const result = setQuestions(newTotal);
        bot.sendMessage(chatId, result);
    });

    // ========== COMMAND: /help ==========
    bot.onText(/\/help/, (msg) => {
        const chatId = msg.chat.id;
        bot.sendMessage(chatId, getHelpMessage());
    });

    console.log('✅ Perintah bot siap digunakan');
}

// ============================================================
// FUNGSI-FUNGSI UTAMA
// ============================================================

function getStatusMessage() {
    const config = readConfig();
    if (!config) return '❌ Gagal membaca apikeytestiq.js';

    const keys = config.API_KEYS || [];
    const fileExists = fs.existsSync(CONFIG_PATH);
    
    let status = `📊 STATUS CONFIG\n\n`;
    status += `📁 File apikeytestiq.js: ${fileExists ? '✅ Ada' : '❌ Tidak ada'}\n`;
    status += `🔑 Total API Keys: ${keys.length}\n`;
    status += `📌 Model: ${config.GEMINI_MODEL}\n`;
    status += `📝 Jumlah Soal: ${config.TOTAL_QUESTIONS}\n\n`;
    status += `🔍 DETAIL KEYS:\n`;
    
    if (keys.length === 0) {
        status += `   (Tidak ada API keys)\n`;
    } else {
        keys.forEach((k, i) => {
            const masked = k.length > 10 ? k.substring(0, 10) + '...' + k.substring(k.length - 5) : k;
            const valid = k.length > 10 ? '✅' : '❌';
            status += `   ${i+1}. ${masked} ${valid}\n`;
        });
    }
    
    status += `\n🕐 Last Update: ${new Date().toLocaleString('id-ID')}`;
    return status;
}

function getListKeysMessage() {
    const config = readConfig();
    if (!config) return '❌ Gagal membaca apikeytestiq.js';

    const keys = config.API_KEYS || [];
    if (keys.length === 0) {
        return '📭 Tidak ada API keys yang tersimpan.';
    }

    let message = `🔑 DAFTAR API KEYS (${keys.length})\n\n`;
    keys.forEach((key, index) => {
        const masked = key.length > 10 ? key.substring(0, 10) + '...' + key.substring(key.length - 5) : key;
        const valid = key.length > 10 ? '✅' : '❌';
        message += `${index + 1}. ${masked} ${valid}\n`;
    });
    
    return message;
}

function getHelpMessage() {
    return `
📚 DAFTAR PERINTAH LENGKAP

📊 /status - Lihat status config
🔑 /listkeys - Daftar semua API keys
➕ /addkey [key] - Tambah API key
❌ /removekey [key] - Hapus API key
🔍 /testkey [key] - Test validasi key
📌 /setmodel [model] - Ganti model
📝 /setquestions [jumlah] - Ganti jumlah soal
📚 /help - Bantuan ini
📱 /start - Menu utama

CONTOH PENGGUNAAN:
/addkey AQ.xxxxxxxxxxxxx
/removekey AQ.xxxxxxxxxxxxx
/testkey AQ.xxxxxxxxxxxxx
/setmodel gemini-2.5-flash-lite
/setquestions 40

MODEL YANG TERSEDIA:
• gemini-2.5-flash-lite (default)
• gemini-2.0-flash
• gemini-2.0-flash-lite
    `;
}

async function addKey(newKey) {
    if (!newKey || newKey.length < 10) {
        return '❌ API key tidak valid. Minimal 10 karakter.';
    }

    const config = readConfig();
    if (!config) return '❌ Gagal membaca apikeytestiq.js';

    if (config.API_KEYS.includes(newKey)) {
        return '⚠️ API key sudah ada dalam daftar.';
    }

    config.API_KEYS.push(newKey);
    
    if (writeConfig(config)) {
        const masked = newKey.substring(0, 10) + '...' + newKey.substring(newKey.length - 5);
        return `✅ API key berhasil ditambahkan!\n\nKey: ${masked}\nTotal: ${config.API_KEYS.length} keys`;
    }
    return '❌ Gagal menyimpan apikeytestiq.js';
}

async function removeKey(keyToRemove) {
    if (!keyToRemove) return '❌ Masukkan API key yang akan dihapus.';

    const config = readConfig();
    if (!config) return '❌ Gagal membaca apikeytestiq.js';

    const index = config.API_KEYS.indexOf(keyToRemove);
    if (index === -1) return '❌ API key tidak ditemukan dalam daftar.';

    const removedKey = config.API_KEYS[index];
    config.API_KEYS.splice(index, 1);
    
    if (writeConfig(config)) {
        const masked = removedKey.substring(0, 10) + '...' + removedKey.substring(removedKey.length - 5);
        return `✅ API key berhasil dihapus!\n\nKey: ${masked}\nTotal: ${config.API_KEYS.length} keys`;
    }
    return '❌ Gagal menyimpan apikeytestiq.js';
}

async function testKey(key) {
    if (!key || key.length < 10) {
        return '❌ API key tidak valid. Minimal 10 karakter.';
    }

    try {
        const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent?key=' + key, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contents: [{ parts: [{ text: 'OK' }] }]
            })
        });

        const masked = key.substring(0, 10) + '...' + key.substring(key.length - 5);
        
        if (response.ok) {
            return `✅ API key VALID dan AKTIF!\n\nKey: ${masked}`;
        } else if (response.status === 403) {
            return `❌ API key TIDAK VALID (403 Forbidden)\n\nKey: ${masked}\n\nCek: API key mungkin sudah dinonaktifkan atau salah.`;
        } else if (response.status === 429) {
            return `⚠️ Rate limit exceeded (429)\nCoba lagi nanti.\n\nKey: ${masked}`;
        } else {
            return `❌ API key TIDAK VALID (HTTP ${response.status})\n\nKey: ${masked}`;
        }
    } catch (error) {
        return `❌ Error saat mengetes: ${error.message}`;
    }
}

function setModel(newModel) {
    if (!newModel) return '❌ Masukkan nama model.\nContoh: /setmodel gemini-2.5-flash-lite';

    const config = readConfig();
    if (!config) return '❌ Gagal membaca apikeytestiq.js';

    const oldModel = config.GEMINI_MODEL;
    config.GEMINI_MODEL = newModel;
    
    if (writeConfig(config)) {
        return `✅ Model berhasil diubah!\n\nLama: ${oldModel}\nBaru: ${newModel}`;
    }
    return '❌ Gagal menyimpan apikeytestiq.js';
}

function setQuestions(newTotal) {
    if (isNaN(newTotal) || newTotal < 1 || newTotal > 100) {
        return '❌ Jumlah soal harus angka antara 1-100!';
    }

    const config = readConfig();
    if (!config) return '❌ Gagal membaca apikeytestiq.js';

    const oldTotal = config.TOTAL_QUESTIONS;
    config.TOTAL_QUESTIONS = newTotal;
    
    if (writeConfig(config)) {
        return `✅ Jumlah soal berhasil diubah!\n\nLama: ${oldTotal} soal\nBaru: ${newTotal} soal`;
    }
    return '❌ Gagal menyimpan apikeytestiq.js';
}

// ============================================================
// ROUTE API
// ============================================================

app.get('/status', (req, res) => {
    res.json({
        status: 'running',
        bot: botInitialized,
        port: PORT,
        configPath: CONFIG_PATH,
        configExists: fs.existsSync(CONFIG_PATH)
    });
});

app.get('/api/config', (req, res) => {
    try {
        const config = readConfig();
        if (!config) {
            return res.status(404).json({ success: false, message: 'Config tidak ditemukan' });
        }
        
        res.json({
            success: true,
            data: {
                totalKeys: config.API_KEYS?.length || 0,
                model: config.GEMINI_MODEL,
                totalQuestions: config.TOTAL_QUESTIONS,
                keys: config.API_KEYS?.map(k => ({
                    masked: k.length > 10 ? k.substring(0, 10) + '...' + k.substring(k.length - 5) : k,
                    valid: k.length > 10
                }))
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// ============================================================
// JALANKAN SERVER
// ============================================================

app.listen(PORT, () => {
    console.log('='.repeat(50));
    console.log('🤖 BOT MANAGER CONFIG IQ TEST');
    console.log('='.repeat(50));
    console.log(`✅ Server berjalan di: http://localhost:${PORT}`);
    console.log(`📁 Config file: ${CONFIG_PATH}`);
    console.log(`🤖 Bot Telegram: ${botInitialized ? 'AKTIF ✅' : 'TIDAK AKTIF ❌'}`);
    console.log('='.repeat(50));
    
    if (!botInitialized) {
        console.log('\n⚠️ PERHATIAN: Bot tidak aktif!');
        console.log('Silakan isi BOT_TOKEN dan ADMIN_CHAT_ID di file server.js');
    } else {
        console.log('\n✅ Bot siap digunakan!');
        console.log(`📱 Cari bot @${BOT_TOKEN.split(':')[0]} di Telegram`);
    }
});

module.exports = { app, bot };