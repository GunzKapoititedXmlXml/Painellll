// server.js
const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const cookieParser = require('cookie-parser');

// ========== ENKRIPSI FILE DENGAN PASSWORD (AES-256) ==========
function encryptFile(content, password) {
    const salt = crypto.randomBytes(16);
    const iv = crypto.randomBytes(16);
    const key = crypto.pbkdf2Sync(password, salt, 100000, 32, 'sha256');
    const cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
    let encrypted = cipher.update(content, 'utf8', 'base64');
    encrypted += cipher.final('base64');
    return salt.toString('base64') + ':' + iv.toString('base64') + ':' + encrypted;
}

function decryptFile(encryptedData, password) {
    try {
        const parts = encryptedData.split(':');
        if (parts.length !== 3) {
            throw new Error('Invalid encrypted data format');
        }
        
        const salt = Buffer.from(parts[0], 'base64');
        const iv = Buffer.from(parts[1], 'base64');
        const encrypted = parts[2];
        
        const key = crypto.pbkdf2Sync(password, salt, 100000, 32, 'sha256');
        const decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);
        let decrypted = decipher.update(encrypted, 'base64', 'utf8');
        decrypted += decipher.final('utf8');
        
        return decrypted;
    } catch (error) {
        console.error('❌ Decryption failed:', error.message);
        return null;
    }
}

// ========== BUAT APP ==========
const config = require('./config.js');
const proxyProtection = require('./proxy.js');
const app = express();
const PORT = config.port;
const BASE_URL = config.baseURL;

// ========== ANTI-DDOS & ANTI-BRUTE FORCE ==========
app.set('trust proxy', 1);
app.use(proxyProtection);

// ========== MIDDLEWARE ==========
app.use(cors({
    origin: function(origin, callback) {
        const allowedOrigins = [
            'http://localhost:9000', 
            'http://testiq.xonepanel.qzz.io',
            'https://testiq.xonepanel.qzz.io',
            undefined
        ];
        if (allowedOrigins.indexOf(origin) !== -1 || !origin) {
            callback(null, true);
        } else {
            console.log(`🚫 CORS blocked: ${origin}`);
            callback(new Error('Not allowed by CORS'));
        }
    },
    methods: ['GET', 'POST', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Cookie', 'Authorization'],
    credentials: true
}));
app.use(express.json({ limit: '10mb' }));
app.use(cookieParser());
app.use(proxyProtection.contentGuard);

// ========== SESSION/TOKEN TRACKING ==========
const tokenSessions = new Map();
const TOKEN_EXPIRY_MS = 5 * 60 * 1000; // 5 menit

// ========== DETEKSI BROWSER AUTHENTIC ==========
function isRealBrowser(req) {
    const userAgent = req.headers['user-agent'] || '';
    const accept = req.headers['accept'] || '';
    const acceptLanguage = req.headers['accept-language'] || '';
    const secChUa = req.headers['sec-ch-ua'] || '';
    
    const isBrowser = (
        (userAgent.includes('Mozilla') || userAgent.includes('Chrome') || 
         userAgent.includes('Safari') || userAgent.includes('Firefox') ||
         userAgent.includes('Edg') || userAgent.includes('Opera') ||
         userAgent.includes('Brave') || userAgent.includes('Vivaldi')) &&
        (accept.includes('text/html') || accept.includes('application/json') || accept.includes('*/*')) &&
        (acceptLanguage.includes('id') || acceptLanguage.includes('en') || acceptLanguage.includes('*') || acceptLanguage.includes('q='))
    );
    
    const isBot = (
        userAgent.includes('curl') || 
        userAgent.includes('wget') ||
        userAgent.includes('Postman') ||
        userAgent.includes('insomnia') ||
        userAgent.includes('python-requests') ||
        userAgent.includes('node-fetch') ||
        userAgent.includes('axios') ||
        userAgent.includes('java') ||
        userAgent.includes('perl') ||
        userAgent.includes('ruby') ||
        userAgent.includes('Go-http-client') ||
        userAgent.includes('okhttp') ||
        userAgent.includes('HTTPie')
    );
    
    return isBrowser && !isBot;
}

// ========== MIDDLEWARE UNTUK MELINDUNGI SEMUA API ==========
app.use('/api', (req, res, next) => {
    const ip = req.ip || req.connection?.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'] || 'unknown';
    const pathName = req.path;
    const method = req.method;
    
    if (pathName.includes('/create-dashboard-token')) {
        console.log(`✅ [API GUARD] Token creation allowed for ${ip}`);
        return next();
    }
    
    const isMobileBrowser = (
        userAgent.includes('Android') || 
        userAgent.includes('iPhone') || 
        userAgent.includes('iPad') ||
        userAgent.includes('Mobile')
    );
    
    if (isMobileBrowser) {
        console.log(`📱 [API GUARD] Mobile browser access from ${ip}`);
        return next();
    }
    
    if (!isRealBrowser(req)) {
        console.log(`🚫 [API GUARD] BLOCKED - Non-browser access from IP: ${ip}`);
        console.log(`   Path: ${pathName}`);
        console.log(`   User-Agent: ${userAgent}`);
        
        return res.status(403).json({
            success: false,
            message: 'Access denied - Browser only',
            code: 'BROWSER_ONLY',
            timestamp: new Date().toISOString()
        });
    }
    
    console.log(`✅ [API GUARD] Access granted to ${pathName} from IP: ${ip}`);
    next();
});

// ========== GENERATE UNIQUE BROWSER ID ==========
function getBrowserId(req) {
    let browserId = req.cookies?.browser_id;
    
    if (!browserId) {
        browserId = crypto.randomBytes(32).toString('hex');
        console.log(`🆕 New browser ID generated: ${browserId.substring(0, 20)}...`);
    }
    
    return browserId;
}

// ========== GENERATE DEVICE FINGERPRINT ==========
function getDeviceFingerprint(req) {
    const userAgent = req.headers['user-agent'] || 'unknown';
    const acceptLanguage = req.headers['accept-language'] || 'unknown';
    const platform = req.headers['sec-ch-ua-platform'] || 'unknown';
    const browserId = getBrowserId(req);
    const screenRes = req.headers['sec-ch-ua'] || 'unknown';
    const timezone = req.headers['timezone-offset'] || 'unknown';
    
    const fingerprint = `${userAgent}|${acceptLanguage}|${platform}|${screenRes}|${timezone}|${browserId}`;
    
    return crypto.createHash('sha256')
        .update(fingerprint)
        .digest('hex');
}

// ========== GENERATE TOKEN UNIK UNTUK SESI ==========
function generateToken(deviceFingerprint, browserId) {
    const timestamp = Date.now().toString(10);
    const random = crypto.randomBytes(8).toString('hex');
    const browserHash = crypto.createHash('sha256')
        .update(browserId)
        .digest('hex')
        .substring(0, 8);
    return `iq_${browserHash}_${timestamp}_${random}`;
}

// ========== VALIDATE TOKEN ==========
function isValidToken(token, deviceFingerprint, browserId) {
    if (!token) return false;
    
    const session = tokenSessions.get(token);
    if (!session) {
        console.log('❌ Token tidak ditemukan di session');
        return false;
    }
    
    const now = Date.now();
    if (now - session.timestamp > TOKEN_EXPIRY_MS) {
        console.log('❌ Token expired');
        tokenSessions.delete(token);
        return false;
    }
    
    if (session.deviceFingerprint !== deviceFingerprint) {
        console.log('❌ Device fingerprint mismatch');
        tokenSessions.delete(token);
        return false;
    }
    
    if (session.browserId !== browserId) {
        console.log('❌ Browser ID mismatch');
        tokenSessions.delete(token);
        return false;
    }
    
    console.log('✅ Token valid');
    return true;
}

// ========== MIDDLEWARE UNTUK SET COOKIE BROWSER ID ==========
app.use((req, res, next) => {
    if (req.path.startsWith('/api/') || 
        req.path.endsWith('.css') || 
        req.path.endsWith('.js') || 
        req.path.endsWith('.png') || 
        req.path.endsWith('.jpg') || 
        req.path.endsWith('.jpeg') || 
        req.path.endsWith('.gif') || 
        req.path.endsWith('.svg') || 
        req.path.endsWith('.ico') || 
        req.path.endsWith('.webp') ||
        req.path.endsWith('.woff') ||
        req.path.endsWith('.woff2') ||
        req.path.endsWith('.ttf') ||
        req.path.endsWith('.eot')) {
        return next();
    }
    
    if (!isRealBrowser(req)) {
        return next();
    }
    
    let browserId = req.cookies?.browser_id;
    
    if (!browserId) {
        browserId = crypto.randomBytes(32).toString('hex');
        
        res.cookie('browser_id', browserId, {
            httpOnly: false,
            secure: false,
            sameSite: 'lax',
            path: '/',
            maxAge: 7 * 24 * 60 * 60 * 1000
        });
        
        console.log(`🆕 New browser session cookie set: ${browserId.substring(0, 20)}...`);
    }
    
    next();
});

// ============================================================
// ========== SMART ENCRYPT/DECRYPT SYSTEM ==========
// ============================================================

// ========== GET LOADER CONTENT ==========
function getDashboardLoader() {
    return `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IQ Test Dashboard</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            background: #0a0a1a;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .loader {
            background: #111128;
            border-radius: 16px;
            padding: 40px 35px;
            max-width: 400px;
            width: 100%;
            text-align: center;
            border: 1px solid rgba(255,255,255,0.06);
            box-shadow: 0 20px 50px rgba(0,0,0,0.6);
        }
        .loader .spinner {
            width: 50px;
            height: 50px;
            border: 3px solid rgba(255,255,255,0.05);
            border-top-color: #4a9eff;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
            margin: 0 auto 20px;
        }
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        .loader h2 { color: #fff; font-size: 1.2rem; font-weight: 600; }
        .loader p { color: #666; font-size: 0.9rem; margin-top: 8px; }
        .error-box {
            background: #111128;
            border-radius: 16px;
            padding: 40px 35px;
            max-width: 400px;
            width: 100%;
            text-align: center;
            border: 1px solid rgba(255,255,255,0.06);
            box-shadow: 0 20px 50px rgba(0,0,0,0.6);
        }
        .error-icon { font-size: 3.5rem; margin-bottom: 16px; }
        .error-title { color: #fff; font-size: 1.3rem; font-weight: 600; margin-bottom: 6px; }
        .error-msg { color: #ff6b6b; font-size: 0.95rem; margin-bottom: 20px; }
        .btn {
            display: inline-block;
            padding: 11px 28px;
            border-radius: 10px;
            font-size: 0.9rem;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.2s;
            margin: 0 5px;
        }
        .btn-primary { background: #4a9eff; color: #fff; }
        .btn-primary:hover { background: #3b7fd4; transform: translateY(-2px); }
        .btn-secondary { background: rgba(255,255,255,0.06); color: #8888aa; border: 1px solid rgba(255,255,255,0.06); }
        .btn-secondary:hover { background: rgba(255,255,255,0.1); }
        .btn-group { display: flex; gap: 10px; justify-content: center; flex-wrap: wrap; }
    </style>
</head>
<body>
    <div id="app"></div>
    <script>
        (async function() {
            const urlParams = new URLSearchParams(window.location.search);
            const errorParam = urlParams.get('error');
            
            if (errorParam === 'invalid_token' || errorParam === 'access_denied') {
                document.getElementById('app').innerHTML = '<div class="error-box">' +
                    '<div class="error-icon">😕</div>' +
                    '<h1 class="error-title">Akses Ditolak</h1>' +
                    '<p class="error-msg">Session tidak valid. Silakan mulai ulang.</p>' +
                    '<div class="btn-group">' +
                        '<button onclick="window.location.href=\'/\'" class="btn btn-primary">🔄 Mulai Ulang</button>' +
                        '<button onclick="location.reload()" class="btn btn-secondary">↻ Refresh</button>' +
                    '</div>' +
                '</div>';
                return;
            }
            
            try {
                let token = new URLSearchParams(window.location.search).get('token');
                
                if (!token) {
                    const cookies = document.cookie.split(';');
                    cookies.forEach(cookie => {
                        const parts = cookie.trim().split('=');
                        if (parts[0] === 'iq_token') token = parts[1];
                    });
                }
                
                if (!token) {
                    console.log('🆕 No token, creating new...');
                    const response = await fetch('/api/create-dashboard-token');
                    const data = await response.json();
                    if (data.success && data.token) {
                        token = data.token;
                        document.cookie = 'iq_token=' + token + '; path=/; max-age=86400; SameSite=Lax';
                        window.location.href = window.location.pathname + '?token=' + token;
                        return;
                    }
                }
                
                if (token) {
                    const res = await fetch('/api/get-decrypted-dashboard?token=' + encodeURIComponent(token));
                    if (res.status === 403) {
                        document.cookie = 'iq_token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
                        window.location.href = '/';
                        return;
                    }
                    if (!res.ok) throw new Error('Failed to load dashboard');
                    const html = await res.text();
                    document.open();
                    document.write(html);
                    document.close();
                }
            } catch(e) {
                console.error('Error:', e);
                document.getElementById('app').innerHTML = '<div class="error-box">' +
                    '<div class="error-icon">😕</div>' +
                    '<h1 class="error-title">Gagal Memuat</h1>' +
                    '<p class="error-msg">Konten tidak dapat ditampilkan</p>' +
                    '<div class="btn-group">' +
                        '<a href="/" class="btn btn-primary">← Kembali</a>' +
                        '<button onclick="location.reload()" class="btn btn-secondary">↻ Ulangi</button>' +
                    '</div>' +
                '</div>';
            }
        })();
    <\/script>
</body>
</html>`;
}

function getTestLoader() {
    return `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IQ Test</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            background: #0a0a1a;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .loader {
            background: #111128;
            border-radius: 16px;
            padding: 40px 35px;
            max-width: 400px;
            width: 100%;
            text-align: center;
            border: 1px solid rgba(255,255,255,0.06);
            box-shadow: 0 20px 50px rgba(0,0,0,0.6);
        }
        .loader .spinner {
            width: 50px;
            height: 50px;
            border: 3px solid rgba(255,255,255,0.05);
            border-top-color: #4a9eff;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
            margin: 0 auto 20px;
        }
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        .loader h2 { color: #fff; font-size: 1.2rem; font-weight: 600; }
        .loader p { color: #666; font-size: 0.9rem; margin-top: 8px; }
        .error-box {
            background: #111128;
            border-radius: 16px;
            padding: 40px 35px;
            max-width: 400px;
            width: 100%;
            text-align: center;
            border: 1px solid rgba(255,255,255,0.06);
            box-shadow: 0 20px 50px rgba(0,0,0,0.6);
        }
        .error-icon { font-size: 3.5rem; margin-bottom: 16px; }
        .error-title { color: #fff; font-size: 1.3rem; font-weight: 600; margin-bottom: 6px; }
        .error-msg { color: #ff6b6b; font-size: 0.95rem; margin-bottom: 20px; }
        .btn {
            display: inline-block;
            padding: 11px 28px;
            border-radius: 10px;
            font-size: 0.9rem;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.2s;
            margin: 0 5px;
        }
        .btn-primary { background: #4a9eff; color: #fff; }
        .btn-primary:hover { background: #3b7fd4; transform: translateY(-2px); }
        .btn-secondary { background: rgba(255,255,255,0.06); color: #8888aa; border: 1px solid rgba(255,255,255,0.06); }
        .btn-secondary:hover { background: rgba(255,255,255,0.1); }
        .btn-group { display: flex; gap: 10px; justify-content: center; flex-wrap: wrap; }
    </style>
</head>
<body>
    <div id="app"></div>
    <script>
        (async function() {
            try {
                const urlParams = new URLSearchParams(window.location.search);
                let token = urlParams.get('token');
                if (!token) {
                    const cookies = document.cookie.split(';');
                    cookies.forEach(cookie => {
                        const parts = cookie.trim().split('=');
                        if (parts[0] === 'iq_token') token = parts[1];
                    });
                }
                if (!token) {
                    window.location.href = '/?error=no_token';
                    return;
                }
                const res = await fetch('/api/get-decrypted-content?token=' + encodeURIComponent(token));
                if (res.status === 403) {
                    document.cookie = 'iq_token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
                    window.location.href = '/?error=invalid_token';
                    return;
                }
                if (!res.ok) throw new Error('Failed to load content: ' + res.status);
                const html = await res.text();
                document.open();
                document.write(html);
                document.close();
            } catch(e) {
                console.error('Error loading content:', e);
                document.getElementById('app').innerHTML = '<div class="error-box">' +
                    '<div class="error-icon">😕</div>' +
                    '<h1 class="error-title">Gagal Memuat</h1>' +
                    '<p class="error-msg">Konten tidak dapat ditampilkan</p>' +
                    '<div class="btn-group">' +
                        '<a href="/" class="btn btn-primary">← Kembali</a>' +
                        '<button onclick="location.reload()" class="btn btn-secondary">↻ Ulangi</button>' +
                    '</div>' +
                '</div>';
            }
        })();
    <\/script>
</body>
</html>`;
}

// ========== CORE ENCRYPT/DECRYPT FUNCTIONS ==========

// Encrypt single file
function encryptSingleFile(sourcePath, encryptedPath, password, loaderContent) {
    try {
        if (!fs.existsSync(sourcePath)) {
            console.log(`⚠️ File not found: ${sourcePath}`);
            return false;
        }
        
        const content = fs.readFileSync(sourcePath, 'utf8');
        if (content.includes('Memuat Dashboard') || content.includes('Memuat Tes IQ')) {
            console.log(`⏭️ ${path.basename(sourcePath)} already encrypted (loader detected)`);
            return false;
        }
        
        const backupPath = sourcePath + '.original';
        fs.writeFileSync(backupPath, content);
        console.log(`💾 Backup original: ${backupPath}`);
        
        const encrypted = encryptFile(content, password);
        fs.writeFileSync(encryptedPath, encrypted);
        console.log(`✅ Encrypted: ${encryptedPath}`);
        
        fs.writeFileSync(sourcePath, loaderContent);
        console.log(`✅ Loader written: ${sourcePath}`);
        
        return true;
    } catch (error) {
        console.error(`❌ Failed to encrypt ${sourcePath}:`, error.message);
        return false;
    }
}

// ========== DECRYPT SINGLE FILE (FIXED) ==========
function decryptSingleFile(originalPath, encryptedPath, password) {
    try {
        let restored = false;
        
        // 1. Coba restore dari backup (.original)
        const backupPath = originalPath + '.original';
        if (fs.existsSync(backupPath)) {
            console.log(`📂 Found backup: ${backupPath}`);
            const content = fs.readFileSync(backupPath, 'utf8');
            fs.writeFileSync(originalPath, content);
            console.log(`✅ Restored original from backup: ${originalPath}`);
            
            fs.unlinkSync(backupPath);
            console.log(`🗑️ Deleted backup: ${backupPath}`);
            restored = true;
        }
        
        // 2. Coba decrypt dari file encrypted (.encrypted)
        if (fs.existsSync(encryptedPath)) {
            console.log(`📂 Found encrypted file: ${encryptedPath}`);
            const encryptedData = fs.readFileSync(encryptedPath, 'utf8');
            const decrypted = decryptFile(encryptedData, password);
            
            if (decrypted) {
                fs.writeFileSync(originalPath, decrypted);
                console.log(`✅ Decrypted: ${originalPath}`);
                
                fs.unlinkSync(encryptedPath);
                console.log(`🗑️ Deleted encrypted: ${encryptedPath}`);
                restored = true;
            } else {
                console.log(`❌ Failed to decrypt: ${encryptedPath}`);
            }
        }
        
        // 3. Jika gagal restore dan tidak ada encrypted, cek apakah file asli adalah loader
        if (!restored && fs.existsSync(originalPath)) {
            const content = fs.readFileSync(originalPath, 'utf8');
            if (content.includes('Memuat Dashboard') || content.includes('Memuat Tes IQ')) {
                console.log(`⚠️ File ${path.basename(originalPath)} masih berupa LOADER`);
                console.log(`💡 Tidak ada backup atau encrypted file untuk direstore`);
                console.log(`📝 File akan tetap sebagai LOADER (ini normal jika pertama kali)`);
                return true;
            }
        }
        
        return restored;
    } catch (error) {
        console.error(`❌ Failed to decrypt ${originalPath}:`, error.message);
        return false;
    }
}

// ========== ENCRYPT ALL FILES ==========
function encryptAllFiles() {
    console.log('\n🔐 [ENCRYPT] Encrypting all files...');
    const PASSWORD = config.encryptionPassword;
    let successCount = 0;
    
    const dashboardPath = path.join(__dirname, 'dashboard', 'index.html');
    const dashboardEncrypted = dashboardPath + '.encrypted';
    if (fs.existsSync(dashboardPath)) {
        if (encryptSingleFile(dashboardPath, dashboardEncrypted, PASSWORD, getDashboardLoader())) {
            successCount++;
        }
    }
    
    const testPath = path.join(__dirname, 'IQTest/test', 'index.html');
    const testEncrypted = testPath + '.encrypted';
    if (fs.existsSync(testPath)) {
        if (encryptSingleFile(testPath, testEncrypted, PASSWORD, getTestLoader())) {
            successCount++;
        }
    }
    
    console.log(`✅ [ENCRYPT] ${successCount} file(s) encrypted.\n`);
    return successCount;
}

// ========== DECRYPT ALL FILES (FIXED) ==========
function decryptAllFiles() {
    console.log('\n🔓 [DECRYPT] Decrypting all files...');
    const PASSWORD = config.encryptionPassword;
    let successCount = 0;
    let skippedCount = 0;
    
    // Dashboard
    const dashboardPath = path.join(__dirname, 'dashboard', 'index.html');
    const dashboardEncrypted = dashboardPath + '.encrypted';
    const dashboardBackup = dashboardPath + '.original';
    
    if (fs.existsSync(dashboardEncrypted) || fs.existsSync(dashboardBackup)) {
        console.log(`📂 Processing dashboard...`);
        if (decryptSingleFile(dashboardPath, dashboardEncrypted, PASSWORD)) {
            successCount++;
        }
    } else {
        console.log(`⏭️ Dashboard: No encrypted or backup file found, skipping...`);
        skippedCount++;
    }
    
    // Test
    const testPath = path.join(__dirname, 'IQTest/test', 'index.html');
    const testEncrypted = testPath + '.encrypted';
    const testBackup = testPath + '.original';
    
    if (fs.existsSync(testEncrypted) || fs.existsSync(testBackup)) {
        console.log(`📂 Processing test...`);
        if (decryptSingleFile(testPath, testEncrypted, PASSWORD)) {
            successCount++;
        }
    } else {
        console.log(`⏭️ Test: No encrypted or backup file found, skipping...`);
        skippedCount++;
    }
    
    console.log(`✅ [DECRYPT] ${successCount} file(s) decrypted, ${skippedCount} skipped.\n`);
    return successCount;
}

// ========== HANDLE PROCESS EXIT ==========
function handleShutdown() {
    console.log('\n🛑 [SHUTDOWN] Server is shutting down...');
    console.log('🔓 Decrypting files...');
    decryptAllFiles();
    console.log('👋 Server shutdown complete.');
    process.exit(0);
}

// Catch shutdown signals
process.on('SIGINT', handleShutdown);
process.on('SIGTERM', handleShutdown);
process.on('SIGHUP', handleShutdown);
process.on('SIGQUIT', handleShutdown);

// ========== MIDDLEWARE UNTUK CEK ENKRIPSI ==========
app.use((req, res, next) => {
    if (req.path.startsWith('/api/')) {
        return next();
    }
    
    const dashboardPath = path.join(__dirname, 'dashboard', 'index.html');
    const testPath = path.join(__dirname, 'IQTest/test', 'index.html');
    const dashboardEncrypted = dashboardPath + '.encrypted';
    const testEncrypted = testPath + '.encrypted';
    
    let needsEncrypt = false;
    
    if (fs.existsSync(dashboardPath)) {
        const content = fs.readFileSync(dashboardPath, 'utf8');
        if (!content.includes('Memuat Dashboard') && !content.includes('Memuat Tes IQ')) {
            needsEncrypt = true;
        }
    }
    
    if (fs.existsSync(testPath)) {
        const content = fs.readFileSync(testPath, 'utf8');
        if (!content.includes('Memuat Tes IQ') && !content.includes('Memuat Dashboard')) {
            needsEncrypt = true;
        }
    }
    
    if (needsEncrypt) {
        console.log('🔄 [MIDDLEWARE] Files not encrypted, encrypting...');
        encryptAllFiles();
    }
    
    next();
});

// ========== ENDPOINTS ==========

// ========== GET DECRYPTED CONTENT ==========
app.get('/api/get-decrypted-content', (req, res) => {
    const token = req.query.token || req.cookies?.iq_token;
    const browserId = getBrowserId(req);
    const deviceFingerprint = getDeviceFingerprint(req);
    const ip = req.ip || req.connection?.remoteAddress || 'unknown';
    
    console.log(`🔍 Request to /api/get-decrypted-content`);
    console.log(`   IP: ${ip}`);
    console.log(`   Token: ${token ? token.substring(0, 20) + '...' : 'none'}`);
    
    if (!token || !isValidToken(token, deviceFingerprint, browserId)) {
        console.log(`❌ Access denied - Invalid token from IP: ${ip}`);
        return res.status(403).json({
            success: false,
            message: 'Access denied - Invalid or expired token',
            code: 'INVALID_TOKEN'
        });
    }
    
    try {
        const encryptedPath = path.join(__dirname, 'IQTest/test', 'index.html.encrypted');
        const PASSWORD = config.encryptionPassword;
        
        if (fs.existsSync(encryptedPath)) {
            const encryptedData = fs.readFileSync(encryptedPath, 'utf8');
            const decrypted = decryptFile(encryptedData, PASSWORD);
            
            if (decrypted) {
                console.log(`✅ Content decrypted and sent to IP: ${ip}`);
                res.send(decrypted);
            } else {
                res.status(500).send('Gagal mendekripsi');
            }
        } else {
            const testPath = path.join(__dirname, 'IQTest/test', 'index.html');
            if (fs.existsSync(testPath)) {
                const content = fs.readFileSync(testPath, 'utf8');
                res.send(content);
            } else {
                res.status(404).send('File tidak ditemukan');
            }
        }
    } catch (error) {
        console.error('Error:', error);
        res.status(500).send('Server error');
    }
});

// ========== GET DECRYPTED DASHBOARD ==========
app.get('/api/get-decrypted-dashboard', (req, res) => {
    const token = req.query.token || req.cookies?.iq_token;
    const browserId = getBrowserId(req);
    const deviceFingerprint = getDeviceFingerprint(req);
    const ip = req.ip || req.connection?.remoteAddress || 'unknown';
    
    console.log(`🔍 Request to /api/get-decrypted-dashboard`);
    console.log(`   IP: ${ip}`);
    console.log(`   Token: ${token ? token.substring(0, 20) + '...' : 'none'}`);
    
    if (!token || !isValidToken(token, deviceFingerprint, browserId)) {
        console.log(`❌ Access denied - Invalid token for dashboard from IP: ${ip}`);
        return res.status(403).json({
            success: false,
            message: 'Access denied - Invalid or expired token',
            code: 'INVALID_TOKEN'
        });
    }
    
    try {
        const encryptedPath = path.join(__dirname, 'dashboard', 'index.html.encrypted');
        const PASSWORD = config.encryptionPassword;
        
        if (fs.existsSync(encryptedPath)) {
            const encryptedData = fs.readFileSync(encryptedPath, 'utf8');
            const decrypted = decryptFile(encryptedData, PASSWORD);
            
            if (decrypted) {
                console.log(`✅ Dashboard decrypted and sent to IP: ${ip}`);
                res.send(decrypted);
            } else {
                res.status(500).send('Gagal mendekripsi dashboard');
            }
        } else {
            const dashboardPath = path.join(__dirname, 'dashboard', 'index.html');
            if (fs.existsSync(dashboardPath)) {
                const content = fs.readFileSync(dashboardPath, 'utf8');
                res.send(content);
            } else {
                res.status(404).send('Dashboard tidak ditemukan');
            }
        }
    } catch (error) {
        console.error('Error:', error);
        res.status(500).send('Server error');
    }
});

// ========== CREATE TOKEN ==========
app.get('/api/create-dashboard-token', (req, res) => {
    console.log(`🆕 Creating new dashboard token...`);
    
    const browserId = getBrowserId(req);
    const deviceFingerprint = getDeviceFingerprint(req);
    const token = generateToken(deviceFingerprint, browserId);
    
    tokenSessions.set(token, {
        timestamp: Date.now(),
        deviceFingerprint: deviceFingerprint,
        browserId: browserId,
        userAgent: req.headers['user-agent'] || 'unknown',
        ip: req.ip || req.connection.remoteAddress,
        createdAt: new Date().toISOString()
    });
    
    res.cookie('iq_token', token, {
        maxAge: TOKEN_EXPIRY_MS,
        httpOnly: false,
        secure: false,
        sameSite: 'lax',
        path: '/'
    });
    
    console.log(`🆕 New session created for browser`);
    console.log(`   Browser ID: ${browserId.substring(0, 20)}...`);
    console.log(`   Device: ${deviceFingerprint.substring(0, 20)}...`);
    console.log(`   Token: ${token.substring(0, 20)}...`);
    
    res.json({
        success: true,
        token: token,
        browserId: browserId.substring(0, 20) + '...',
        deviceFingerprint: deviceFingerprint.substring(0, 20) + '...'
    });
});

// ========== REDIRECT TO TEST ==========
app.get('/go-to-test', (req, res) => {
    const browserId = getBrowserId(req);
    const deviceFingerprint = getDeviceFingerprint(req);
    
    let token = req.cookies?.iq_token;
    
    if (!token) {
        token = generateToken(deviceFingerprint, browserId);
        tokenSessions.set(token, {
            timestamp: Date.now(),
            deviceFingerprint: deviceFingerprint,
            browserId: browserId,
            userAgent: req.headers['user-agent'] || 'unknown',
            ip: req.ip || req.connection.remoteAddress,
            createdAt: new Date().toISOString()
        });
        
        res.cookie('iq_token', token, {
            maxAge: TOKEN_EXPIRY_MS,
            httpOnly: false,
            secure: false,
            sameSite: 'lax',
            path: '/'
        });
        
        console.log(`🆕 New token created for test access: ${token.substring(0, 20)}...`);
    }
    
    res.redirect(302, `/IQTest/test?token=${token}&from=testIQ`);
});

// ========== CHECK TOKEN ==========
app.get('/api/check-token', (req, res) => {
    const token = req.query.token || req.cookies?.iq_token;
    const browserId = getBrowserId(req);
    const deviceFingerprint = getDeviceFingerprint(req);
    
    if (!token) {
        return res.json({
            valid: false,
            message: 'No token provided',
            browserId: browserId.substring(0, 20) + '...',
            device: deviceFingerprint.substring(0, 20) + '...'
        });
    }
    
    const isValid = isValidToken(token, deviceFingerprint, browserId);
    const session = tokenSessions.get(token);
    const expiry = session ? new Date(session.timestamp + TOKEN_EXPIRY_MS).toISOString() : null;
    
    res.json({
        valid: isValid,
        token: token.substring(0, 20) + '...',
        browserId: browserId.substring(0, 20) + '...',
        device: deviceFingerprint.substring(0, 20) + '...',
        deviceMatch: session ? session.deviceFingerprint === deviceFingerprint : false,
        browserMatch: session ? session.browserId === browserId : false,
        expiresAt: expiry,
        timeRemaining: session ? Math.floor((TOKEN_EXPIRY_MS - (Date.now() - session.timestamp)) / 1000) : 0,
        message: isValid ? 'Token valid untuk browser ini' : 'Token invalid atau browser berbeda'
    });
});

// ========== ENCRYPTION STATUS ==========
app.get('/api/encryption-status', (req, res) => {
    const dashboardPath = path.join(__dirname, 'dashboard', 'index.html');
    const testPath = path.join(__dirname, 'IQTest/test', 'index.html');
    const dashboardEncrypted = dashboardPath + '.encrypted';
    const testEncrypted = testPath + '.encrypted';
    const dashboardBackup = dashboardPath + '.original';
    const testBackup = testPath + '.original';
    
    const status = {
        dashboard: {
            exists: fs.existsSync(dashboardPath),
            isEncrypted: fs.existsSync(dashboardPath) ? 
                fs.readFileSync(dashboardPath, 'utf8').includes('Memuat Dashboard') : false,
            encryptedFile: fs.existsSync(dashboardEncrypted),
            backupExists: fs.existsSync(dashboardBackup),
            lastModified: fs.existsSync(dashboardPath) ? fs.statSync(dashboardPath).mtime : null
        },
        test: {
            exists: fs.existsSync(testPath),
            isEncrypted: fs.existsSync(testPath) ? 
                fs.readFileSync(testPath, 'utf8').includes('Memuat Tes IQ') : false,
            encryptedFile: fs.existsSync(testEncrypted),
            backupExists: fs.existsSync(testBackup),
            lastModified: fs.existsSync(testPath) ? fs.statSync(testPath).mtime : null
        },
        serverStatus: {
            isRunning: true,
            timestamp: new Date().toISOString()
        }
    };
    
    res.json({
        success: true,
        status: status,
        message: status.dashboard.isEncrypted && status.test.isEncrypted ? 
            '🔐 Files are encrypted (server ON)' : 
            '🔓 Files are decrypted (server OFF or unprotected)'
    });
});

// ========== FORCE ENCRYPT ==========
app.post('/api/force-encrypt', (req, res) => {
    try {
        const count = encryptAllFiles();
        res.json({
            success: true,
            message: `Force encryption completed`,
            encryptedCount: count,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

// ========== FORCE DECRYPT (IMPROVED) ==========
app.post('/api/force-decrypt', (req, res) => {
    try {
        console.log('🔓 [FORCE DECRYPT] Starting forced decryption...');
        
        const PASSWORD = config.encryptionPassword;
        let results = {
            dashboard: false,
            test: false,
            message: ''
        };
        
        // Dashboard
        const dashboardPath = path.join(__dirname, 'dashboard', 'index.html');
        const dashboardEncrypted = dashboardPath + '.encrypted';
        const dashboardBackup = dashboardPath + '.original';
        
        if (fs.existsSync(dashboardBackup)) {
            const content = fs.readFileSync(dashboardBackup, 'utf8');
            fs.writeFileSync(dashboardPath, content);
            fs.unlinkSync(dashboardBackup);
            results.dashboard = true;
            console.log('✅ Dashboard restored from backup');
        } else if (fs.existsSync(dashboardEncrypted)) {
            const encryptedData = fs.readFileSync(dashboardEncrypted, 'utf8');
            const decrypted = decryptFile(encryptedData, PASSWORD);
            if (decrypted) {
                fs.writeFileSync(dashboardPath, decrypted);
                fs.unlinkSync(dashboardEncrypted);
                results.dashboard = true;
                console.log('✅ Dashboard decrypted');
            }
        } else {
            console.log('⚠️ No dashboard backup or encrypted file found');
            results.message = 'No dashboard files to decrypt';
        }
        
        // Test
        const testPath = path.join(__dirname, 'IQTest/test', 'index.html');
        const testEncrypted = testPath + '.encrypted';
        const testBackup = testPath + '.original';
        
        if (fs.existsSync(testBackup)) {
            const content = fs.readFileSync(testBackup, 'utf8');
            fs.writeFileSync(testPath, content);
            fs.unlinkSync(testBackup);
            results.test = true;
            console.log('✅ Test restored from backup');
        } else if (fs.existsSync(testEncrypted)) {
            const encryptedData = fs.readFileSync(testEncrypted, 'utf8');
            const decrypted = decryptFile(encryptedData, PASSWORD);
            if (decrypted) {
                fs.writeFileSync(testPath, decrypted);
                fs.unlinkSync(testEncrypted);
                results.test = true;
                console.log('✅ Test decrypted');
            }
        } else {
            console.log('⚠️ No test backup or encrypted file found');
            if (!results.message) results.message = 'No test files to decrypt';
        }
        
        // Check if successful
        const success = results.dashboard || results.test;
        
        res.json({
            success: success,
            message: success ? 'Force decryption completed successfully' : 'No files to decrypt',
            results: results,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        console.error('❌ Force decrypt error:', error);
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

// ========== FILE STORAGE ==========
const DATA_FILE = path.join(__dirname, 'ranking.json');

function initDataFile() {
    const dir = path.dirname(DATA_FILE);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
        console.log('✅ Folder data created');
    }
    if (!fs.existsSync(DATA_FILE)) {
        fs.writeFileSync(DATA_FILE, JSON.stringify({ users: [] }, null, 2));
        console.log('✅ File ranking.json created');
    }
}
initDataFile();

function readData() {
    try {
        const raw = fs.readFileSync(DATA_FILE, 'utf8');
        return JSON.parse(raw);
    } catch (error) {
        console.error('Error reading data file:', error);
        return { users: [] };
    }
}

function writeData(data) {
    try {
        fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
        return true;
    } catch (error) {
        console.error('Error writing data file:', error);
        return false;
    }
}

// ========== ROUTES API ==========
app.get(config.apiPath, (req, res) => {
    try {
        const data = readData();
        const sorted = [...data.users].sort((a, b) => b.iq - a.iq);
        res.json({
            success: true,
            data: sorted,
            total: sorted.length
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

app.post(config.apiPath, (req, res) => {
    try {
        const { name, iq, correct, total, time, category } = req.body;

        if (!name || iq === undefined || correct === undefined) {
            return res.status(400).json({
                success: false,
                message: 'Data tidak lengkap'
            });
        }

        const data = readData();
        const existingIndex = data.users.findIndex(
            u => u.name.toLowerCase() === name.toLowerCase()
        );

        const userData = {
            name: name.trim(),
            iq: Number(iq),
            correct: Number(correct),
            total: Number(total) || 10,
            time: time || '00:00',
            category: category || 'Tidak Diketahui',
            date: new Date().toISOString()
        };

        if (existingIndex !== -1) {
            data.users[existingIndex] = {
                ...data.users[existingIndex],
                ...userData
            };
            console.log(`🔄 Update user: ${name} | IQ: ${iq}`);
        } else {
            data.users.push(userData);
            console.log(`✅ User baru: ${name} | IQ: ${iq}`);
        }

        if (writeData(data)) {
            res.json({
                success: true,
                message: 'Data berhasil disimpan',
                data: userData
            });
        } else {
            res.status(500).json({
                success: false,
                message: 'Gagal menyimpan data'
            });
        }
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

app.get(`${config.apiPath}/search`, (req, res) => {
    try {
        const { name } = req.query;
        if (!name) {
            return res.status(400).json({
                success: false,
                message: 'Parameter name diperlukan'
            });
        }

        const data = readData();
        const users = data.users.filter(
            u => u.name.toLowerCase().includes(name.toLowerCase())
        );

        res.json({
            success: true,
            data: users
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

app.get(`${config.apiPath}/stats`, (req, res) => {
    try {
        const data = readData();
        const users = data.users;

        if (users.length === 0) {
            return res.json({
                success: true,
                data: {
                    total: 0,
                    highestIQ: 0,
                    averageIQ: 0,
                    lowestIQ: 0,
                    totalUsers: 0
                }
            });
        }

        const iqs = users.map(u => u.iq);
        const highestIQ = Math.max(...iqs);
        const lowestIQ = Math.min(...iqs);
        const averageIQ = Math.round(iqs.reduce((a, b) => a + b, 0) / iqs.length);

        res.json({
            success: true,
            data: {
                total: users.length,
                highestIQ,
                averageIQ,
                lowestIQ,
                totalUsers: users.length
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

app.delete(`${config.apiPath}/clear`, (req, res) => {
    try {
        if (writeData({ users: [] })) {
            console.log('🗑️ Semua data ranking dihapus');
            res.json({
                success: true,
                message: 'Semua data berhasil dihapus'
            });
        } else {
            res.status(500).json({
                success: false,
                message: 'Gagal menghapus data'
            });
        }
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

// ========== PROXY STATUS ==========
app.get('/api/proxy-status', (req, res) => {
    const proxy = require('./proxy.js');
    const status = proxy.getSystemStatus();
    const blocked = proxy.getBlockedIPs();
    
    res.json({
        success: true,
        timestamp: new Date().toISOString(),
        system: status,
        currentlyBlocked: blocked,
        totalBlocked: blocked.length
    });
});

app.get('/api/brute-force-stats', (req, res) => {
    const proxy = require('./proxy.js');
    const stats = proxy.getBruteForceStats();
    const blocked = proxy.getBlockedIPs();
    
    res.json({
        success: true,
        timestamp: new Date().toISOString(),
        activeBruteForceAttempts: stats,
        currentlyBlockedIPs: blocked,
        totalBlocked: blocked.length
    });
});

app.get('/api/my-ip-status', (req, res) => {
    const ip = req.ip || req.connection?.remoteAddress || 'unknown';
    const proxy = require('./proxy.js');
    const blockedIPs = proxy.getBlockedIPs();
    
    const myBlock = blockedIPs.find(b => b.ip === ip);
    
    res.json({
        success: true,
        ip: ip,
        isBlocked: !!myBlock,
        blockInfo: myBlock || null,
        allBlockedIPs: blockedIPs,
        totalBlocked: blockedIPs.length
    });
});

app.post('/api/unblock-ip', (req, res) => {
    const { ip } = req.body;
    const proxy = require('./proxy.js');
    
    if (!ip) {
        return res.status(400).json({
            success: false,
            message: 'IP required'
        });
    }
    
    const result = proxy.unblockIP(ip);
    res.json({
        success: true,
        message: `IP ${ip} unblocked successfully`,
        unblocked: result
    });
});

app.post('/api/unblock-all', (req, res) => {
    const proxy = require('./proxy.js');
    const blocked = proxy.getBlockedIPs();
    let count = 0;
    
    for (const b of blocked) {
        proxy.unblockIP(b.ip);
        count++;
    }
    
    res.json({
        success: true,
        message: `Successfully unblocked ${count} IP(s)`,
        count: count
    });
});

// ========== CLEANUP EXPIRED TOKENS ==========
setInterval(() => {
    const now = Date.now();
    let deletedCount = 0;
    for (const [key, data] of tokenSessions.entries()) {
        if (now - data.timestamp > TOKEN_EXPIRY_MS) {
            tokenSessions.delete(key);
            deletedCount++;
        }
    }
    if (deletedCount > 0) {
        console.log(`🧹 Cleaned ${deletedCount} expired tokens`);
        console.log(`📊 Active tokens: ${tokenSessions.size}`);
    }
}, 60000);

// ========== BLOCK SENSITIVE FILES ==========
app.use((req, res, next) => {
    const blockedFiles = [
        'package.json',
        'package-lock.json',
        'config.js',
        'servertestiq.js',
        'ranking.json', 
        'server.js',
        'proxy.js',
        'README.md',
        'nodemon.json',
        'tsconfig.json',
        '.eslintrc.js',
        '.prettierrc',
        'yarn.lock',
        '.env',
        '.git'
    ];
    
    const requestedPath = req.path;
    const requestedFile = path.basename(requestedPath);
    
    if (blockedFiles.includes(requestedFile) || 
        requestedPath.includes('node_modules') ||
        requestedPath.includes('.git') ||
        requestedPath.includes('.env')) {
        console.log(`🚫 Blocked access to: ${requestedPath}`);
        return res.status(403).json({
            success: false,
            message: 'NO FILE DETECTED'
        });
    }
    
    const blockedExtensions = ['.env', '.lock', '.log', '.key', '.pem', '.crt', '.encrypted', '.original', '.backup'];
    const ext = path.extname(requestedPath);
    if (blockedExtensions.includes(ext) && !requestedPath.includes('/api/')) {
        return res.status(403).json({
            success: false,
            message: 'NO FILE DETECTED'
        });
    }
    
    next();
});

// ========== PROTECTED PATH ==========
const PROTECTED_PATH = '/IQTest/test';

app.use(PROTECTED_PATH, (req, res, next) => {
    if (req.path.includes('/api/') || req.path.includes('/ranking')) {
        return next();
    }
    
    const browserId = getBrowserId(req);
    const deviceFingerprint = getDeviceFingerprint(req);
    const tokenFromQuery = req.query.token;
    const tokenFromCookie = req.cookies?.iq_token;
    const token = tokenFromQuery || tokenFromCookie;
    
    console.log(`🔍 Access check for ${req.path}:`);
    console.log(`   Token: ${token ? token.substring(0, 20) + '...' : 'none'}`);
    console.log(`   Browser ID: ${browserId.substring(0, 20)}...`);
    console.log(`   Device: ${deviceFingerprint.substring(0, 20)}...`);
    
    if (tokenFromQuery && !tokenFromCookie) {
        const isValid = isValidToken(tokenFromQuery, deviceFingerprint, browserId);
        if (isValid) {
            res.cookie('iq_token', tokenFromQuery, {
                maxAge: TOKEN_EXPIRY_MS,
                httpOnly: false,
                secure: false,
                sameSite: 'lax',
                path: '/'
            });
            console.log(`✅ Token dari query disimpan ke cookie`);
        }
    }
    
    const hasValidToken = token && isValidToken(token, deviceFingerprint, browserId);
    
    if (hasValidToken) {
        const session = tokenSessions.get(token);
        if (session) {
            session.timestamp = Date.now();
            tokenSessions.set(token, session);
        }
        
        res.cookie('iq_token', token, {
            maxAge: TOKEN_EXPIRY_MS,
            httpOnly: false,
            secure: false,
            sameSite: 'lax',
            path: '/'
        });
        
        console.log(`✅ Access granted with token`);
        return next();
    }
    
    console.log(`🚫 ACCESS DENIED - Redirecting to dashboard...`);
    res.clearCookie('iq_token');
    return res.redirect(302, '/?error=access_denied');
});

// ========== SERVE STATIC FILES ==========
app.use(express.static(__dirname, {
    setHeaders: (res, filePath) => {
        const allowedExtensions = ['.html', '.htm', '.css', '.js', '.png', '.jpg', '.jpeg', '.gif', '.svg', '.ico', '.webp', '.woff', '.woff2', '.ttf', '.eot'];
        const ext = path.extname(filePath);
        if (!allowedExtensions.includes(ext)) {
            res.removeHeader('Content-Disposition');
        }
    }
}));

// ========== SERVE DASHBOARD ==========
const DASHBOARD_DIR = path.join(__dirname, 'dashboard');

app.use('/dashboard', (req, res, next) => {
    if (req.path.endsWith('.encrypted') || req.path.endsWith('.original')) {
        return res.status(403).json({
            success: false,
            message: 'Access denied'
        });
    }
    next();
});

app.use('/dashboard', express.static(DASHBOARD_DIR, {
    setHeaders: (res, filePath) => {
        const ext = path.extname(filePath);
        if (ext === '.html' || ext === '.htm') {
            res.setHeader('Content-Type', 'text/html');
        }
    }
}));

// ========== ROOT - DASHBOARD ==========
app.get('/', (req, res) => {
    const dashboardFile = path.join(DASHBOARD_DIR, 'index.html');
    
    if (fs.existsSync(dashboardFile)) {
        console.log(`📄 Serving dashboard: ${path.relative(__dirname, dashboardFile)}`);
        res.sendFile(dashboardFile);
    } else {
        console.log(`❌ Dashboard file not found: ${dashboardFile}`);
        res.status(404).json({
            success: false,
            message: 'Dashboard file not found. Please put index.html in dashboard folder.',
            path: dashboardFile
        });
    }
});

// ========== 404 HANDLER ==========
app.use((req, res) => {
    res.status(404).json({
        success: false,
        message: 'Resource tidak ditemukan'
    });
});

// ========== ERROR HANDLING ==========
app.use((err, req, res, next) => {
    console.error('Server error:', err);
    res.status(500).json({
        success: false,
        message: 'Terjadi kesalahan pada server'
    });
});

// ========== START SERVER ==========
app.listen(PORT, () => {
    console.log(`\n╔════════════════════════════════════════════╗`);
    console.log(`║   🚀 IQ TEST RANKING SERVER  `);
    console.log(`╠════════════════════════════════════════════╣`);
    console.log(`║   🌐 ${BASE_URL}`);
    console.log(`║   📁 Data: ${DATA_FILE}`);
    console.log(`║   📁 Dashboard: ${DASHBOARD_DIR}`);
    console.log(`║   🔑 Password: Tersembunyi di config.js`);
    console.log(`║   ⏰ Token Expiry: ${TOKEN_EXPIRY_MS/60000} menit`);
    console.log(`║   🔒 Browser ID: Session (hilang saat browser ditutup)`);
    console.log(`║   🛡️  Proxy: Aktif (block 10 menit)`);
    console.log(`║   🔐 API Protection: ALL ENDPOINTS PROTECTED`);
    console.log(`║   🚫 Non-Browser: BLOCKED`);
    console.log(`║   📱 Mobile Support: ENABLED`);
    console.log(`║   🔐 Encryption: AUTO ON START`);
    console.log(`║   🔓 Decryption: AUTO ON SHUTDOWN`);
    console.log(`╚════════════════════════════════════════════╝\n`);
    
    setTimeout(() => {
        console.log('🔐 [STARTUP] Encrypting files...');
        encryptAllFiles();
    }, 2000);
    
    console.log(`\n📋 DAFTAR API ENDPOINT:`);
    console.log(`   ✅ GET  ${config.apiPath}`);
    console.log(`   ✅ POST ${config.apiPath}`);
    console.log(`   ✅ GET  ${config.apiPath}/search`);
    console.log(`   ✅ GET  ${config.apiPath}/stats`);
    console.log(`   ✅ DELETE ${config.apiPath}/clear`);
    console.log(`   ✅ GET  /api/get-decrypted-content`);
    console.log(`   ✅ GET  /api/get-decrypted-dashboard`);
    console.log(`   ✅ GET  /api/create-dashboard-token`);
    console.log(`   ✅ GET  /api/check-token`);
    console.log(`   ✅ GET  /api/encryption-status`);
    console.log(`   ✅ POST /api/force-encrypt`);
    console.log(`   ✅ POST /api/force-decrypt`);
    console.log(`   ✅ GET  /api/proxy-status`);
    console.log(`   ✅ GET  /api/brute-force-stats`);
    console.log(`   ✅ GET  /api/my-ip-status`);
    console.log(`   ✅ POST /api/unblock-ip`);
    console.log(`   ✅ POST /api/unblock-all`);
    console.log(`\n🔐 Server akan ENCRYPT file saat start`);
    console.log(`🔓 Server akan DECRYPT file saat shutdown`);
    console.log(`💾 Backup original files disimpan sebagai *.original\n`);
});