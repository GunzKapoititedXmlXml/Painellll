// server.js
const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const cookieParser = require('cookie-parser');

// ========== ENKRIPSI FILE DENGAN PASSWORD (AES-256) ==========
function encryptFile(content, password) {
    const salt = crypto.randomBytes(16);
    const iv = crypto.randomBytes(16);
    const key = crypto.pbkdf2Sync(password, salt, 100000, 32, 'sha256');
    const cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
    let encrypted = cipher.update(content, 'utf8', 'base64');
    encrypted += cipher.final('base64');
    return salt.toString('base64') + ':' + iv.toString('base64') + ':' + encrypted;
}

function decryptFile(encryptedData, password) {
    try {
        const parts = encryptedData.split(':');
        if (parts.length !== 3) {
            throw new Error('Invalid encrypted data format');
        }
        
        const salt = Buffer.from(parts[0], 'base64');
        const iv = Buffer.from(parts[1], 'base64');
        const encrypted = parts[2];
        
        const key = crypto.pbkdf2Sync(password, salt, 100000, 32, 'sha256');
        const decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);
        let decrypted = decipher.update(encrypted, 'base64', 'utf8');
        decrypted += decipher.final('utf8');
        
        return decrypted;
    } catch (error) {
        console.error('❌ Decryption failed:', error.message);
        return null;
    }
}

// ========== BUAT APP ==========
const config = require('./config.js');
const proxyProtection = require('./proxy.js');
const app = express();
const PORT = config.port;
const BASE_URL = config.baseURL;

// ========== ANTI-DDOS & ANTI-BRUTE FORCE ==========
app.set('trust proxy', 1);
app.use(proxyProtection);

// ========== MIDDLEWARE ==========
app.use(cors({
    origin: function(origin, callback) {
        const allowedOrigins = [
            'http://localhost:9000', 
            'http://testiq.xonepanel.qzz.io',
            'https://testiq.xonepanel.qzz.io',
            undefined
        ];
        if (allowedOrigins.indexOf(origin) !== -1 || !origin) {
            callback(null, true);
        } else {
            console.log(`🚫 CORS blocked: ${origin}`);
            callback(new Error('Not allowed by CORS'));
        }
    },
    methods: ['GET', 'POST', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Cookie', 'Authorization'],
    credentials: true
}));
app.use(express.json({ limit: '10mb' }));
app.use(cookieParser());
app.use(proxyProtection.contentGuard);

// ========== SESSION/TOKEN TRACKING ==========
const tokenSessions = new Map();
const TOKEN_EXPIRY_MS = 60 * 1000; // 1 menit

// ========== DETEKSI BROWSER AUTHENTIC ==========
function isRealBrowser(req) {
    const userAgent = req.headers['user-agent'] || '';
    const accept = req.headers['accept'] || '';
    const acceptLanguage = req.headers['accept-language'] || '';
    const secChUa = req.headers['sec-ch-ua'] || '';
    
    const isBrowser = (
        (userAgent.includes('Mozilla') || userAgent.includes('Chrome') || 
         userAgent.includes('Safari') || userAgent.includes('Firefox') ||
         userAgent.includes('Edg') || userAgent.includes('Opera') ||
         userAgent.includes('Brave')) &&
        (accept.includes('text/html') || accept.includes('application/json') || accept.includes('*/*')) &&
        (acceptLanguage.includes('id') || acceptLanguage.includes('en') || acceptLanguage.includes('*'))
    );
    
    const isBot = (
        userAgent.includes('curl') || 
        userAgent.includes('wget') ||
        userAgent.includes('Postman') ||
        userAgent.includes('insomnia') ||
        userAgent.includes('python-requests') ||
        userAgent.includes('node-fetch') ||
        userAgent.includes('axios') ||
        userAgent.includes('java') ||
        userAgent.includes('perl') ||
        userAgent.includes('ruby') ||
        userAgent.includes('Go-http-client') ||
        userAgent.includes('okhttp') ||
        userAgent.includes('HTTPie')
    );
    
    return isBrowser && !isBot;
}

// ========== MIDDLEWARE UNTUK MELINDUNGI SEMUA API ==========
// MIDDLEWARE INI AKAN BERJALAN UNTUK SEMUA ENDPOINT YANG DIMULAI DENGAN /api/
app.use('/api', (req, res, next) => {
    const ip = req.ip || req.connection?.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'] || 'unknown';
    const pathName = req.path;
    const method = req.method;
    
    console.log(`🛡️ [API GUARD] Checking request to ${pathName} from ${ip}`);
    console.log(`   Method: ${method}`);
    console.log(`   User-Agent: ${userAgent.substring(0, 50)}...`);
    
    // CEK APAKAH REQUEST DARI BROWSER
    if (!isRealBrowser(req)) {
        console.log(`🚫 [API GUARD] BLOCKED - Non-browser access from IP: ${ip}`);
        console.log(`   Path: ${pathName}`);
        console.log(`   User-Agent: ${userAgent}`);
        
        return res.status(403).json({
            success: false,
            message: 'Access denied - Browser only',
            code: 'BROWSER_ONLY',
            timestamp: new Date().toISOString()
        });
    }
    
    // VALIDASI TOKEN UNTUK ENDPOINT TERTENTU
    const protectedEndpoints = [
        '/get-decrypted-content',
        '/get-decrypted-dashboard',
        '/create-dashboard-token',
        '/check-token'
    ];
    
    // CEK APAKAH PATH MEMBUTUHKAN TOKEN
    const needsToken = protectedEndpoints.some(endpoint => pathName.includes(endpoint));
    
    if (needsToken) {
        const token = req.query.token || req.cookies?.iq_token;
        
        if (!token) {
            console.log(`🔴 [API GUARD] Token required for ${pathName} from IP: ${ip}`);
            return res.status(403).json({
                success: false,
                message: 'Access denied - Token required',
                code: 'TOKEN_REQUIRED'
            });
        }
        
        // Validasi token
        const browserId = getBrowserId(req);
        const deviceFingerprint = getDeviceFingerprint(req);
        
        if (!isValidToken(token, deviceFingerprint, browserId)) {
            console.log(`🔴 [API GUARD] Invalid token for ${pathName} from IP: ${ip}`);
            console.log(`   Token: ${token.substring(0, 20)}...`);
            return res.status(403).json({
                success: false,
                message: 'Access denied - Invalid or expired token',
                code: 'INVALID_TOKEN'
            });
        }
        
        console.log(`✅ [API GUARD] Token valid for ${pathName}`);
    }
    
    console.log(`✅ [API GUARD] Access granted to ${pathName} from IP: ${ip}`);
    next();
});

// ========== GENERATE UNIQUE BROWSER ID ==========
function getBrowserId(req) {
    let browserId = req.cookies?.browser_id;
    
    if (!browserId) {
        browserId = crypto.randomBytes(32).toString('hex');
        console.log(`🆕 New browser ID generated: ${browserId.substring(0, 20)}...`);
    }
    
    return browserId;
}

// ========== GENERATE DEVICE FINGERPRINT ==========
function getDeviceFingerprint(req) {
    const userAgent = req.headers['user-agent'] || 'unknown';
    const acceptLanguage = req.headers['accept-language'] || 'unknown';
    const platform = req.headers['sec-ch-ua-platform'] || 'unknown';
    const browserId = getBrowserId(req);
    const screenRes = req.headers['sec-ch-ua'] || 'unknown';
    const timezone = req.headers['timezone-offset'] || 'unknown';
    
    const fingerprint = `${userAgent}|${acceptLanguage}|${platform}|${screenRes}|${timezone}|${browserId}`;
    
    return crypto.createHash('sha256')
        .update(fingerprint)
        .digest('hex');
}

// ========== GENERATE TOKEN UNIK UNTUK SESI ==========
function generateToken(deviceFingerprint, browserId) {
    const timestamp = Date.now().toString(10);
    const random = crypto.randomBytes(5).toString('hex');
    const browserHash = crypto.createHash('sha256')
        .update(browserId)
        .digest('hex')
        .substring(0, 8);
    return `iq_${browserHash}_${timestamp}_${random}`;
}

// ========== VALIDATE TOKEN ==========
function isValidToken(token, deviceFingerprint, browserId) {
    if (!token) return false;
    
    const session = tokenSessions.get(token);
    if (!session) {
        console.log('❌ Token tidak ditemukan di session');
        return false;
    }
    
    const now = Date.now();
    if (now - session.timestamp > TOKEN_EXPIRY_MS) {
        console.log('❌ Token expired');
        tokenSessions.delete(token);
        return false;
    }
    
    if (session.deviceFingerprint !== deviceFingerprint) {
        console.log('❌ Device fingerprint mismatch');
        tokenSessions.delete(token);
        return false;
    }
    
    if (session.browserId !== browserId) {
        console.log('❌ Browser ID mismatch');
        tokenSessions.delete(token);
        return false;
    }
    
    console.log('✅ Token valid');
    return true;
}

// ========== MIDDLEWARE UNTUK SET COOKIE BROWSER ID ==========
app.use((req, res, next) => {
    if (req.path.startsWith('/api/')) {
        return next();
    }
    
    if (!isRealBrowser(req)) {
        return next();
    }
    
    let browserId = req.cookies?.browser_id;
    
    if (!browserId) {
        browserId = crypto.randomBytes(32).toString('hex');
        
        res.cookie('browser_id', browserId, {
            httpOnly: true,
            secure: false,
            sameSite: 'strict',
            path: '/'
        });
        
        console.log(`🆕 New browser session cookie set: ${browserId.substring(0, 20)}...`);
    }
    
    next();
});

// ========== ENDPOINT UNTUK MENDAPATKAN KONTEN TERDEKRIPSI ==========
app.get('/api/get-decrypted-content', (req, res) => {
    const token = req.query.token || req.cookies?.iq_token;
    const browserId = getBrowserId(req);
    const deviceFingerprint = getDeviceFingerprint(req);
    const ip = req.ip || req.connection?.remoteAddress || 'unknown';
    
    console.log(`🔍 Request to /api/get-decrypted-content`);
    console.log(`   IP: ${ip}`);
    console.log(`   Token: ${token ? token.substring(0, 20) + '...' : 'none'}`);
    
    // Token sudah divalidasi di middleware /api
    try {
        const encryptedPath = path.join(__dirname, 'IQTest/test', 'index.html.encrypted');
        const PASSWORD = config.encryptionPassword;
        
        if (fs.existsSync(encryptedPath)) {
            const encryptedData = fs.readFileSync(encryptedPath, 'utf8');
            const decrypted = decryptFile(encryptedData, PASSWORD);
            
            if (decrypted) {
                console.log(`✅ Content decrypted and sent to IP: ${ip}`);
                res.send(decrypted);
            } else {
                res.status(500).send('Gagal mendekripsi');
            }
        } else {
            res.status(404).send('File tidak ditemukan');
        }
    } catch (error) {
        console.error('Error:', error);
        res.status(500).send('Server error');
    }
});

// ========== ENDPOINT UNTUK REDIRECT KE TEST DENGAN TOKEN ==========
app.get('/go-to-test', (req, res) => {
    if (!isRealBrowser(req)) {
        return res.status(403).json({
            success: false,
            message: 'Access denied - Browser only'
        });
    }
    
    const browserId = getBrowserId(req);
    const deviceFingerprint = getDeviceFingerprint(req);
    
    let token = req.cookies?.iq_token;
    
    if (!token) {
        token = generateToken(deviceFingerprint, browserId);
        tokenSessions.set(token, {
            timestamp: Date.now(),
            deviceFingerprint: deviceFingerprint,
            browserId: browserId,
            userAgent: req.headers['user-agent'] || 'unknown',
            ip: req.ip || req.connection.remoteAddress,
            createdAt: new Date().toISOString()
        });
        
        res.cookie('iq_token', token, {
            maxAge: TOKEN_EXPIRY_MS,
            httpOnly: true,
            secure: false,
            sameSite: 'strict'
        });
        
        console.log(`🆕 New token created for test access: ${token.substring(0, 20)}...`);
    }
    
    res.redirect(302, `/IQTest/test?token=${token}&from=testIQ`);
});

// ========== AUTO ENCRYPT FILE ==========
function autoEncryptIndexHTML() {
    const indexPath = path.join(__dirname, 'IQTest/test', 'index.html');
    const encryptedPath = path.join(__dirname, 'IQTest/test', 'index.html.encrypted');
    const PASSWORD = config.encryptionPassword;
    
    if (fs.existsSync(indexPath)) {
        const content = fs.readFileSync(indexPath, 'utf8');
        const encrypted = encryptFile(content, PASSWORD);
        fs.writeFileSync(encryptedPath, encrypted);
        console.log(`✅ File terenkripsi: ${encryptedPath}`);
        
        const loaderContent = `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loading...</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            background: #0a0a1a;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .error-box {
            background: #111128;
            border-radius: 16px;
            padding: 40px 35px;
            max-width: 400px;
            width: 100%;
            text-align: center;
            border: 1px solid rgba(255,255,255,0.06);
            box-shadow: 0 20px 50px rgba(0,0,0,0.6);
        }
        .error-icon { font-size: 3.5rem; margin-bottom: 16px; }
        .error-title { color: #fff; font-size: 1.3rem; font-weight: 600; margin-bottom: 6px; }
        .error-msg { color: #ff6b6b; font-size: 0.95rem; margin-bottom: 20px; }
        .error-desc { color: #8888aa; font-size: 0.9rem; line-height: 1.5; margin-bottom: 24px; }
        .btn {
            display: inline-block;
            padding: 11px 28px;
            border-radius: 10px;
            font-size: 0.9rem;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.2s;
            margin: 0 5px;
        }
        .btn-primary { background: #4a9eff; color: #fff; }
        .btn-primary:hover { background: #3b7fd4; transform: translateY(-2px); }
        .btn-secondary { background: rgba(255,255,255,0.06); color: #8888aa; border: 1px solid rgba(255,255,255,0.06); }
        .btn-secondary:hover { background: rgba(255,255,255,0.1); }
        .btn-group { display: flex; gap: 10px; justify-content: center; flex-wrap: wrap; }
    </style>
</head>
<body>
    <div id="app"></div>
    <script>
        (async function() {
            try {
                const urlParams = new URLSearchParams(window.location.search);
                let token = urlParams.get('token');
                if (!token) {
                    const cookies = document.cookie.split(';');
                    cookies.forEach(cookie => {
                        const parts = cookie.trim().split('=');
                        if (parts[0] === 'iq_token') token = parts[1];
                    });
                }
                if (!token) {
                    window.location.href = '/?error=no_token';
                    return;
                }
                const res = await fetch('/api/get-decrypted-content?token=' + encodeURIComponent(token));
                if (res.status === 403) {
                    window.location.href = '/?error=invalid_token';
                    return;
                }
                if (!res.ok) throw new Error('Failed to load content: ' + res.status);
                const html = await res.text();
                document.open();
                document.write(html);
                document.close();
            } catch(e) {
                console.error('Error loading content:', e);
                document.body.innerHTML = '<div class="error-box">' +
                    '<div class="error-icon">😕</div>' +
                    '<h1 class="error-title">Gagal Memuat</h1>' +
                    '<p class="error-msg">Konten tidak dapat ditampilkan</p>' +
                    '<p class="error-desc">' + (e.message || 'Terjadi kesalahan saat memuat halaman') + '</p>' +
                    '<div class="btn-group">' +
                        '<a href="/" class="btn btn-primary">← Kembali</a>' +
                        '<button onclick="location.reload()" class="btn btn-secondary">↻ Ulangi</button>' +
                    '</div>' +
                '</div>';
            }
        })();
    <\/script>
</body>
</html>`;
        
        fs.writeFileSync(indexPath, loaderContent);
        console.log(`✅ Loader simpel dibuat: ${indexPath}`);
        
    } else {
        console.log(`⚠️ File tidak ditemukan: ${indexPath}`);
    }
}

// ========== AUTO ENCRYPT DASHBOARD ==========
function autoEncryptDashboard() {
    const dashboardDir = path.join(__dirname, 'dashboard');
    const indexDashboardPath = path.join(dashboardDir, 'index.html');
    const encryptedDashboardPath = path.join(dashboardDir, 'index.html.encrypted');
    const PASSWORD = config.encryptionPassword;
    
    if (fs.existsSync(indexDashboardPath)) {
        const content = fs.readFileSync(indexDashboardPath, 'utf8');
        const encrypted = encryptFile(content, PASSWORD);
        fs.writeFileSync(encryptedDashboardPath, encrypted);
        console.log(`✅ Dashboard terenkripsi: ${encryptedDashboardPath}`);
        
        const dashboardLoaderContent = `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IQ Test Dashboard</title>
</head>
<body>
    <div id="app"></div>
    <script>
        function setBrowserInfo() {
            const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
            document.cookie = 'timezone-offset=' + timezone + '; path=/; max-age=86400';
            
            const screenRes = window.screen.width + 'x' + window.screen.height;
            document.cookie = 'screen-res=' + screenRes + '; path=/; max-age=86400';
            
            const language = navigator.language || navigator.userLanguage;
            document.cookie = 'lang=' + language + '; path=/; max-age=86400';
        }
        
        setBrowserInfo();
        
        (async function() {
            let token = new URLSearchParams(window.location.search).get('token');
            
            const cookies = document.cookie.split(';');
            let cookieToken = null;
            cookies.forEach(cookie => {
                const parts = cookie.trim().split('=');
                if (parts[0] === 'iq_token') {
                    cookieToken = parts[1];
                }
            });
            
            if (cookieToken && !token) {
                console.log('🔄 Token found in cookie, redirecting...');
                window.location.href = window.location.pathname + '?token=' + cookieToken;
                return;
            }
            
            if (token) {
                console.log('✅ Token found in URL:', token.substring(0, 20) + '...');
                
                document.cookie = 'iq_token=' + token + '; path=/; max-age=86400; SameSite=Strict';
                
                try {
                    const res = await fetch('/api/get-decrypted-dashboard?token=' + encodeURIComponent(token));
                    
                    if (res.status === 403) {
                        console.log('❌ Token invalid, generating new...');
                        const response = await fetch('/api/create-dashboard-token');
                        const data = await response.json();
                        if (data.success && data.token) {
                            window.location.href = window.location.pathname + '?token=' + data.token;
                            return;
                        }
                    }
                    
                    if (!res.ok) throw new Error('Failed to load dashboard');
                    
                    const html = await res.text();
                    document.open();
                    document.write(html);
                    document.close();
                } catch(e) {
                    console.error('Error:', e);
                    const response = await fetch('/api/create-dashboard-token');
                    const data = await response.json();
                    if (data.success && data.token) {
                        window.location.href = window.location.pathname + '?token=' + data.token;
                    }
                }
                return;
            }
            
            console.log('🆕 No token found, creating new session...');
            try {
                const response = await fetch('/api/create-dashboard-token');
                const data = await response.json();
                if (data.success && data.token) {
                    console.log('✅ New token created:', data.token.substring(0, 20) + '...');
                    window.location.href = window.location.pathname + '?token=' + data.token;
                } else {
                    throw new Error('Failed to create token');
                }
            } catch(e) {
                console.error('Error creating token:', e);
                document.body.innerHTML = \`
                    <div style="display:flex;justify-content:center;align-items:center;height:100vh;font-family:Arial,sans-serif;background:#0a0a1a;color:#fff;flex-direction:column;">
                        <div style="font-size:3rem;margin-bottom:20px;">⚠️</div>
                        <div style="color:#ff6b6b;font-size:1.2rem;">Gagal memuat dashboard</div>
                        <div style="color:#666;margin-top:10px;">Silakan refresh halaman</div>
                    </div>
                \`;
            }
        })();
    </script>
</body>
</html>`;
        
        fs.writeFileSync(indexDashboardPath, dashboardLoaderContent);
        console.log(`✅ Dashboard loader dibuat: ${indexDashboardPath}`);
        
    } else {
        console.log(`⚠️ Dashboard file tidak ditemukan: ${indexDashboardPath}`);
        if (!fs.existsSync(dashboardDir)) {
            fs.mkdirSync(dashboardDir, { recursive: true });
            console.log(`📁 Folder dashboard dibuat: ${dashboardDir}`);
        }
    }
}

// ========== FUNGSI BACKUP FILE ENKRIPSI ==========
function backupEncryptedFiles() {
    const testEncryptedPath = path.join(__dirname, 'IQTest/test', 'index.html.encrypted');
    const testBackupPath = path.join(__dirname, 'IQTest/test', 'index.html.encrypted.backup');
    
    if (fs.existsSync(testEncryptedPath)) {
        try {
            fs.copyFileSync(testEncryptedPath, testBackupPath);
            console.log(`💾 Backup test file dibuat: ${testBackupPath}`);
        } catch (error) {
            console.error(`❌ Gagal backup test file: ${error.message}`);
        }
    }
    
    const dashboardEncryptedPath = path.join(__dirname, 'dashboard', 'index.html.encrypted');
    const dashboardBackupPath = path.join(__dirname, 'dashboard', 'index.html.encrypted.backup');
    
    if (fs.existsSync(dashboardEncryptedPath)) {
        try {
            fs.copyFileSync(dashboardEncryptedPath, dashboardBackupPath);
            console.log(`💾 Backup dashboard file dibuat: ${dashboardBackupPath}`);
        } catch (error) {
            console.error(`❌ Gagal backup dashboard file: ${error.message}`);
        }
    }
}

// ========== ENDPOINT UNTUK DASHBOARD TERDEKRIPSI ==========
app.get('/api/get-decrypted-dashboard', (req, res) => {
    const token = req.query.token || req.cookies?.iq_token;
    const browserId = getBrowserId(req);
    const deviceFingerprint = getDeviceFingerprint(req);
    const ip = req.ip || req.connection?.remoteAddress || 'unknown';
    
    console.log(`🔍 Request to /api/get-decrypted-dashboard`);
    console.log(`   IP: ${ip}`);
    console.log(`   Token: ${token ? token.substring(0, 20) + '...' : 'none'}`);
    
    // Token sudah divalidasi di middleware /api
    try {
        const encryptedPath = path.join(__dirname, 'dashboard', 'index.html.encrypted');
        const PASSWORD = config.encryptionPassword;
        
        if (fs.existsSync(encryptedPath)) {
            const encryptedData = fs.readFileSync(encryptedPath, 'utf8');
            const decrypted = decryptFile(encryptedData, PASSWORD);
            
            if (decrypted) {
                console.log(`✅ Dashboard decrypted and sent to IP: ${ip}`);
                res.send(decrypted);
            } else {
                res.status(500).send('Gagal mendekripsi dashboard');
            }
        } else {
            res.status(404).send('Dashboard tidak ditemukan');
        }
    } catch (error) {
        console.error('Error:', error);
        res.status(500).send('Server error');
    }
});

// ========== ENDPOINT CREATE TOKEN UNTUK DASHBOARD ==========
app.get('/api/create-dashboard-token', (req, res) => {
    // Browser sudah divalidasi di middleware /api
    
    const browserId = getBrowserId(req);
    const deviceFingerprint = getDeviceFingerprint(req);
    const token = generateToken(deviceFingerprint, browserId);
    
    tokenSessions.set(token, {
        timestamp: Date.now(),
        deviceFingerprint: deviceFingerprint,
        browserId: browserId,
        userAgent: req.headers['user-agent'] || 'unknown',
        ip: req.ip || req.connection.remoteAddress,
        createdAt: new Date().toISOString()
    });
    
    res.cookie('iq_token', token, {
        maxAge: TOKEN_EXPIRY_MS,
        httpOnly: true,
        secure: false,
        sameSite: 'strict'
    });
    
    console.log(`🆕 New session created for browser`);
    console.log(`   Browser ID: ${browserId.substring(0, 20)}...`);
    console.log(`   Device: ${deviceFingerprint.substring(0, 20)}...`);
    console.log(`   Token: ${token.substring(0, 20)}...`);
    
    res.json({
        success: true,
        token: token,
        browserId: browserId.substring(0, 20) + '...',
        deviceFingerprint: deviceFingerprint.substring(0, 20) + '...'
    });
});

// ========== CLEANUP EXPIRED TOKENS ==========
setInterval(() => {
    const now = Date.now();
    let deletedCount = 0;
    for (const [key, data] of tokenSessions.entries()) {
        if (now - data.timestamp > TOKEN_EXPIRY_MS) {
            tokenSessions.delete(key);
            deletedCount++;
        }
    }
    if (deletedCount > 0) {
        console.log(`🧹 Cleaned ${deletedCount} expired tokens`);
        console.log(`📊 Active tokens: ${tokenSessions.size}`);
    }
}, 60000);

// ========== BLOCK SENSITIVE FILES ==========
app.use((req, res, next) => {
    const blockedFiles = [
        'package.json',
        'package-lock.json',
        'config.js',
        'servertestiq.js',
        'ranking.json', 
        'server.js',
        'proxy.js',
        'README.md',
        'nodemon.json',
        'tsconfig.json',
        '.eslintrc.js',
        '.prettierrc',
        'yarn.lock',
        '.env',
        '.git'
    ];
    
    const requestedPath = req.path;
    const requestedFile = path.basename(requestedPath);
    
    if (blockedFiles.includes(requestedFile) || 
        requestedPath.includes('node_modules') ||
        requestedPath.includes('.git') ||
        requestedPath.includes('.env')) {
        console.log(`🚫 Blocked access to: ${requestedPath}`);
        return res.status(403).json({
            success: false,
            message: 'NO FILE DETECTED'
        });
    }
    
    const blockedExtensions = ['.env', '.lock', '.log', '.key', '.pem', '.crt', '.encrypted', '.backup'];
    const ext = path.extname(requestedPath);
    if (blockedExtensions.includes(ext) && !requestedPath.includes('/api/')) {
        return res.status(403).json({
            success: false,
            message: 'NO FILE DETECTED'
        });
    }
    
    next();
});

// ========== PROTECTED PATH ==========
const PROTECTED_PATH = '/IQTest/test';

// ========== MIDDLEWARE PROTECTED PATH ==========
app.use(PROTECTED_PATH, (req, res, next) => {
    if (req.path.includes('/api/') || req.path.includes('/ranking')) {
        return next();
    }
    
    if (!isRealBrowser(req)) {
        console.log(`🚫 Non-browser access to protected path from IP: ${req.ip}`);
        return res.status(403).json({
            success: false,
            message: 'Access denied - Browser only'
        });
    }
    
    const browserId = getBrowserId(req);
    const deviceFingerprint = getDeviceFingerprint(req);
    const tokenFromQuery = req.query.token;
    const tokenFromCookie = req.cookies?.iq_token;
    const token = tokenFromQuery || tokenFromCookie;
    
    console.log(`🔍 Access check for ${req.path}:`);
    console.log(`   Token: ${token ? token.substring(0, 20) + '...' : 'none'}`);
    
    if (tokenFromQuery && !tokenFromCookie) {
        const isValid = isValidToken(tokenFromQuery, deviceFingerprint, browserId);
        if (isValid) {
            res.cookie('iq_token', tokenFromQuery, {
                maxAge: TOKEN_EXPIRY_MS,
                httpOnly: true,
                secure: false,
                sameSite: 'strict'
            });
            console.log(`✅ Token dari query disimpan ke cookie`);
        }
    }
    
    const hasValidToken = token && isValidToken(token, deviceFingerprint, browserId);
    
    if (hasValidToken) {
        const session = tokenSessions.get(token);
        if (session) {
            session.timestamp = Date.now();
            tokenSessions.set(token, session);
        }
        
        res.cookie('iq_token', token, {
            maxAge: TOKEN_EXPIRY_MS,
            httpOnly: true,
            secure: false,
            sameSite: 'strict'
        });
        
        console.log(`✅ Access granted with token`);
        return next();
    }
    
    console.log(`🚫 ACCESS DENIED - Redirecting to dashboard...`);
    res.clearCookie('iq_token');
    return res.redirect(302, '/?error=access_denied');
});

// ========== SERVE STATIC FILES ==========
app.use(express.static(__dirname, {
    setHeaders: (res, filePath) => {
        const allowedExtensions = ['.html', '.htm', '.css', '.js', '.png', '.jpg', '.jpeg', '.gif', '.svg', '.ico', '.webp', '.woff', '.woff2', '.ttf', '.eot'];
        const ext = path.extname(filePath);
        if (!allowedExtensions.includes(ext)) {
            res.removeHeader('Content-Disposition');
        }
    }
}));

// ========== SERVE DASHBOARD FOLDER ==========
const DASHBOARD_DIR = path.join(__dirname, 'dashboard');

app.use('/dashboard', (req, res, next) => {
    if (req.path.endsWith('.encrypted')) {
        return res.status(403).json({
            success: false,
            message: 'Access denied'
        });
    }
    next();
});

app.use('/dashboard', express.static(DASHBOARD_DIR, {
    setHeaders: (res, filePath) => {
        const ext = path.extname(filePath);
        if (ext === '.html' || ext === '.htm') {
            res.setHeader('Content-Type', 'text/html');
        }
    }
}));

// ========== FILE STORAGE ==========
const DATA_FILE = path.join(__dirname, 'ranking.json');

function initDataFile() {
    const dir = path.dirname(DATA_FILE);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
        console.log('✅ Folder data created');
    }
    if (!fs.existsSync(DATA_FILE)) {
        fs.writeFileSync(DATA_FILE, JSON.stringify({ users: [] }, null, 2));
        console.log('✅ File ranking.json created');
    }
}
initDataFile();

function readData() {
    try {
        const raw = fs.readFileSync(DATA_FILE, 'utf8');
        return JSON.parse(raw);
    } catch (error) {
        console.error('Error reading data file:', error);
        return { users: [] };
    }
}

function writeData(data) {
    try {
        fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
        return true;
    } catch (error) {
        console.error('Error writing data file:', error);
        return false;
    }
}

// ========== ROUTES API - SEMUA SUDAH DILINDUNGI OLEH MIDDLEWARE /api ==========
app.get(config.apiPath, (req, res) => {
    try {
        const data = readData();
        const sorted = [...data.users].sort((a, b) => b.iq - a.iq);
        res.json({
            success: true,
            data: sorted,
            total: sorted.length
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

app.post(config.apiPath, (req, res) => {
    try {
        const { name, iq, correct, total, time, category } = req.body;

        if (!name || iq === undefined || correct === undefined) {
            return res.status(400).json({
                success: false,
                message: 'Data tidak lengkap'
            });
        }

        const data = readData();
        const existingIndex = data.users.findIndex(
            u => u.name.toLowerCase() === name.toLowerCase()
        );

        const userData = {
            name: name.trim(),
            iq: Number(iq),
            correct: Number(correct),
            total: Number(total) || 10,
            time: time || '00:00',
            category: category || 'Tidak Diketahui',
            date: new Date().toISOString()
        };

        if (existingIndex !== -1) {
            data.users[existingIndex] = {
                ...data.users[existingIndex],
                ...userData
            };
            console.log(`🔄 Update user: ${name} | IQ: ${iq}`);
        } else {
            data.users.push(userData);
            console.log(`✅ User baru: ${name} | IQ: ${iq}`);
        }

        if (writeData(data)) {
            res.json({
                success: true,
                message: 'Data berhasil disimpan',
                data: userData
            });
        } else {
            res.status(500).json({
                success: false,
                message: 'Gagal menyimpan data'
            });
        }
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

app.get(`${config.apiPath}/search`, (req, res) => {
    try {
        const { name } = req.query;
        if (!name) {
            return res.status(400).json({
                success: false,
                message: 'Parameter name diperlukan'
            });
        }

        const data = readData();
        const users = data.users.filter(
            u => u.name.toLowerCase().includes(name.toLowerCase())
        );

        res.json({
            success: true,
            data: users
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

app.get(`${config.apiPath}/stats`, (req, res) => {
    try {
        const data = readData();
        const users = data.users;

        if (users.length === 0) {
            return res.json({
                success: true,
                data: {
                    total: 0,
                    highestIQ: 0,
                    averageIQ: 0,
                    lowestIQ: 0,
                    totalUsers: 0
                }
            });
        }

        const iqs = users.map(u => u.iq);
        const highestIQ = Math.max(...iqs);
        const lowestIQ = Math.min(...iqs);
        const averageIQ = Math.round(iqs.reduce((a, b) => a + b, 0) / iqs.length);

        res.json({
            success: true,
            data: {
                total: users.length,
                highestIQ,
                averageIQ,
                lowestIQ,
                totalUsers: users.length
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

app.delete(`${config.apiPath}/clear`, (req, res) => {
    try {
        if (writeData({ users: [] })) {
            console.log('🗑️ Semua data ranking dihapus');
            res.json({
                success: true,
                message: 'Semua data berhasil dihapus'
            });
        } else {
            res.status(500).json({
                success: false,
                message: 'Gagal menghapus data'
            });
        }
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

// ========== CHECK TOKEN STATUS ==========
app.get('/api/check-token', (req, res) => {
    const token = req.query.token || req.cookies?.iq_token;
    const browserId = getBrowserId(req);
    const deviceFingerprint = getDeviceFingerprint(req);
    
    if (!token) {
        return res.json({
            valid: false,
            message: 'No token provided',
            browserId: browserId.substring(0, 20) + '...',
            device: deviceFingerprint.substring(0, 20) + '...'
        });
    }
    
    const isValid = isValidToken(token, deviceFingerprint, browserId);
    const session = tokenSessions.get(token);
    const expiry = session ? new Date(session.timestamp + TOKEN_EXPIRY_MS).toISOString() : null;
    
    res.json({
        valid: isValid,
        token: token.substring(0, 20) + '...',
        browserId: browserId.substring(0, 20) + '...',
        device: deviceFingerprint.substring(0, 20) + '...',
        deviceMatch: session ? session.deviceFingerprint === deviceFingerprint : false,
        browserMatch: session ? session.browserId === browserId : false,
        expiresAt: expiry,
        timeRemaining: session ? Math.floor((TOKEN_EXPIRY_MS - (Date.now() - session.timestamp)) / 1000) : 0,
        message: isValid ? 'Token valid untuk browser ini' : 'Token invalid atau browser berbeda'
    });
});

// ========== ENDPOINT MONITORING ==========
app.get('/api/proxy-status', (req, res) => {
    const proxy = require('./proxy.js');
    const status = proxy.getSystemStatus();
    const blocked = proxy.getBlockedIPs();
    
    res.json({
        success: true,
        timestamp: new Date().toISOString(),
        system: status,
        currentlyBlocked: blocked,
        totalBlocked: blocked.length
    });
});

app.get('/api/brute-force-stats', (req, res) => {
    const proxy = require('./proxy.js');
    const stats = proxy.getBruteForceStats();
    const blocked = proxy.getBlockedIPs();
    
    res.json({
        success: true,
        timestamp: new Date().toISOString(),
        activeBruteForceAttempts: stats,
        currentlyBlockedIPs: blocked,
        totalBlocked: blocked.length
    });
});

app.get('/api/my-ip-status', (req, res) => {
    const ip = req.ip || req.connection?.remoteAddress || 'unknown';
    const proxy = require('./proxy.js');
    const blockedIPs = proxy.getBlockedIPs();
    
    const myBlock = blockedIPs.find(b => b.ip === ip);
    
    res.json({
        success: true,
        ip: ip,
        isBlocked: !!myBlock,
        blockInfo: myBlock || null,
        allBlockedIPs: blockedIPs,
        totalBlocked: blockedIPs.length
    });
});

app.post('/api/unblock-ip', (req, res) => {
    const { ip } = req.body;
    const proxy = require('./proxy.js');
    
    if (!ip) {
        return res.status(400).json({
            success: false,
            message: 'IP required'
        });
    }
    
    const result = proxy.unblockIP(ip);
    res.json({
        success: true,
        message: `IP ${ip} unblocked successfully`,
        unblocked: result
    });
});

app.post('/api/unblock-all', (req, res) => {
    const proxy = require('./proxy.js');
    const blocked = proxy.getBlockedIPs();
    let count = 0;
    
    for (const b of blocked) {
        proxy.unblockIP(b.ip);
        count++;
    }
    
    res.json({
        success: true,
        message: `Successfully unblocked ${count} IP(s)`,
        count: count
    });
});

// ========== ROOT - SERVE DASHBOARD HTML ==========
app.get('/', (req, res) => {
    const dashboardFile = path.join(DASHBOARD_DIR, 'index.html');
    
    if (fs.existsSync(dashboardFile)) {
        console.log(`📄 Serving dashboard: ${path.relative(__dirname, dashboardFile)}`);
        res.sendFile(dashboardFile);
    } else {
        console.log(`❌ Dashboard file not found: ${dashboardFile}`);
        res.status(404).json({
            success: false,
            message: 'Dashboard file not found. Please put index.html in dashboard folder.',
            path: dashboardFile
        });
    }
});

// ========== 404 HANDLER ==========
app.use((req, res) => {
    res.status(404).json({
        success: false,
        message: 'Resource tidak ditemukan'
    });
});

// ========== ERROR HANDLING ==========
app.use((err, req, res, next) => {
    console.error('Server error:', err);
    res.status(500).json({
        success: false,
        message: 'Terjadi kesalahan pada server'
    });
});

// ========== START SERVER ==========
app.listen(PORT, () => {
    console.log(`\n╔════════════════════════════════════════════╗`);
    console.log(`║   🚀 IQ TEST RANKING SERVER  `);
    console.log(`╠════════════════════════════════════════════╣`);
    console.log(`║   🌐 ${BASE_URL}`);
    console.log(`║   📁 Data: ${DATA_FILE}`);
    console.log(`║   📁 Dashboard: ${DASHBOARD_DIR}`);
    console.log(`║   🔑 Password: Tersembunyi di config.js`);
    console.log(`║   ⏰ Token Expiry: ${TOKEN_EXPIRY_MS/60000} menit`);
    console.log(`║   🔒 Browser ID: Session (hilang saat browser ditutup)`);
    console.log(`║   🛡️  Proxy: Aktif (block 10 menit)`);
    console.log(`║   🔐 API Protection: ALL ENDPOINTS PROTECTED`);
    console.log(`║   🚫 Non-Browser: BLOCKED`);
    console.log(`╚════════════════════════════════════════════╝\n`);
    
    console.log(`\n📋 DAFTAR API ENDPOINT YANG DILINDUNGI:`);
    console.log(`   ✅ GET  ${config.apiPath}`);
    console.log(`   ✅ POST ${config.apiPath}`);
    console.log(`   ✅ GET  ${config.apiPath}/search`);
    console.log(`   ✅ GET  ${config.apiPath}/stats`);
    console.log(`   ✅ DELETE ${config.apiPath}/clear`);
    console.log(`   ✅ GET  /api/get-decrypted-content`);
    console.log(`   ✅ GET  /api/get-decrypted-dashboard`);
    console.log(`   ✅ GET  /api/create-dashboard-token`);
    console.log(`   ✅ GET  /api/check-token`);
    console.log(`   ✅ GET  /api/proxy-status`);
    console.log(`   ✅ GET  /api/brute-force-stats`);
    console.log(`   ✅ GET  /api/my-ip-status`);
    console.log(`   ✅ POST /api/unblock-ip`);
    console.log(`   ✅ POST /api/unblock-all`);
    console.log(`\n🛡️  SEMUA API ENDPOINT DILINDUNGI DENGAN BROWSER VALIDATION\n`);
});